import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
@Injectable({providedIn:'root'})
export class ApiService {
 private http=inject(HttpClient); private base=environment.apiUrl;
 get<T>(path:string,query:Record<string,string|number|boolean|undefined>={}):Observable<T>{
  let params=new HttpParams(); Object.entries(query).forEach(([k,v])=>{if(v!==undefined&&v!=='')params=params.set(k,String(v));});
  return this.http.get<T>(this.base+path,{params});
 }
 post<T>(path:string,body:unknown):Observable<T>{return this.http.post<T>(this.base+path,body)}
 put<T>(path:string,body:unknown):Observable<T>{return this.http.put<T>(this.base+path,body)}
 patch<T>(path:string,body:unknown):Observable<T>{return this.http.patch<T>(this.base+path,body)}
 delete<T>(path:string):Observable<T>{return this.http.delete<T>(this.base+path)}
}