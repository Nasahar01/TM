import { Priority, Role, TaskStatus } from './entities';
export interface LoginRequest { email:string; password:string }
export interface AuthResponse { accessToken:string; refreshToken:string; tokenType?:string; expiresInSeconds?:number; userId:number; email:string; name:string; role:Role }
export interface CreateProjectRequest { name:string; description?:string; startDate:string; endDate?:string; managerId?:number; memberIds?:number[] }
export interface CreateTaskRequest { projectId:number; title:string; description?:string; priority:Priority; dueDate?:string; assigneeId?:number }
export interface UpdateTaskRequest { title?:string; description?:string; priority?:Priority; dueDate?:string }
export interface UpdateStatusRequest { status:TaskStatus }
export interface AssignTaskRequest { assigneeId:number|null }
export interface CreateUserRequest { name:string; email:string; password:string; role:Role; phone?:string; department?:string }
export interface UpdateProfileRequest { name:string; phone?:string; department?:string }
export interface ChangePasswordRequest { currentPassword:string; newPassword:string }
export interface CommentRequest { content:string }
