export type Role = 'ADMIN'|'PROJECT_MANAGER'|'TEAM_MEMBER';
export type TaskStatus = 'TODO'|'IN_PROGRESS'|'IN_REVIEW'|'DONE';
export type Priority = 'LOW'|'MEDIUM'|'HIGH'|'CRITICAL';
export interface User { id:number; name:string; email:string; role:Role; phone?:string; department?:string; active?:boolean }
export interface Project { id:number; projectCode?:string; name:string; code?:string; description?:string; status?:string; startDate:string; endDate?:string; managerId?:number; managerName?:string; memberIds?:number[]; progress?:{available?:boolean;completed?:number;total?:number;percent?:number}; archived?:boolean }
export interface Task { id:number; projectId:number; title:string; description?:string; priority:Priority; status:TaskStatus; assigneeId?:number; createdById?:number; createdByName?:string; dueDate?:string; overdue?:boolean; createdAt?:string; updatedAt?:string }
export interface TaskComment { id:number; taskId:number; authorId:number; userId?:number; authorName?:string; userName?:string; content:string; createdAt:string }
export interface TaskHistory { id:number; taskId:number; action?:string; changedById?:number; changedByName?:string; fieldName:string; oldValue?:string; newValue?:string; changedAt:string }
export interface PageResponse<T> { content:T[]; page:number; totalElements:number; totalPages:number; size:number; last?:boolean }
