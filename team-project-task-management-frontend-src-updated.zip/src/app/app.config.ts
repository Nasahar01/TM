import { ApplicationConfig } from '@angular/core';
import { provideRouter, withInMemoryScrolling, withViewTransitions } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideStore } from '@ngrx/store';
import { provideEffects } from '@ngrx/effects';
import { routes } from './app.routes';
import { authInterceptor } from './features/auth/interceptors/auth.interceptor';
import { authReducer } from './features/auth/state/auth.reducer';
import { AuthEffects } from './features/auth/state/auth.effects';
import { projectsReducer } from './features/projects/state/projects.reducer';
import { ProjectsEffects } from './features/projects/state/projects.effects';
import { tasksReducer } from './features/tasks/state/tasks.reducer';
import { TasksEffects } from './features/tasks/state/tasks.effects';
import { usersReducer } from './features/users/state/users.reducer';
import { UsersEffects } from './features/users/state/users.effects';
export const appConfig: ApplicationConfig = { providers: [
 provideRouter(routes,withInMemoryScrolling({scrollPositionRestoration:'enabled',anchorScrolling:'enabled'}),withViewTransitions()),
 provideHttpClient(withInterceptors([authInterceptor])),
 provideStore({auth:authReducer,projects:projectsReducer,tasks:tasksReducer,users:usersReducer}),
 provideEffects([AuthEffects,ProjectsEffects,TasksEffects,UsersEffects])
]};