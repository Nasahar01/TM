import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap, tap } from 'rxjs';
import { Router } from '@angular/router';
import * as A from './tasks.actions';
import { TasksService } from '../services/tasks.service';

@Injectable()
export class TasksEffects {
  private actions = inject(Actions);
  private api = inject(TasksService);
  private router = inject(Router);
  load$ = createEffect(() => this.actions.pipe(
    ofType(A.loadMyTasks),
    switchMap(() => this.api.mine().pipe(
      map((tasks: any) => A.loadTasksSuccess({ tasks: Array.isArray(tasks) ? tasks : tasks.content ?? [] })),
      catchError(e => of(A.loadTasksFailure({ error: e.error?.message ?? 'Could not load tasks' })))
    ))
  ));
  create$ = createEffect(() => this.actions.pipe(
    ofType(A.createTask),
    switchMap(({ task }) => this.api.create(task).pipe(
      map(task => A.createTaskSuccess({ task })),
      tap(() => this.router.navigate(['/tasks'])),
      catchError(e => of(A.loadTasksFailure({ error: e.error?.message ?? 'Could not create task' })))
    ))
  ));
  status$ = createEffect(() => this.actions.pipe(
    ofType(A.changeTaskStatus),
    switchMap(({ id, status }) => this.api.status(id, status).pipe(
      map(() => A.loadMyTasks()),
      catchError(e => of(A.loadTasksFailure({ error: e.error?.message ?? 'Could not update status' })))
    ))
  ));
}