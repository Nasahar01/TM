import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import * as A from './users.actions';
import { UsersService } from '../services/users.service';

@Injectable()
export class UsersEffects {
  private actions = inject(Actions);
  private api = inject(UsersService);
  load$ = createEffect(() => this.actions.pipe(
    ofType(A.loadUsers),
    switchMap(() => this.api.list().pipe(
      map((r: any) => A.loadUsersSuccess({ users: Array.isArray(r) ? r : r.content ?? [] })),
      catchError(e => of(A.loadUsersFailure({ error: e.error?.message ?? 'Could not load users' })))
    ))
  ));
}