import { Injectable } from '@angular/core';
@Injectable({providedIn:'root'})
export class AuthTokenService {
 get accessToken(){return sessionStorage.getItem('tms_access_token')}
 get refreshToken(){return sessionStorage.getItem('tms_refresh_token')}
 save(access:string,refresh?:string){sessionStorage.setItem('tms_access_token',access);if(refresh)sessionStorage.setItem('tms_refresh_token',refresh)}
 clear(){sessionStorage.removeItem('tms_access_token');sessionStorage.removeItem('tms_refresh_token')}
}