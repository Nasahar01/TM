import { Injectable,inject } from '@angular/core';
import { ApiService } from '../../../core/services/api.service';
import { AuthResponse,LoginRequest } from '../../../core/models/dtos';
import { Observable } from 'rxjs';
import { User } from '../../../core/models/entities';
@Injectable({providedIn:'root'})
export class AuthService {
 private api=inject(ApiService);
 login(body:LoginRequest):Observable<AuthResponse>{return this.api.post('/auth/login',body)}
 validate():Observable<{valid:boolean;id:number;email:string;name:string;role:User['role']}>{return this.api.get('/auth/validate')}
 logout(){return this.api.post<void>('/auth/logout',{})}
 me(){return this.api.get<User>('/users/me')}
}