import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthTokenService } from '../services/auth-token.service';
export const authInterceptor:HttpInterceptorFn=(req,next)=>{
 const token=inject(AuthTokenService).accessToken;
 const request=token?req.clone({setHeaders:{Authorization:`Bearer ${token}`}}):req;
 return next(request);
};