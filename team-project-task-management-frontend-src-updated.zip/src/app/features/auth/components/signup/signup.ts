import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../../../core/services/api.service';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
  <main class="auth-page">
    <a class="brand auth-brand" routerLink="/"><span class="brand-mark">f</span> flowboard</a>
    <section class="auth-card">
      <a routerLink="/" class="back-link">← Back to home</a>
      <div class="auth-symbol">✳</div><p class="eyebrow">REQUEST ACCESS</p>
      <h1>Make room<br><em>to do.</em></h1>
      <p class="auth-copy">Submit a request to join Flowboard. An administrator will review it before your account is activated.</p>
      <form #signupForm="ngForm" (ngSubmit)="submit(signupForm)">
        <label for="name">Full name</label>
        <input id="name" name="name" [(ngModel)]="name" #nameField="ngModel" required maxlength="100" [class.invalid-field]="nameField.invalid&&nameField.touched" placeholder="Your full name">
        <small class="field-error" *ngIf="nameField.invalid&&nameField.touched">Enter your name (up to 100 characters).</small>
        <label for="email">Email address</label>
        <input id="email" name="email" type="email" [(ngModel)]="email" #emailField="ngModel" required email maxlength="150" [class.invalid-field]="emailField.invalid&&emailField.touched" placeholder="you@company.com">
        <small class="field-error" *ngIf="emailField.invalid&&emailField.touched">Enter a valid email address.</small>
        <label for="password">Password</label>
        <input id="password" name="password" type="password" [(ngModel)]="password" #passwordField="ngModel" required minlength="8" maxlength="64" [class.invalid-field]="passwordField.invalid&&passwordField.touched" placeholder="At least 8 characters">
        <small class="field-error" *ngIf="passwordField.invalid&&passwordField.touched">Password must be 8–64 characters.</small>
        <p class="error" *ngIf="error">{{error}}</p><p class="success" *ngIf="success">{{success}}</p>
        <button class="button button-dark button-full" [disabled]="signupForm.invalid||saving">{{saving?'Creating account…':'Create account ↗'}}</button>
      </form>
      <p class="auth-copy signup-switch">Already have an account? <a routerLink="/login">Sign in</a></p>
    </section>
    <p class="auth-foot">A little more clarity. A lot more momentum.</p>
  </main>`
})
export class Signup {
  private api = inject(ApiService);
  name=''; email=''; password=''; saving=false; error=''; success='';
  submit(form: NgForm) {
    if (form.invalid || this.saving) return;
    this.saving=true; this.error=''; this.success='';
    // Requires the registration-request endpoints documented in BACKEND_CHANGES_REQUIRED.md.
    this.api.post<any>('/users/registration-requests',{name:this.name.trim(),email:this.email.trim(),password:this.password})
      .subscribe({next:()=>{this.saving=false;this.success='Request submitted. An administrator will review it; you can sign in after approval.';this.name='';this.email='';this.password='';form.resetForm();},
      error:(e)=>{this.saving=false;this.error=e.status===401||e.status===404||e.status===405?'The backend does not yet support access requests. Apply the backend changes in BACKEND_CHANGES_REQUIRED.md, then try again.':(e.error?.message||'Could not submit your request. Please try again.');}});
  }
}
