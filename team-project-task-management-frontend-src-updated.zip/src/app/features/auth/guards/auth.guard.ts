import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { catchError, map, of, switchMap, take, tap } from 'rxjs';
import { AuthTokenService } from '../services/auth-token.service';
import { AuthService } from '../services/auth.service';
import { selectCurrentUser } from '../state/auth.selectors';
import { loadMeSuccess } from '../state/auth.actions';

export const authGuard: CanActivateFn = () => {
  const tokens = inject(AuthTokenService);
  const router = inject(Router);
  const store = inject(Store);
  const auth = inject(AuthService);
  if (!tokens.accessToken) return router.createUrlTree(['/login']);
  return store.select(selectCurrentUser).pipe(
    take(1),
    switchMap(user => {
      if (user) return of(true);
      return auth.me().pipe(
        tap(current => {
          store.dispatch(loadMeSuccess({ user: current }));
          sessionStorage.setItem('tms_role', current.role);
        }),
        map(() => true),
        catchError(() => {
          tokens.clear();
          sessionStorage.removeItem('tms_role');
          return of(router.createUrlTree(['/login']));
        })
      );
    })
  );
};
