import { createAction,props } from '@ngrx/store'; import { AuthResponse,LoginRequest } from '../../../core/models/dtos'; import { User } from '../../../core/models/entities';
export const login=createAction('[Auth] Login',props<{credentials:LoginRequest}>());
export const loginSuccess=createAction('[Auth] Login Success',props<{response:AuthResponse}>());
export const loginFailure=createAction('[Auth] Login Failure',props<{error:string}>());
export const logout=createAction('[Auth] Logout');
export const logoutSuccess=createAction('[Auth] Logout Success');
export const loadMe=createAction('[Auth] Load Me');
export const loadMeSuccess=createAction('[Auth] Load Me Success',props<{user:User}>());
export const clearAuthError=createAction('[Auth] Clear Error');