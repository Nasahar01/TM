import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Router } from '@angular/router';
import { catchError, exhaustMap, map, of, tap } from 'rxjs';
import * as A from './auth.actions';
import { AuthService } from '../services/auth.service';
import { AuthTokenService } from '../services/auth-token.service';

@Injectable()
export class AuthEffects {
  private actions = inject(Actions);
  private api = inject(AuthService);
  private tokens = inject(AuthTokenService);
  private router = inject(Router);

  login$ = createEffect(() => this.actions.pipe(
    ofType(A.login),
    exhaustMap(({ credentials }) => this.api.login(credentials).pipe(
      tap(r => {
        this.tokens.save(r.accessToken, r.refreshToken);
        sessionStorage.setItem('tms_role', r.role);
      }),
      map(response => A.loginSuccess({ response })),
      tap(() => this.router.navigate(['/app'])),
      catchError(e => of(A.loginFailure({ error: e.error?.message || 'Unable to sign in. Check your credentials.' })))
    ))
  ));

  loadMe$ = createEffect(() => this.actions.pipe(
    ofType(A.loadMe),
    exhaustMap(() => this.api.me().pipe(
      map(user => A.loadMeSuccess({ user })),
      catchError(() => of(A.loginFailure({ error: 'Your session could not be restored.' })))
    ))
  ));

  logout$ = createEffect(() => this.actions.pipe(
    ofType(A.logout),
    exhaustMap(() => this.api.logout().pipe(
      catchError(() => of(null)),
      tap(() => {
        this.tokens.clear();
        sessionStorage.removeItem('tms_role');
        this.router.navigate(['/']);
      }),
      map(() => A.logoutSuccess())
    ))
  ));
}