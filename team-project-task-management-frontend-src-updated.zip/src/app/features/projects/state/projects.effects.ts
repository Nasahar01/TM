import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import * as A from './projects.actions';
import { ProjectsService } from '../services/projects.service';

function rows<T>(value: any): T[] {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.content)) return value.content;
  if (Array.isArray(value?.items)) return value.items;
  if (Array.isArray(value?.data)) return value.data;
  if (Array.isArray(value?.data?.content)) return value.data.content;
  return [];
}
@Injectable()
export class ProjectsEffects {
  private actions = inject(Actions);
  private api = inject(ProjectsService);
  load$ = createEffect(() => this.actions.pipe(
    ofType(A.loadProjects),
    switchMap(({ q }) => this.api.list(q).pipe(
      map((r: any) => A.loadProjectsSuccess({ projects: rows(r) })),
      catchError(e => of(A.loadProjectsFailure({ error: e.error?.message ?? 'Could not load projects' })))
    ))
  ));
  create$ = createEffect(() => this.actions.pipe(
    ofType(A.createProject),
    switchMap(({ project }) => this.api.create(project).pipe(
      switchMap(created => [A.createProjectSuccess({ project: created }), A.loadProjects({})]),
      catchError(e => of(A.loadProjectsFailure({ error: e.error?.message ?? 'Could not create project' })))
    ))
  ));
}
