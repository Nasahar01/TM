# Frontend/backend alignment notes

## Changes in this frontend ZIP

- Removed the duplicate project-list request on the dashboard. The dashboard now loads projects once and reuses that result while it loads task data.
- Task loading now keeps successful project results even if one project request fails; previously one failed project request could cause the UI to fall back to `/tasks/my` and incorrectly show zero tasks for admins/managers.
- Increased the task page size from 100 to 200 and normalized the backend's standard `PageResponse.content` shape.
- Added loading states so pending project/task/user requests are not rendered as empty lists or zero counts.
- Creating a task/project or changing task status updates the local NgRx list rather than triggering a full reload immediately. Creating/deactivating a member updates the local user list rather than refetching the entire directory.
- Signup now submits an access request; the admin user page has an Access requests panel with approve/reject actions.

## Backend requirements / limitations

The supplied backend currently has no `POST /users/register`, no public registration-request endpoint, and no admin approve/reject endpoints. The new access-request UI calls:

- `POST /users/registration-requests`
- `GET /admin/registration-requests?status=PENDING&page=0&size=100`
- `PATCH /admin/registration-requests/{id}/approve`
- `PATCH /admin/registration-requests/{id}/reject`

These must be implemented in the backend before signup requests and their review can work. See `BACKEND_CHANGES_REQUIRED.md` for the endpoint contract, schema, password handling and gateway security changes. The gateway already routes `/users/**` and `/admin/**`, but its JWT public-path allowlist must explicitly permit only the public registration-request POST.

For fastest task loading, the backend should also add a role-aware `GET /tasks/visible` endpoint. It is not present in the supplied backend, so this frontend keeps a safe multi-project fallback for ADMIN/PROJECT_MANAGER.

The source ZIP was updated without installed npm dependencies in this environment, so an Angular production build could not be run here. Please run `npm install` and `npm run build` locally before deployment.
