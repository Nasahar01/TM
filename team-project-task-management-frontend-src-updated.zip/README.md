# Flowboard — Team Project & Task Management frontend

Angular 20 standalone application following the VoyageGuard source conventions: feature-oriented folders, standalone components, service-based API calls, NgRx actions/reducers/selectors/effects, and global styling.

## Run locally
1. Ensure the TMS backend services, MySQL, and Eureka are running. The frontend calls the gateway at `http://localhost:8080`.
2. Install Node.js 20.19+ (or the version supported by Angular 20).
3. Run `npm install`
4. Run `npm start` and open `http://localhost:4200`.

Update `src/environments/environment.ts` if your API gateway is hosted elsewhere. The backend gateway CORS configuration should allow `http://localhost:4200`.

## Demo accounts
Use the seeded accounts from the backend README:
- `admin@tms.com` / `Admin@123`
- `manager@tms.com` / `Manager@123`
- `member1@tms.com` / `Member@123`
- `member2@tms.com` / `Member@123`

## Features included
- Public landing page, no login required, with smooth hover, reveal, floating and route-transition animations.
- Sign in using `POST /auth/login`; bearer access token attached by interceptor; logout via `POST /auth/logout`.
- Workspace overview with project and task summary.
- Projects list/search/create, project progress, archive/member operations in typed service.
- My tasks, status updates, task creation, project board/summary, comments and history methods.
- Admin user directory, create/deactivate user; profile, password, directory methods in user service.
- Role guard for admin-only user management.
- DTOs/entities for the backend's project/task/user/auth domain.
- NgRx feature state for authentication, projects, tasks and users.

## Backend alignment notes
- Routes use the public gateway endpoints documented in the backend README; `/internal/**` is intentionally not called from the browser.
- The auth response is the backend's flat `AuthResponseDTO` (`accessToken`, `refreshToken`, `userId`, `name`, `email`, `role`).
- This backend returns tokens in JSON, not HttpOnly cookies. The starter stores access/refresh tokens in sessionStorage; if the backend is changed to set HttpOnly cookies, remove token storage and use `withCredentials` with the server cookie/CORS configuration.
- Some backend endpoints are exposed as typed service methods but do not yet have dedicated polished screens (project members, comments/history detail, profile/password). API methods are present for those workflows.
- Check backend DTO field names against your actual branch if they differ. The supplied backend archive README is the source of endpoint truth.
