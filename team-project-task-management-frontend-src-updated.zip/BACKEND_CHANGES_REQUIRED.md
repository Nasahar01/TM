# Backend changes required for fast task loading and access requests

I reviewed the supplied WebFlux backend source (`api-gateway`, `auth-service`, `user-service`, `project-service`, and `task-service`). The current frontend can reduce duplicate requests and avoid throwing away all task results when one project request fails, but two backend capabilities are not present yet.

## 1. Registration request + admin approval/rejection

The current `UserRouter` exposes `GET/PUT /users/me`, `GET /users/directory`, and admin CRUD under `/admin/users`. It has **no public registration endpoint and no registration-request entity/table**. The frontend now calls the endpoints below, so this feature becomes functional only after the backend implements them.

### API contract

- `POST /users/registration-requests` — public, no JWT. Body: `{ "name": "...", "email": "...", "password": "..." }`. Return `201` with a safe request DTO (never return the password hash).
- `GET /admin/registration-requests?status=PENDING&page=0&size=100` — ADMIN only. Return the standard `PageResponse` shape (`content`, `page`, `size`, `totalElements`, `totalPages`, `last`).
- `PATCH /admin/registration-requests/{id}/approve` — ADMIN only. Body `{ "role": "TEAM_MEMBER" }` (allow only `TEAM_MEMBER` or `PROJECT_MANAGER` unless promoting admins is an explicit policy). Create an active user using the already-BCrypt-hashed requested password, mark the request `APPROVED`, and return the safe user response.
- `PATCH /admin/registration-requests/{id}/reject` — ADMIN only. Body `{ "reason": "optional reason" }`. Mark `REJECTED`; erase the stored password hash.

### Suggested schema

Create this table in `user-service/src/main/resources/schema.sql` (or preferably a versioned migration):

```sql
CREATE TABLE IF NOT EXISTS registration_requests (
  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  password_hash VARCHAR(100),
  status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
  requested_at DATETIME(6) NOT NULL,
  reviewed_at DATETIME(6),
  reviewed_by BIGINT,
  rejection_reason VARCHAR(500),
  CONSTRAINT uk_registration_request_email UNIQUE (email)
);
CREATE INDEX idx_registration_requests_status ON registration_requests(status);
```

Implement a `RegistrationRequest` entity, reactive repository, DTOs, service and handlers, then add these routes to `UserRouter`. Validate name/email/password using constraints already used by `CreateUserRequest`; normalize email to lowercase; reject duplicate emails against both `users` and pending requests; hash the password with the same `PasswordEncoder` as `UserService`; never store or log the raw password. Approval must be transactional/idempotent so repeated clicks cannot create duplicate users. On approval, copy the stored hash directly into the `users.password` column—**do not pass it through the password encoder a second time**. Ensure the user is active and the account is only created after approval.

### Gateway security is required

The gateway already routes `/users/**` and `/admin/**` to `user-service`, so no new gateway route is needed. However, `api-gateway/.../config/SecurityConfig.java` currently lists only `/auth/login`, `/auth/refresh`, and actuator paths as public. Add the exact path `/users/registration-requests` to `PUBLIC_PATHS` and `permitAll()` for POST registration requests. Do not make `/admin/registration-requests` public. Add a user-service handler that does not call `RequestUser.require()` for the public POST, but does require `ADMIN` for all admin review endpoints. Confirm service-level security also allows that one public POST.

The existing auth service checks `active` during login, so a request should not create a user or issue a token before approval.

## 2. Reduce task loading to one request (recommended)

The current task backend only exposes `GET /tasks/my` (tasks assigned to the current user) and `GET /tasks/project/{projectId}`. The frontend previously made a project-list request and then one task request per project; that fan-out is the main avoidable source of delay for ADMIN/PROJECT_MANAGER dashboards. The frontend update now removes duplicate project-list calls in the dashboard, handles project task requests independently, and updates task/project lists locally after successful create/status changes instead of immediately refetching everything.

For the best fix, add a role-aware endpoint such as `GET /tasks/visible?page=0&size=200` that returns one paginated `PageResponse<TaskResponse>`:

- `ADMIN`: tasks across the organization.
- `PROJECT_MANAGER`: tasks only in projects they manage (use the project service's authoritative access rules).
- `TEAM_MEMBER`: tasks assigned to that user (same scope as `/tasks/my`).

Keep authorization in the backend; do not trust a role or user ID supplied in query parameters. Implement the query efficiently with indexed project/assignee columns and stable sorting. Then the frontend can replace the multi-request manager/admin fallback with this endpoint. The current backend does **not** have `/tasks/visible`, so it is not called by this ZIP.

## 3. Current backend behavior confirmed

- `GET /tasks/my` returns tasks assigned to the current user, not all tasks visible to an admin/manager.
- Project/task/user list endpoints return the standard `PageResponse` object with a `content` array.
- `POST /admin/users` is ADMIN-only and immediately creates an active user; it is appropriate for administrator-created accounts, not public signup.
- Gateway routes `/users/**`, `/admin/**`, `/projects/**`, and `/tasks/**` already exist.
