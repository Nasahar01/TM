import { Component, inject, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Store } from '@ngrx/store';
import { AnimatedBg } from './shared/components/animated-bg/animated-bg';
import { ToastContainer } from './shared/components/toast-container/toast-container';
import { loadCurrentUser } from './features/auth/state/auth.actions';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, AnimatedBg, ToastContainer],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnInit {

  private store = inject(Store);

  /** Restores the session (GET /auth/validate) before any guarded route renders. */
  ngOnInit(): void {
    this.store.dispatch(loadCurrentUser());
  }
}
