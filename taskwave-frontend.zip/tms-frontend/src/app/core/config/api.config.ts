import { InjectionToken } from '@angular/core';

/** Base URL of the Spring Cloud API Gateway. Every request goes through it. */
export const API_URL = new InjectionToken<string>('API_URL', {
  providedIn: 'root',
  factory: () => 'http://localhost:8080',
});
