export type Role = 'ADMIN' | 'PROJECT_MANAGER' | 'TEAM_MEMBER';

export const ROLES: Role[] = ['ADMIN', 'PROJECT_MANAGER', 'TEAM_MEMBER'];

export interface RoleInfo {
  role: Role;
  /** short slug used in /login?portal=slug */
  slug: string;
  label: string;
  tagline: string;
  icon: string;
  home: string;
  /** demo account seeded by user-service (README) - used by the "fill demo" shortcut on the login page */
  demo: { email: string; password: string };
}

export const ROLE_INFO: RoleInfo[] = [
  { role: 'ADMIN', slug: 'admin', label: 'Admin', tagline: 'Manage users, oversee every project', icon: 'shield-check', home: '/app/dashboard', demo: { email: 'admin@tms.com', password: 'Admin@123' } },
  { role: 'PROJECT_MANAGER', slug: 'manager', label: 'Project Manager', tagline: 'Plan projects, build teams, assign tasks', icon: 'briefcase', home: '/app/dashboard', demo: { email: 'manager@tms.com', password: 'Manager@123' } },
  { role: 'TEAM_MEMBER', slug: 'member', label: 'Team Member', tagline: 'See your tasks, move work forward', icon: 'users', home: '/app/dashboard', demo: { email: 'member1@tms.com', password: 'Member@123' } },
];

export const roleInfo = (role: string | null | undefined): RoleInfo | undefined => ROLE_INFO.find((r) => r.role === role);
export const roleBySlug = (slug: string | null | undefined): RoleInfo | undefined => ROLE_INFO.find((r) => r.slug === slug);
export const homeFor = (role: string | null | undefined): string => roleInfo(role)?.home ?? '/app/dashboard';

export interface NavItem { label: string; path: string; icon: string; }

/** Sidebar entries per role. Notifications do not exist in this system, so the shared items are Profile only. */
export const NAV_BY_ROLE: Record<Role, NavItem[]> = {
  ADMIN: [
    { label: 'Dashboard', path: '/app/dashboard', icon: 'home' },
    { label: 'Projects', path: '/app/projects', icon: 'folder' },
    { label: 'My tasks', path: '/app/my-tasks', icon: 'check-square' },
    { label: 'Users', path: '/app/admin/users', icon: 'users' },
  ],
  PROJECT_MANAGER: [
    { label: 'Dashboard', path: '/app/dashboard', icon: 'home' },
    { label: 'Projects', path: '/app/projects', icon: 'folder' },
    { label: 'New project', path: '/app/projects/new', icon: 'plus' },
    { label: 'My tasks', path: '/app/my-tasks', icon: 'check-square' },
  ],
  TEAM_MEMBER: [
    { label: 'Dashboard', path: '/app/dashboard', icon: 'home' },
    { label: 'My tasks', path: '/app/my-tasks', icon: 'check-square' },
    { label: 'My projects', path: '/app/projects', icon: 'folder' },
  ],
};
