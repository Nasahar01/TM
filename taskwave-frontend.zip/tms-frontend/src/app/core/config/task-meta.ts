/** Single source of truth for task / project vocabulary (mirrors the backend enums). */
export type TaskStatus = 'TODO' | 'IN_PROGRESS' | 'IN_REVIEW' | 'DONE';
export type TaskPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type ProjectStatus = 'PLANNING' | 'ACTIVE' | 'ON_HOLD' | 'COMPLETED' | 'ARCHIVED';

export const TASK_STATUSES: TaskStatus[] = ['TODO', 'IN_PROGRESS', 'IN_REVIEW', 'DONE'];
export const TASK_PRIORITIES: TaskPriority[] = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];
/** ARCHIVED is only reachable through PATCH /projects/{id}/archive, never through the edit form. */
export const EDITABLE_PROJECT_STATUSES: ProjectStatus[] = ['PLANNING', 'ACTIVE', 'ON_HOLD', 'COMPLETED'];
export const PROJECT_STATUSES: ProjectStatus[] = [...EDITABLE_PROJECT_STATUSES, 'ARCHIVED'];

export interface ColumnMeta { status: TaskStatus; label: string; icon: string; accent: string; }

export const BOARD_COLUMNS: ColumnMeta[] = [
  { status: 'TODO', label: 'To Do', icon: 'circle', accent: '#8a86b8' },
  { status: 'IN_PROGRESS', label: 'In Progress', icon: 'play', accent: '#3aa8ff' },
  { status: 'IN_REVIEW', label: 'In Review', icon: 'eye', accent: '#ffb429' },
  { status: 'DONE', label: 'Done', icon: 'check', accent: '#14c8a0' },
];

export const PRIORITY_COLOR: Record<TaskPriority, string> = {
  LOW: '#14c8a0',
  MEDIUM: '#3aa8ff',
  HIGH: '#ffb429',
  CRITICAL: '#ff6277',
};

export const statusLabel = (s: string): string => BOARD_COLUMNS.find((c) => c.status === s)?.label ?? s;
