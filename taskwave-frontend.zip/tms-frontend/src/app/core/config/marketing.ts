/** Copy for the public pages, kept out of the templates so it is easy to edit. */
export interface Feature { icon: string; title: string; text: string; tone: string; }

export const FEATURES: Feature[] = [
  { icon: 'folder', title: 'Projects with a clear owner', text: 'Create projects with dates, status and a project manager. Every project gets a unique code and a team of members.', tone: 'brand' },
  { icon: 'check-square', title: 'Tasks that never get lost', text: 'Create tasks with priority, due date and assignee. Update details, reassign, or delete in a couple of clicks.', tone: 'mint' },
  { icon: 'columns', title: 'Drag and drop Kanban', text: 'Move cards across To Do, In Progress, In Review and Done. The board updates instantly and syncs in the background.', tone: 'sky' },
  { icon: 'message', title: 'Discussion on every task', text: 'Keep decisions next to the work with comments on each task, shown with author and time.', tone: 'sun' },
  { icon: 'history', title: 'A full audit trail', text: 'Status moves, reassignments and edits are recorded with who did it and when. Nothing changes silently.', tone: 'coral' },
  { icon: 'shield-check', title: 'Role-based access', text: 'Admins, project managers and team members each see and do exactly what their role allows, enforced by the API.', tone: 'brand' },
];

export interface Step { n: string; title: string; text: string; icon: string; }

export const STEPS: Step[] = [
  { n: '01', title: 'Admin onboards the team', text: 'The admin creates user accounts and assigns the Project Manager or Team Member role.', icon: 'user-plus' },
  { n: '02', title: 'Manager plans the project', text: 'A project manager creates the project, sets dates and adds the people who will work on it.', icon: 'folder' },
  { n: '03', title: 'Tasks are assigned', text: 'Tasks get a priority, a due date and an assignee from the project team.', icon: 'target' },
  { n: '04', title: 'Everyone moves work forward', text: 'Members update status on the Kanban board and talk it through in comments, while progress updates live.', icon: 'zap' },
];

export interface MatrixRow { capability: string; admin: string; manager: string; member: string; }

export const MATRIX: MatrixRow[] = [
  { capability: 'Create and manage users', admin: 'yes', manager: 'no', member: 'no' },
  { capability: 'Create projects', admin: 'yes', manager: 'yes', member: 'no' },
  { capability: 'Edit projects and manage members', admin: 'All projects', manager: 'Own projects', member: 'no' },
  { capability: 'Archive a project', admin: 'yes', manager: 'Own projects', member: 'no' },
  { capability: 'Create and assign tasks', admin: 'yes', manager: 'yes', member: 'In their projects' },
  { capability: 'Edit or delete tasks', admin: 'yes', manager: 'Own projects', member: 'Tasks they created' },
  { capability: 'Change task status', admin: 'yes', manager: 'Own projects', member: 'Tasks assigned to them' },
  { capability: 'Comment and read history', admin: 'yes', manager: 'yes', member: 'yes' },
];

export interface Faq { q: string; a: string; }

export const FAQS: Faq[] = [
  { q: 'Who can create an account?', a: 'Accounts are created by an Admin, who also chooses the role. Self sign-up is intentionally not available, so only people your organisation approves can get in.' },
  { q: 'Can a team member move any task?', a: 'No. Team members can update the status of tasks assigned to them. Admins and the project manager of a project can move any task in it.' },
  { q: 'What happens when a project is archived?', a: 'It becomes read-only. Nobody can add or change tasks, but the full history stays available for reference.' },
  { q: 'Can completed tasks be deleted?', a: 'No. Completed tasks are kept as project history so progress reports stay honest.' },
  { q: 'What if someone leaves a project?', a: 'When a member is removed, their tasks in that project become unassigned so a manager can hand them to someone else.' },
  { q: 'Is my session secure?', a: 'Every request carries a signed JWT. Access tokens are short lived and silently renewed with a rotating refresh token; signing out ends the session on every device.' },
];

export const MARQUEE: string[] = [
  'Projects', 'Kanban board', 'Task assignment', 'Due-date tracking', 'Comments', 'Audit history', 'Role-based access', 'Progress summary', 'Team directory', 'Priority levels',
];
