import { inject, Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { map } from 'rxjs';
import * as AuthActions from '../../features/auth/state/auth.actions';
import * as CommentsActions from '../../features/comments/state/comments.actions';
import * as ProjectsActions from '../../features/projects/state/projects.actions';
import * as TasksActions from '../../features/tasks/state/tasks.actions';
import * as UsersActions from '../../features/users/state/users.actions';
import { showToast } from './ui.actions';

/** One place that turns success / failure actions into toasts. Components never call toasts themselves. */
@Injectable()
export class NotifyEffects {
  private actions$ = inject(Actions);

  success$ = createEffect(() =>
    this.actions$.pipe(
      ofType(
        AuthActions.loginSuccess, AuthActions.logoutSuccess,
        UsersActions.updateProfileSuccess, UsersActions.changePasswordSuccess, UsersActions.createUserSuccess,
        UsersActions.updateUserSuccess, UsersActions.deactivateUserSuccess,
        ProjectsActions.createProjectSuccess, ProjectsActions.updateProjectSuccess, ProjectsActions.archiveProjectSuccess,
        ProjectsActions.addMembersSuccess, ProjectsActions.removeMemberSuccess,
        TasksActions.createTaskSuccess, TasksActions.updateTaskSuccess, TasksActions.deleteTaskSuccess,
        TasksActions.updateTaskStatusSuccess, TasksActions.assignTaskSuccess,
        CommentsActions.addCommentSuccess,
      ),
      map((a) => showToast({ kind: 'success', message: this.successText(a) })),
    ),
  );

  failure$ = createEffect(() =>
    this.actions$.pipe(
      ofType(
        AuthActions.logoutFailure,
        UsersActions.loadProfileFailure, UsersActions.updateProfileFailure, UsersActions.changePasswordFailure,
        UsersActions.loadUsersFailure, UsersActions.createUserFailure, UsersActions.updateUserFailure,
        UsersActions.deactivateUserFailure, UsersActions.loadDirectoryFailure,
        ProjectsActions.loadProjectsFailure, ProjectsActions.loadProjectFailure, ProjectsActions.createProjectFailure,
        ProjectsActions.updateProjectFailure, ProjectsActions.archiveProjectFailure, ProjectsActions.addMembersFailure,
        ProjectsActions.removeMemberFailure,
        TasksActions.loadBoardFailure, TasksActions.loadProjectTasksFailure, TasksActions.loadMyTasksFailure, TasksActions.loadTaskFailure,
        TasksActions.createTaskFailure, TasksActions.updateTaskFailure, TasksActions.deleteTaskFailure,
        TasksActions.updateTaskStatusFailure, TasksActions.assignTaskFailure,
        CommentsActions.loadCommentsFailure, CommentsActions.addCommentFailure, CommentsActions.loadHistoryFailure,
      ),
      map((a) => showToast({ kind: 'error', message: a.error })),
    ),
  );

  expired$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthActions.sessionExpired),
      map(() => showToast({ kind: 'info', message: 'Your session ended. Please sign in again.' })),
    ),
  );

  private successText(a: { type: string }): string {
    switch (a.type) {
      case AuthActions.loginSuccess.type: return 'Welcome back! You are signed in.';
      case AuthActions.logoutSuccess.type: return 'You have been signed out.';
      case UsersActions.updateProfileSuccess.type: return 'Profile updated.';
      case UsersActions.changePasswordSuccess.type: return 'Password changed.';
      case UsersActions.createUserSuccess.type: return 'User created.';
      case UsersActions.updateUserSuccess.type: return 'User updated.';
      case UsersActions.deactivateUserSuccess.type: return 'User deactivated.';
      case ProjectsActions.createProjectSuccess.type: return 'Project created.';
      case ProjectsActions.updateProjectSuccess.type: return 'Project updated.';
      case ProjectsActions.archiveProjectSuccess.type: return 'Project archived. It is now read-only.';
      case ProjectsActions.addMembersSuccess.type: return 'Team updated.';
      case ProjectsActions.removeMemberSuccess.type: return 'Member removed. Their tasks are now unassigned.';
      case TasksActions.createTaskSuccess.type: return 'Task created.';
      case TasksActions.updateTaskSuccess.type: return 'Task updated.';
      case TasksActions.deleteTaskSuccess.type: return 'Task deleted.';
      case TasksActions.updateTaskStatusSuccess.type: return 'Task status updated.';
      case TasksActions.assignTaskSuccess.type: return 'Assignee updated.';
      case CommentsActions.addCommentSuccess.type: return 'Comment posted.';
      default: return 'Done.';
    }
  }
}
