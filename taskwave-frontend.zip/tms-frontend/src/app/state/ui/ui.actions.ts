import { createAction } from '@ngrx/store';

export type ToastKind = 'success' | 'error' | 'info';
let toastSeq = 0;

export const showToast = createAction('[UI] Show Toast', (p: { kind: ToastKind; message: string }) => ({ ...p, id: ++toastSeq }));
export const dismissToast = createAction('[UI] Dismiss Toast', (p: { id: number }) => p);
