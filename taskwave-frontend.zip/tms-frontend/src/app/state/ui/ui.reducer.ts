import { createReducer, on } from '@ngrx/store';
import { initialUiState, UiState } from './ui.state';
import * as UiActions from './ui.actions';

export const uiReducer = createReducer(
  initialUiState,
  on(UiActions.showToast, (state, { id, kind, message }): UiState => ({ toasts: [...state.toasts.slice(-3), { id, kind, message }] })),
  on(UiActions.dismissToast, (state, { id }): UiState => ({ toasts: state.toasts.filter((t) => t.id !== id) })),
);
