import { ToastKind } from './ui.actions';

export interface Toast { id: number; kind: ToastKind; message: string; }
export interface UiState { toasts: Toast[]; }
export const initialUiState: UiState = { toasts: [] };
