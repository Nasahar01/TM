import { dismissToast, showToast } from './ui.actions';
import { uiReducer } from './ui.reducer';
import { initialUiState } from './ui.state';

describe('uiReducer', () => {
  it('adds and dismisses toasts', () => {
    const a = showToast({ kind: 'success', message: 'Saved' });
    let s = uiReducer(initialUiState, a);
    expect(s.toasts.length).toBe(1);
    s = uiReducer(s, dismissToast({ id: a.id }));
    expect(s.toasts.length).toBe(0);
  });

  it('shows at most four toasts at a time', () => {
    let s = initialUiState;
    for (let i = 0; i < 7; i++) s = uiReducer(s, showToast({ kind: 'info', message: `m${i}` }));
    expect(s.toasts.length).toBe(4);
    expect(s.toasts[3].message).toBe('m6');
  });
});
