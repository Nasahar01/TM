import { Routes } from '@angular/router';
import { authGuard } from './features/auth/guards/authGuard';
import { roleGuard } from './features/auth/guards/roleGuard';
import { roleHomeGuard } from './features/auth/guards/roleHomeGuard';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./features/public/components/public-layout/public-layout').then((m) => m.PublicLayout),
    children: [
      { path: '', pathMatch: 'full', title: 'Taskwave | Plan, assign, ship together', loadComponent: () => import('./features/public/components/home/home').then((m) => m.Home) },
      { path: 'features', title: 'Features | Taskwave', loadComponent: () => import('./features/public/components/features/features').then((m) => m.Features) },
      { path: 'about', title: 'How it works | Taskwave', loadComponent: () => import('./features/public/components/about/about').then((m) => m.About) },
      { path: 'login', title: 'Sign in | Taskwave', loadComponent: () => import('./features/auth/components/login-form/login-form').then((m) => m.LoginForm) },
    ],
  },
  {
    path: 'app',
    canActivate: [authGuard],
    loadComponent: () => import('./features/dashboard/components/dashboard-layout/dashboard-layout').then((m) => m.DashboardLayout),
    children: [
      { path: '', pathMatch: 'full', canActivate: [roleHomeGuard], children: [] },
      { path: 'dashboard', title: 'Dashboard | Taskwave', loadComponent: () => import('./features/dashboard/components/overview/overview').then((m) => m.Overview) },
      { path: 'projects', title: 'Projects | Taskwave', loadComponent: () => import('./features/projects/components/projects-list/projects-list').then((m) => m.ProjectsList) },
      {
        path: 'projects/new',
        title: 'New project | Taskwave',
        canActivate: [roleGuard],
        data: { roles: ['ADMIN', 'PROJECT_MANAGER'] },
        loadComponent: () => import('./features/projects/components/project-form/project-form').then((m) => m.ProjectForm),
      },
      {
        path: 'projects/:id/edit',
        title: 'Edit project | Taskwave',
        canActivate: [roleGuard],
        data: { roles: ['ADMIN', 'PROJECT_MANAGER'] },
        loadComponent: () => import('./features/projects/components/project-form/project-form').then((m) => m.ProjectForm),
      },
      { path: 'projects/:id', title: 'Project | Taskwave', loadComponent: () => import('./features/projects/components/project-detail/project-detail').then((m) => m.ProjectDetail) },
      { path: 'my-tasks', title: 'My tasks | Taskwave', loadComponent: () => import('./features/tasks/components/my-tasks/my-tasks').then((m) => m.MyTasks) },
      {
        path: 'admin/users',
        title: 'Users | Taskwave',
        canActivate: [roleGuard],
        data: { roles: ['ADMIN'] },
        loadComponent: () => import('./features/users/components/admin-users/admin-users').then((m) => m.AdminUsers),
      },
      { path: 'profile', title: 'Profile | Taskwave', loadComponent: () => import('./features/users/components/profile/profile').then((m) => m.Profile) },
    ],
  },
  { path: '**', title: 'Not found | Taskwave', loadComponent: () => import('./features/public/components/not-found/not-found').then((m) => m.NotFound) },
];
