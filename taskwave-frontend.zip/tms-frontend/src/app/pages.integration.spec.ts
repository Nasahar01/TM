import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap, provideRouter } from '@angular/router';
import { Store } from '@ngrx/store';
import { BehaviorSubject } from 'rxjs';
import { provideTestEnv } from './testing/test-env';
import { makeDetail, makeProject, makeSession, makeTask, makeUser } from './testing/factories';
import { emptyColumns } from './features/tasks/entities/task.entity';
import * as Auth from './features/auth/state/auth.actions';
import * as Projects from './features/projects/state/projects.actions';
import * as Tasks from './features/tasks/state/tasks.actions';
import * as Users from './features/users/state/users.actions';
import * as Comments from './features/comments/state/comments.actions';
import { ProjectDetail } from './features/projects/components/project-detail/project-detail';
import { Overview } from './features/dashboard/components/overview/overview';
import { ProjectsList } from './features/projects/components/projects-list/projects-list';
import { MyTasks } from './features/tasks/components/my-tasks/my-tasks';
import { AdminUsers } from './features/users/components/admin-users/admin-users';
import { Profile } from './features/users/components/profile/profile';
import { ProjectForm } from './features/projects/components/project-form/project-form';
import { DashboardLayout } from './features/dashboard/components/dashboard-layout/dashboard-layout';
import { Home } from './features/public/components/home/home';

const page = <T,>(content: T[]) => ({ content, page: 0, size: 10, totalElements: content.length, totalPages: 1, last: true });
const flush = async (f: any) => { for (let i = 0; i < 4; i++) { await new Promise((r) => setTimeout(r, 5)); f.detectChanges(); } };

function setup(cmp: any, opts: { id?: string; query?: Record<string, string>; role?: any } = {}) {
  const query = new BehaviorSubject(convertToParamMap(opts.query ?? {}));
  TestBed.configureTestingModule({
    imports: [cmp],
    providers: [...provideTestEnv(), { provide: ActivatedRoute, useValue: { snapshot: { paramMap: convertToParamMap(opts.id ? { id: opts.id } : {}) }, queryParamMap: query } }],
  });
  const store = TestBed.inject(Store);
  store.dispatch(Auth.loginSuccess({ user: makeSession({ role: opts.role ?? 'PROJECT_MANAGER', userId: 2, name: 'Manu Manager' }) }));
  return { store, query };
}

describe('pages render with real data', () => {
  it('ProjectDetail: header, progress, kanban, then the task drawer', async () => {
    const { store, query } = setup(ProjectDetail, { id: '5' });
    const f = TestBed.createComponent(ProjectDetail);
    f.detectChanges();
    store.dispatch(Projects.loadProjectSuccess({ detail: makeDetail() }));
    store.dispatch(Tasks.loadBoardSuccess({ board: { projectId: 5, columns: { ...emptyColumns(), TODO: [makeTask({ id: 1, title: 'Write docs' }), makeTask({ id: 2, title: 'Fix bug', assigneeId: null })], DONE: [makeTask({ id: 3, status: 'DONE', title: 'Set up CI' })] } } }));
    await flush(f);
    const el = f.nativeElement as HTMLElement;
    expect(el.textContent).toContain('Website relaunch');
    expect(el.textContent).toContain('PRJ-ABC12345');
    expect(el.querySelectorAll('app-task-card').length).toBe(3);
    expect(el.textContent).toContain('33%');

    // open drawer via ?task=1
    query.next(convertToParamMap({ task: '1' }));
    store.dispatch(Tasks.loadTaskSuccess({ task: makeTask({ id: 1, title: 'Write docs' }) }));
    store.dispatch(Comments.loadCommentsSuccess({ taskId: 1, comments: [{ id: 1, taskId: 1, authorId: 2, authorName: 'Manu', content: 'Looks good', createdAt: '2026-10-28T10:00:00' }] }));
    store.dispatch(Comments.loadHistorySuccess({ taskId: 1, history: [{ id: 1, taskId: 1, action: 'CREATED', fieldName: 'task', oldValue: null, newValue: 'Write docs', changedById: 2, changedByName: 'Manu', changedAt: '2026-10-28T10:00:00' }] }));
    await flush(f);
    expect(el.querySelector('[role=dialog]')).toBeTruthy();
    expect(el.textContent).toContain('Looks good');
    expect(el.querySelector('app-task-detail select')).toBeTruthy(); // manager may change status
  });

  it('ProjectDetail as team member: cannot create or manage, only sees the board', async () => {
    const { store } = setup(ProjectDetail, { id: '5', role: 'TEAM_MEMBER' });
    store.dispatch(Auth.loginSuccess({ user: makeSession({ userId: 1, role: 'TEAM_MEMBER' }) }));
    const f = TestBed.createComponent(ProjectDetail);
    f.detectChanges();
    store.dispatch(Projects.loadProjectSuccess({ detail: makeDetail() }));
    store.dispatch(Tasks.loadBoardSuccess({ board: { projectId: 5, columns: emptyColumns() } }));
    await flush(f);
    const text = (f.nativeElement as HTMLElement).textContent!;
    expect(text).not.toContain('Edit project');
    expect(text).not.toContain('Archive');
  });

  it('ProjectDetail archived: read-only banner and no New task', async () => {
    const { store } = setup(ProjectDetail, { id: '5' });
    const f = TestBed.createComponent(ProjectDetail);
    f.detectChanges();
    store.dispatch(Projects.loadProjectSuccess({ detail: makeDetail({ status: 'ARCHIVED' }) }));
    store.dispatch(Tasks.loadBoardSuccess({ board: { projectId: 5, columns: emptyColumns() } }));
    await flush(f);
    const text = (f.nativeElement as HTMLElement).textContent!;
    expect(text).toContain('read-only');
    expect(text).not.toContain('New task');
  });

  it('Overview shows stats and projects', async () => {
    const { store } = setup(Overview);
    const f = TestBed.createComponent(Overview);
    f.detectChanges();
    store.dispatch(Tasks.loadMyTasksSuccess({ page: page([makeTask({ id: 1, overdue: true, dueDate: '2020-01-01' }), makeTask({ id: 2, status: 'DONE' })]) }));
    store.dispatch(Projects.loadProjectsSuccess({ page: page([makeProject()]) }));
    await flush(f);
    const text = (f.nativeElement as HTMLElement).textContent!;
    expect(text).toContain('Manu');
    expect(text).toContain('Website relaunch');
    expect(text).toContain('Design login');
  });

  it('ProjectsList / MyTasks / AdminUsers / Profile render rows', async () => {
    let s = setup(ProjectsList);
    let f = TestBed.createComponent(ProjectsList);
    f.detectChanges();
    s.store.dispatch(Projects.loadProjectsSuccess({ page: page([makeProject()]) }));
    await flush(f);
    expect((f.nativeElement as HTMLElement).querySelectorAll('app-project-card').length).toBe(1);
    TestBed.resetTestingModule();

    s = setup(MyTasks);
    f = TestBed.createComponent(MyTasks);
    f.detectChanges();
    s.store.dispatch(Tasks.loadMyTasksSuccess({ page: page([makeTask()]) }));
    await flush(f);
    expect((f.nativeElement as HTMLElement).textContent).toContain('Design login');
    TestBed.resetTestingModule();

    s = setup(AdminUsers, { role: 'ADMIN' });
    f = TestBed.createComponent(AdminUsers);
    f.detectChanges();
    s.store.dispatch(Users.loadUsersSuccess({ page: page([makeUser({ name: 'Zed Zebra' })]) }));
    await flush(f);
    expect((f.nativeElement as HTMLElement).textContent).toContain('Zed Zebra');
    TestBed.resetTestingModule();

    s = setup(Profile);
    f = TestBed.createComponent(Profile);
    f.detectChanges();
    s.store.dispatch(Users.loadProfileSuccess({ profile: makeUser({ name: 'Pat Profile' }) }));
    await flush(f);
    const input = (f.nativeElement as HTMLElement).querySelector('input[formControlName=name]') as HTMLInputElement;
    expect(input.value).toBe('Pat Profile');
  });

  it('ProjectForm (edit) pre-fills from the loaded project and blocks save until changed/valid', async () => {
    const { store } = setup(ProjectForm, { id: '5' });
    const f = TestBed.createComponent(ProjectForm);
    f.detectChanges();
    store.dispatch(Projects.loadProjectSuccess({ detail: makeDetail({ name: 'Alpha' }) }));
    await flush(f);
    const el = f.nativeElement as HTMLElement;
    expect((el.querySelector('input[formControlName=name]') as HTMLInputElement).value).toBe('Alpha');
    const name = el.querySelector('input[formControlName=name]') as HTMLInputElement;
    name.value = '   ';
    name.dispatchEvent(new Event('input'));
    f.detectChanges();
    expect((el.querySelector('button[type=submit]') as HTMLButtonElement).disabled).toBe(true);
    expect(el.querySelector('.field--invalid')).toBeTruthy();
  });

  it('DashboardLayout shows the role navigation', async () => {
    setup(DashboardLayout, { role: 'ADMIN' });
    const f = TestBed.createComponent(DashboardLayout);
    f.detectChanges();
    expect((f.nativeElement as HTMLElement).textContent).toContain('Users');
  });

  it('Home renders all sections', () => {
    TestBed.configureTestingModule({ imports: [Home], providers: provideTestEnv() });
    const f = TestBed.createComponent(Home);
    f.detectChanges();
    const text = (f.nativeElement as HTMLElement).textContent!;
    expect(text).toContain('Ship it together');
    expect(text).toContain('Who can do what');
    expect(text).toContain('Questions, answered');
  });
});
