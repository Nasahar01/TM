import { ApplicationConfig, provideBrowserGlobalErrorListeners, provideZoneChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideRouter, withInMemoryScrolling, withViewTransitions } from '@angular/router';
import { provideEffects } from '@ngrx/effects';
import { provideStore } from '@ngrx/store';

import { routes } from './app.routes';
import { authInterceptor } from './features/auth/interceptors/authInterceptor';
import { authReducer } from './features/auth/state/auth.reducer';
import { AuthEffects } from './features/auth/state/auth.effects';
import { usersReducer } from './features/users/state/users.reducer';
import { UsersEffects } from './features/users/state/users.effects';
import { projectsReducer } from './features/projects/state/projects.reducer';
import { ProjectsEffects } from './features/projects/state/projects.effects';
import { tasksReducer } from './features/tasks/state/tasks.reducer';
import { TasksEffects } from './features/tasks/state/tasks.effects';
import { commentsReducer } from './features/comments/state/comments.reducer';
import { CommentsEffects } from './features/comments/state/comments.effects';
import { uiReducer } from './state/ui/ui.reducer';
import { NotifyEffects } from './state/ui/notify.effects';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes, withViewTransitions(), withInMemoryScrolling({ scrollPositionRestoration: 'enabled', anchorScrolling: 'enabled' })),
    provideHttpClient(withInterceptors([authInterceptor])),
    provideStore({
      auth: authReducer,
      users: usersReducer,
      projects: projectsReducer,
      tasks: tasksReducer,
      comments: commentsReducer,
      ui: uiReducer,
    }),
    provideEffects([AuthEffects, UsersEffects, ProjectsEffects, TasksEffects, CommentsEffects, NotifyEffects]),
  ]
};
