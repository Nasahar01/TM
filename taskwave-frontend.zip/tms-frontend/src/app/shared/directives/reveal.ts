import { afterNextRender, Directive, ElementRef, inject, input, OnDestroy } from '@angular/core';

/** Fades and lifts an element in the first time it scrolls into view. Usage: <section appReveal [revealDelay]="120"> */
@Directive({ selector: '[appReveal]' })
export class Reveal implements OnDestroy {
  private el = inject<ElementRef<HTMLElement>>(ElementRef);
  revealDelay = input<number>(0);
  private observer?: IntersectionObserver;

  constructor() {
    afterNextRender(() => {
      const node = this.el.nativeElement;
      node.classList.add('reveal');
      node.style.transitionDelay = `${this.revealDelay()}ms`;
      if (typeof IntersectionObserver === 'undefined') {
        node.classList.add('in');
        return;
      }
      this.observer = new IntersectionObserver((entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            node.classList.add('in');
            this.observer?.disconnect();
          }
        }
      }, { threshold: 0.12 });
      this.observer.observe(node);
    });
  }

  ngOnDestroy(): void {
    this.observer?.disconnect();
  }
}
