import { afterNextRender, Directive, effect, ElementRef, inject, input, OnDestroy } from '@angular/core';

/** Animates a number from its previous value to the new one. Usage: <span [appCountUp]="42"></span> */
@Directive({ selector: '[appCountUp]' })
export class CountUp implements OnDestroy {
  private el = inject<ElementRef<HTMLElement>>(ElementRef);
  appCountUp = input<number>(0);
  suffix = input<string>('');
  private shown = 0;
  private raf = 0;
  private ready = false;

  constructor() {
    afterNextRender(() => { this.ready = true; this.run(this.appCountUp()); });
    effect(() => { const target = this.appCountUp(); if (this.ready) this.run(target); });
  }

  ngOnDestroy(): void {
    cancelAnimationFrame(this.raf);
  }

  private run(target: number): void {
    cancelAnimationFrame(this.raf);
    const from = this.shown;
    const start = performance.now();
    const duration = 900;
    const step = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 4);
      this.shown = Math.round(from + (target - from) * eased);
      this.el.nativeElement.textContent = `${this.shown}${this.suffix()}`;
      if (t < 1) this.raf = requestAnimationFrame(step);
    };
    this.raf = requestAnimationFrame(step);
  }
}
