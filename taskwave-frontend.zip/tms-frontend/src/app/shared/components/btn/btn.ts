import { Component, input } from '@angular/core';

/** Every action button in the app. It is blocked (disabled + spinner) while `loading` is true. */
@Component({
  selector: 'app-btn',
  templateUrl: './btn.html',
  styleUrl: './btn.css'
})
export class Btn {

  type = input<'button' | 'submit'>('button');
  variant = input<'primary' | 'soft' | 'ghost' | 'light' | 'danger'>('primary');
  size = input<'sm' | 'md' | 'lg'>('md');
  loading = input<boolean>(false);
  disabled = input<boolean>(false);
  block = input<boolean>(false);
  loadingText = input<string>('Loading…');

  classes(): string {
    return `btn btn-${this.variant()} btn-${this.size()}${this.block() ? ' btn-block' : ''}`;
  }
}
