import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Btn } from './btn';

describe('Btn', () => {
  let fixture: ComponentFixture<Btn>;
  const button = () => (fixture.nativeElement as HTMLElement).querySelector('button')!;

  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [Btn] }).compileComponents();
    fixture = TestBed.createComponent(Btn);
    fixture.detectChanges();
  });

  it('is enabled by default', () => {
    expect(button().disabled).toBe(false);
  });

  it('is blocked and shows a spinner while loading', () => {
    fixture.componentRef.setInput('loading', true);
    fixture.componentRef.setInput('loadingText', 'Saving…');
    fixture.detectChanges();
    expect(button().disabled).toBe(true);
    expect(button().querySelector('.spinner')).toBeTruthy();
    expect(button().textContent).toContain('Saving…');
  });

  it('is blocked when disabled (e.g. invalid form)', () => {
    fixture.componentRef.setInput('disabled', true);
    fixture.detectChanges();
    expect(button().disabled).toBe(true);
  });

  it('applies the variant and size classes', () => {
    fixture.componentRef.setInput('variant', 'danger');
    fixture.componentRef.setInput('size', 'sm');
    fixture.detectChanges();
    expect(button().className).toContain('btn-danger');
    expect(button().className).toContain('btn-sm');
  });
});
