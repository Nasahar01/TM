import { Component, computed, input, output } from '@angular/core';
import { Icon } from '../icon/icon';

/** Server-side pager: emits the new 0-based page index. */
@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.html',
  styleUrl: './pagination.css',
  imports: [Icon]
})
export class Pagination {

  page = input<number>(0);
  totalPages = input<number>(0);
  totalElements = input<number>(0);
  disabled = input<boolean>(false);
  pageChange = output<number>();

  pages = computed(() => {
    const total = this.totalPages();
    const current = this.page();
    const from = Math.max(0, Math.min(current - 2, total - 5));
    const to = Math.min(total, from + 5);
    return Array.from({ length: to - from }, (_, i) => from + i);
  });

  go(p: number): void {
    if (this.disabled() || p < 0 || p >= this.totalPages() || p === this.page()) return;
    this.pageChange.emit(p);
  }
}
