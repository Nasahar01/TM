import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Pagination } from './pagination';

describe('Pagination', () => {
  let fixture: ComponentFixture<Pagination>;
  const host = () => fixture.nativeElement as HTMLElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [Pagination] }).compileComponents();
    fixture = TestBed.createComponent(Pagination);
  });

  it('renders nothing for a single page', () => {
    fixture.componentRef.setInput('totalPages', 1);
    fixture.detectChanges();
    expect(host().querySelector('nav')).toBeNull();
  });

  it('emits the clicked page index (0-based)', () => {
    fixture.componentRef.setInput('totalPages', 4);
    fixture.componentRef.setInput('totalElements', 40);
    fixture.detectChanges();
    let emitted = -1;
    fixture.componentInstance.pageChange.subscribe((p) => (emitted = p));
    const buttons = Array.from(host().querySelectorAll('button.pg')) as HTMLButtonElement[];
    buttons.find((b) => b.textContent?.trim() === '3')!.click();
    expect(emitted).toBe(2);
  });

  it('blocks previous on the first page and everything while disabled', () => {
    fixture.componentRef.setInput('totalPages', 3);
    fixture.componentRef.setInput('disabled', true);
    fixture.detectChanges();
    const buttons = Array.from(host().querySelectorAll('button.pg')) as HTMLButtonElement[];
    expect(buttons.every((b) => b.disabled)).toBe(true);
  });
});
