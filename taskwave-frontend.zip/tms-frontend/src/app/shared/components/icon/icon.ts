import { Component, input } from '@angular/core';
import { ICONS } from './icons';

@Component({
  selector: 'app-icon',
  templateUrl: './icon.html',
  styleUrl: './icon.css'
})
export class Icon {

  name = input<string>('shield');
  size = input<number>(20);
  paths(): string[] {
    return ICONS[this.name()] ?? ICONS['shield'];
  }
}
