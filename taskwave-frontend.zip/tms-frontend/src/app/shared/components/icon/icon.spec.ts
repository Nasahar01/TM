import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../testing/test-env';
import { Icon } from './icon';

describe('Icon', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [Icon], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(Icon);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
