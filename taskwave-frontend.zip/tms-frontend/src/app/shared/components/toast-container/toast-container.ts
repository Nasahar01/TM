import { Component, inject } from '@angular/core';
import { Store } from '@ngrx/store';
import { dismissToast } from '../../../state/ui/ui.actions';
import { selectToasts } from '../../../state/ui/ui.selectors';
import { Icon } from '../icon/icon';

@Component({
  selector: 'app-toast-container',
  templateUrl: './toast-container.html',
  styleUrl: './toast-container.css',
  imports: [Icon]
})
export class ToastContainer {

  private store = inject(Store);
  toasts = this.store.selectSignal(selectToasts);

  dismiss(id: number): void {
    this.store.dispatch(dismissToast({ id }));
  }

  icon(kind: string): string {
    return kind === 'success' ? 'check' : kind === 'error' ? 'alert' : 'info';
  }
}
