import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../testing/test-env';
import { ToastContainer } from './toast-container';

describe('ToastContainer', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [ToastContainer], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(ToastContainer);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
