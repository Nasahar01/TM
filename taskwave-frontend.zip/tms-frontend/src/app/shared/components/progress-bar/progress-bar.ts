import { afterNextRender, Component, effect, input, signal } from '@angular/core';

/** Animated horizontal progress bar (0-100). The fill grows from 0 the first time it appears. */
@Component({
  selector: 'app-progress-bar',
  templateUrl: './progress-bar.html',
  styleUrl: './progress-bar.css'
})
export class ProgressBar {

  value = input<number>(0);
  label = input<string>('');
  shown = signal(0);
  private ready = false;

  constructor() {
    afterNextRender(() => {
      this.ready = true;
      requestAnimationFrame(() => this.shown.set(this.clamp(this.value())));
    });
    effect(() => {
      const v = this.clamp(this.value());
      if (this.ready) this.shown.set(v);
    });
  }

  private clamp(v: number): number {
    return Math.max(0, Math.min(100, v || 0));
  }
}
