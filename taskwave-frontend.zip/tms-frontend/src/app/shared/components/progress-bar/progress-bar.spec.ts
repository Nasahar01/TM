import { TestBed } from '@angular/core/testing';
import { ProgressBar } from './progress-bar';

describe('ProgressBar', () => {
  it('exposes the (clamped) value to assistive tech', async () => {
    TestBed.configureTestingModule({ imports: [ProgressBar] });
    const f = TestBed.createComponent(ProgressBar);
    f.componentRef.setInput('value', 140);
    f.detectChanges();
    await new Promise((r) => setTimeout(r, 50));
    f.detectChanges();
    expect(f.componentInstance.shown()).toBe(100);
  });
});
