import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../testing/test-env';
import { PageHeader } from './page-header';

describe('PageHeader', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [PageHeader], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(PageHeader);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
