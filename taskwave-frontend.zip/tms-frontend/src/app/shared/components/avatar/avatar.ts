import { Component, computed, input } from '@angular/core';
import { avatarColor, initialsOf } from '../../utils/format';

/** Round initials badge. Colour is derived from the user id so a person always looks the same. */
@Component({
  selector: 'app-avatar',
  templateUrl: './avatar.html',
  styleUrl: './avatar.css'
})
export class Avatar {

  name = input<string | null | undefined>('');
  seed = input<number | string | null | undefined>(null);
  size = input<number>(32);
  ring = input<boolean>(false);

  initials = computed(() => initialsOf(this.name()));
  color = computed(() => avatarColor(this.seed() ?? this.name()));
}
