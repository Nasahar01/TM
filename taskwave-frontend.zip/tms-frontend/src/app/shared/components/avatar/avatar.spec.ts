import { TestBed } from '@angular/core/testing';
import { Avatar } from './avatar';

describe('Avatar', () => {
  it('shows initials', () => {
    TestBed.configureTestingModule({ imports: [Avatar] });
    const f = TestBed.createComponent(Avatar);
    f.componentRef.setInput('name', 'Asha Rao');
    f.detectChanges();
    expect((f.nativeElement as HTMLElement).textContent?.trim()).toBe('AR');
  });
});
