import { Component, input } from '@angular/core';
import { Icon } from '../icon/icon';

@Component({
  selector: 'app-empty-state',
  templateUrl: './empty-state.html',
  styleUrl: './empty-state.css',
  imports: [Icon]
})
export class EmptyState {

  icon = input<string>('folder');
  title = input<string>('Nothing here yet');
  text = input<string>('');
}
