import { Component, effect, HostListener, input, output, signal } from '@angular/core';
import { Icon } from '../icon/icon';

/**
 * Dialog or right-hand drawer. It stays in the DOM for the length of the closing animation,
 * so it slides/scales out as smoothly as it came in.
 */
@Component({
  selector: 'app-modal',
  templateUrl: './modal.html',
  styleUrl: './modal.css',
  imports: [Icon]
})
export class Modal {

  open = input<boolean>(false);
  title = input<string>('');
  subtitle = input<string>('');
  mode = input<'modal' | 'drawer'>('modal');
  wide = input<boolean>(false);
  closed = output<void>();

  rendered = signal(false);
  leaving = signal(false);
  private timer?: ReturnType<typeof setTimeout>;

  constructor() {
    effect(() => {
      if (this.open()) {
        clearTimeout(this.timer);
        this.leaving.set(false);
        this.rendered.set(true);
      } else if (this.rendered()) {
        this.leaving.set(true);
        this.timer = setTimeout(() => {
          this.rendered.set(false);
          this.leaving.set(false);
        }, 320);
      }
    });
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    if (this.open()) this.closed.emit();
  }
}
