import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { Modal } from './modal';

describe('Modal', () => {
  beforeEach(() => TestBed.configureTestingModule({ imports: [Modal] }));

  it('renders only while open, and stays for the closing animation', fakeAsync(() => {
    const f = TestBed.createComponent(Modal);
    const host = f.nativeElement as HTMLElement;
    f.detectChanges();
    expect(host.querySelector('[role=dialog]')).toBeNull();

    f.componentRef.setInput('open', true);
    f.detectChanges();
    tick();
    f.detectChanges();
    expect(host.querySelector('[role=dialog]')).toBeTruthy();

    f.componentRef.setInput('open', false);
    f.detectChanges();
    tick();
    f.detectChanges();
    expect(host.querySelector('.leaving')).toBeTruthy();
    tick(400);
    f.detectChanges();
    expect(host.querySelector('[role=dialog]')).toBeNull();
  }));

  it('emits closed on Escape', () => {
    const f = TestBed.createComponent(Modal);
    f.componentRef.setInput('open', true);
    f.detectChanges();
    let closed = false;
    f.componentInstance.closed.subscribe(() => (closed = true));
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
    expect(closed).toBe(true);
  });
});
