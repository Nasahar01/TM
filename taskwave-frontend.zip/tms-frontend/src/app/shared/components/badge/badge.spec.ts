import { TestBed } from '@angular/core/testing';
import { Badge } from './badge';

describe('Badge', () => {
  const make = (value: string) => {
    const f = TestBed.createComponent(Badge);
    f.componentRef.setInput('value', value);
    f.detectChanges();
    return f.nativeElement as HTMLElement;
  };

  beforeEach(() => TestBed.configureTestingModule({ imports: [Badge] }));

  it('prettifies the label', () => {
    expect(make('IN_PROGRESS').textContent).toContain('In Progress');
  });

  it('picks a tone per value', () => {
    expect(make('DONE').querySelector('.badge-green')).toBeTruthy();
    expect(make('CRITICAL').querySelector('.badge-red')).toBeTruthy();
    expect(make('IN_REVIEW').querySelector('.badge-amber')).toBeTruthy();
  });
});
