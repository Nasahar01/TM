import { Component, input } from '@angular/core';
import { pretty } from '../../utils/format';

/** Coloured pill for any status / priority / role value. */
@Component({
  selector: 'app-badge',
  templateUrl: './badge.html',
  styleUrl: './badge.css'
})
export class Badge {

  value = input<string | null | undefined>('');

  label(): string {
    return pretty(String(this.value() ?? ''));
  }

  tone(): string {
    const v = String(this.value() ?? '').toUpperCase();
    if (['DONE', 'COMPLETED', 'LOW', 'TRUE', 'ACTIVE_USER'].includes(v)) return 'badge-green';
    if (['ACTIVE', 'IN_PROGRESS', 'MEDIUM', 'PROJECT_MANAGER', 'CREATED'].includes(v)) return 'badge-blue';
    if (['PLANNING', 'IN_REVIEW', 'HIGH', 'ON_HOLD', 'DETAILS_UPDATED'].includes(v)) return 'badge-amber';
    if (['CRITICAL', 'INACTIVE', 'FALSE', 'ADMIN'].includes(v)) return 'badge-red';
    if (['STATUS_CHANGED', 'TEAM_MEMBER'].includes(v)) return 'badge-teal';
    if (['ASSIGNEE_CHANGED'].includes(v)) return 'badge-pink';
    return 'badge-grey';
  }
}
