import { Component, input } from '@angular/core';
import { AbstractControl, Validators } from '@angular/forms';
import { defaultMessage } from '../../utils/validators';

/** Label + input wrapper. Turns red as soon as a wrong value is typed (dirty) or the field was left (touched). */
@Component({
  selector: 'app-field',
  templateUrl: './field.html',
  styleUrl: './field.css'
})
export class Field {

  label = input<string>('');
  hint = input<string>('');
  control = input.required<AbstractControl>();
  messages = input<Record<string, string>>({});

  invalid(): boolean {
    const c = this.control();
    return c.invalid && (c.dirty || c.touched);
  }

  required(): boolean {
    return this.control().hasValidator(Validators.required);
  }

  message(): string {
    const errors = this.control().errors;
    if (!errors) return '';
    const key = Object.keys(errors)[0];
    return this.messages()[key] ?? defaultMessage(key, errors[key]);
  }
}
