import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, Validators } from '@angular/forms';
import { Field } from './field';

describe('Field', () => {
  let fixture: ComponentFixture<Field>;
  let control: FormControl<string | null>;
  const host = () => fixture.nativeElement as HTMLElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [Field] }).compileComponents();
    control = new FormControl('', [Validators.required, Validators.minLength(3)]);
    fixture = TestBed.createComponent(Field);
    fixture.componentRef.setInput('control', control);
    fixture.componentRef.setInput('label', 'Name');
    fixture.detectChanges();
  });

  it('shows no error on a pristine, untouched field', () => {
    expect(host().querySelector('.field--invalid')).toBeNull();
    expect(host().querySelector('.field-error')).toBeNull();
  });

  it('turns red once the field was touched while wrong', () => {
    control.markAsTouched();
    fixture.detectChanges();
    expect(host().querySelector('.field--invalid')).toBeTruthy();
    expect(host().querySelector('.field-error')?.textContent).toContain('required');
  });

  it('turns red as soon as a wrong value is typed (dirty)', () => {
    control.setValue('ab');
    control.markAsDirty();
    fixture.detectChanges();
    expect(host().querySelector('.field-error')?.textContent).toContain('at least 3');
  });

  it('goes back to normal when the value becomes valid', () => {
    control.markAsTouched();
    control.setValue('Asha');
    fixture.detectChanges();
    expect(host().querySelector('.field--invalid')).toBeNull();
  });

  it('shows a star for required controls and uses custom messages', () => {
    expect(host().querySelector('.req')).toBeTruthy();
    fixture.componentRef.setInput('messages', { required: 'Please give a name.' });
    control.markAsTouched();
    fixture.detectChanges();
    expect(host().querySelector('.field-error')?.textContent).toContain('Please give a name.');
  });
});
