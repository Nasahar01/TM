import { Component } from '@angular/core';

/** Fixed, pointer-less page background: drifting aurora blobs, a dot grid and slowly rising task cards. */
@Component({
  selector: 'app-animated-bg',
  templateUrl: './animated-bg.html',
  styleUrl: './animated-bg.css'
})
export class AnimatedBg {

  cards = [1, 2, 3, 4, 5, 6];
}
