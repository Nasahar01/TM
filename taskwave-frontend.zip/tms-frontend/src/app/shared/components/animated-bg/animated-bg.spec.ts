import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../testing/test-env';
import { AnimatedBg } from './animated-bg';

describe('AnimatedBg', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [AnimatedBg], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(AnimatedBg);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
