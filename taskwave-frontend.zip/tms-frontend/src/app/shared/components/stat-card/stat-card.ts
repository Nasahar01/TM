import { Component, input } from '@angular/core';
import { Icon } from '../icon/icon';
import { CountUp } from '../../directives/count-up';

@Component({
  selector: 'app-stat-card',
  templateUrl: './stat-card.html',
  styleUrl: './stat-card.css',
  imports: [Icon, CountUp]
})
export class StatCard {

  label = input<string>('');
  value = input<number>(0);
  suffix = input<string>('');
  icon = input<string>('chart');
  hint = input<string>('');
  tone = input<'brand' | 'mint' | 'sun' | 'coral' | 'sky'>('brand');
}
