import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../testing/test-env';
import { StatCard } from './stat-card';

describe('StatCard', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [StatCard], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(StatCard);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
