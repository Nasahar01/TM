import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../testing/test-env';
import { Loading } from './loading';

describe('Loading', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [Loading], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(Loading);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
