/** Server-side pagination envelope returned by every list endpoint (PageResponse<T> in the backend). */
export interface Page<T> {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
  last: boolean;
}

export const emptyPage = <T>(): Page<T> => ({ content: [], page: 0, size: 0, totalElements: 0, totalPages: 0, last: true });
