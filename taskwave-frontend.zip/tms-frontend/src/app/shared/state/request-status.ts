import { HttpErrorResponse } from '@angular/common/http';

/** Every effect waits this long so the "Loading…" state is visible. */
export const LOADING_DELAY = 1000;

/** Status of one async action (load / create / update ...). */
export interface RequestStatus {
  loading: boolean;
  success: boolean;
  error: string;
  /** id of the row being acted on, so only that row shows a spinner */
  target: number | null;
}

export const idleStatus: RequestStatus = { loading: false, success: false, error: '', target: null };
export const pending = (target: number | null = null): RequestStatus => ({ loading: true, success: false, error: '', target });
export const succeeded = (): RequestStatus => ({ loading: false, success: true, error: '', target: null });
export const failed = (error: string): RequestStatus => ({ loading: false, success: false, error, target: null });

/**
 * Turns anything thrown by HttpClient into a readable message.
 * The backend always answers with { timestamp, status, error, message, path, fieldErrors? }.
 */
export function toMessage(err: unknown): string {
  if (err instanceof HttpErrorResponse) {
    if (err.status === 0) return 'Cannot reach the server. Make sure the API gateway is running on port 8080.';
    const body = err.error;
    if (typeof body === 'string' && body.trim()) return body;
    if (body && typeof body === 'object') {
      const fields = body.fieldErrors as Record<string, string> | undefined;
      if (fields && Object.keys(fields).length) return Object.values(fields).join(' ');
      const text = body.message ?? body.error ?? body.detail;
      if (typeof text === 'string' && text.trim()) return text;
    }
    if (err.status === 401) return 'Your session has expired. Please sign in again.';
    if (err.status === 403) return 'You do not have permission to do that.';
    if (err.status === 404) return 'We could not find what you asked for.';
    if (err.status === 429) return 'Too many attempts. Please wait a moment and try again.';
    if (err.status === 400) return 'Some of the details were not accepted. Please check and retry.';
    if (err.status === 503) return 'A service is temporarily unavailable. Please retry shortly.';
    return `Something went wrong (${err.status}). Please try again.`;
  }
  if (err instanceof Error) return err.message;
  return 'Something went wrong. Please try again.';
}
