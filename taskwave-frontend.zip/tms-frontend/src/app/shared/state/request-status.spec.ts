import { HttpErrorResponse } from '@angular/common/http';
import { failed, idleStatus, pending, succeeded, toMessage } from './request-status';

describe('request-status', () => {
  it('builds the four states', () => {
    expect(idleStatus).toEqual({ loading: false, success: false, error: '', target: null });
    expect(pending(4)).toEqual({ loading: true, success: false, error: '', target: 4 });
    expect(succeeded().success).toBe(true);
    expect(failed('boom').error).toBe('boom');
  });

  it('toMessage prefers the backend message', () => {
    expect(toMessage(new HttpErrorResponse({ status: 400, error: { message: 'Title is required' } }))).toBe('Title is required');
  });

  it('toMessage joins field errors', () => {
    const err = new HttpErrorResponse({ status: 400, error: { fieldErrors: { title: 'Title is required', name: 'Name is required' } } });
    expect(toMessage(err)).toBe('Title is required Name is required');
  });

  it('toMessage explains an unreachable server and common statuses', () => {
    expect(toMessage(new HttpErrorResponse({ status: 0 }))).toContain('Cannot reach the server');
    expect(toMessage(new HttpErrorResponse({ status: 403 }))).toContain('permission');
    expect(toMessage(new HttpErrorResponse({ status: 404 }))).toContain('could not find');
    expect(toMessage(new HttpErrorResponse({ status: 429 }))).toContain('Too many');
  });

  it('toMessage handles plain errors', () => {
    expect(toMessage(new Error('custom'))).toBe('custom');
    expect(toMessage(42)).toContain('Something went wrong');
  });
});
