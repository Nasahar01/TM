/** Small formatting helpers shared by templates. */
export function pretty(value: string | null | undefined): string {
  return (value ?? '').toLowerCase().split('_').filter(Boolean).map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

export function todayIso(): string {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

/** 2026-10-28 -> 28 Oct 2026 */
export function fmtDate(value: string | null | undefined): string {
  if (!value) return '—';
  const d = new Date(value.length <= 10 ? `${value}T00:00:00` : value);
  return isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

/** 28 Oct 2026, 14:05 */
export function fmtDateTime(value: string | null | undefined): string {
  if (!value) return '—';
  const d = new Date(value);
  return isNaN(d.getTime())
    ? '—'
    : `${d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}, ${d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`;
}

/** "5 min ago", "2 d ago" - the task update timestamps shown in discussions. */
export function timeAgo(value: string | null | undefined, now: number = Date.now()): string {
  if (!value) return '';
  const diff = Math.round((now - new Date(value).getTime()) / 1000);
  if (isNaN(diff)) return '';
  if (diff < 45) return 'just now';
  if (diff < 3600) return `${Math.round(diff / 60)} min ago`;
  if (diff < 86400) return `${Math.round(diff / 3600)} h ago`;
  if (diff < 86400 * 7) return `${Math.round(diff / 86400)} d ago`;
  return fmtDate(value.slice(0, 10));
}

export function initialsOf(name: string | null | undefined): string {
  return (name ?? '').split(' ').filter(Boolean).map((p) => p.charAt(0)).join('').slice(0, 2).toUpperCase() || '?';
}

/** Stable colour per user id so avatars stay recognisable. */
export function avatarColor(seed: number | string | null | undefined): string {
  const palette = ['#6a43f5', '#14c8a0', '#3aa8ff', '#ff6277', '#ffb429', '#b24bff', '#0fa3b1', '#e85d9a'];
  const n = typeof seed === 'number' ? seed : String(seed ?? '').split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  return palette[Math.abs(n) % palette.length];
}

export function percent(done: number, total: number): number {
  return total ? Math.round((done * 100) / total) : 0;
}
