import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { todayIso } from './format';

/** Blank strings (only spaces) count as missing. */
export const notBlank: ValidatorFn = (c: AbstractControl): ValidationErrors | null =>
  typeof c.value === 'string' && c.value.length > 0 && c.value.trim().length === 0 ? { blank: true } : null;

/** Backend: phone is @Size(max=20); we additionally require a plausible number when filled. */
export const phone: ValidatorFn = (c) => {
  const v = String(c.value ?? '');
  return !v || /^\+?[0-9][0-9\s-]{6,17}$/.test(v) ? null : { phone: true };
};

/** Backend password rule is 8-64 characters; we also ask for letters and numbers. */
export const strongPassword: ValidatorFn = (c) => {
  const v = String(c.value ?? '');
  if (!v) return null;
  return /[A-Za-z]/.test(v) && /\d/.test(v) ? null : { weakPassword: true };
};

export const todayOrLater: ValidatorFn = (c) => {
  const v = String(c.value ?? '');
  return !v || v >= todayIso() ? null : { pastDate: true };
};

/** Put on the END date control; compares against the sibling control named `startKey`. */
export const onOrAfter = (startKey: string): ValidatorFn => (c) => {
  const start = c.parent?.get(startKey)?.value as string | undefined;
  const end = c.value as string | undefined;
  return !start || !end || end >= start ? null : { dateOrder: true };
};

/** Put on a "confirm" control; compares against the sibling named `otherKey`. */
export const matches = (otherKey: string): ValidatorFn => (c) => {
  const other = c.parent?.get(otherKey)?.value;
  return c.value === other ? null : { mismatch: true };
};

/** The new password must differ from the current one. */
export const differsFrom = (otherKey: string): ValidatorFn => (c) => {
  const other = c.parent?.get(otherKey)?.value;
  return !c.value || c.value !== other ? null : { same: true };
};

export function defaultMessage(key: string, detail: any): string {
  switch (key) {
    case 'required': return 'This field is required.';
    case 'blank': return 'This field cannot be only spaces.';
    case 'email': return 'Enter a valid email address.';
    case 'minlength': return `Must be at least ${detail.requiredLength} characters.`;
    case 'maxlength': return `Must be at most ${detail.requiredLength} characters.`;
    case 'min': return `Must be at least ${detail.min}.`;
    case 'max': return `Must be at most ${detail.max}.`;
    case 'pattern': return 'This value is not in the expected format.';
    case 'phone': return 'Enter a valid phone number (digits, optional +).';
    case 'weakPassword': return 'Use both letters and numbers.';
    case 'pastDate': return 'Date cannot be in the past.';
    case 'dateOrder': return 'End date must be on or after the start date.';
    case 'mismatch': return 'The two values do not match.';
    case 'same': return 'The new password must be different from the current one.';
    default: return 'This value is not valid.';
  }
}
