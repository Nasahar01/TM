import { avatarColor, fmtDate, initialsOf, percent, pretty, timeAgo, todayIso } from './format';

describe('format helpers', () => {
  it('pretty turns enum values into words', () => {
    expect(pretty('IN_PROGRESS')).toBe('In Progress');
    expect(pretty('PROJECT_MANAGER')).toBe('Project Manager');
    expect(pretty(null)).toBe('');
  });

  it('fmtDate formats dates and tolerates empty values', () => {
    expect(fmtDate('2026-10-28')).toContain('2026');
    expect(fmtDate(null)).toBe('—');
    expect(fmtDate('not a date')).toBe('—');
  });

  it('initialsOf takes at most two letters', () => {
    expect(initialsOf('Asha Rao Kumar')).toBe('AR');
    expect(initialsOf('')).toBe('?');
  });

  it('percent never divides by zero', () => {
    expect(percent(1, 4)).toBe(25);
    expect(percent(0, 0)).toBe(0);
  });

  it('timeAgo is relative for recent times', () => {
    const now = new Date('2026-10-28T12:00:00Z').getTime();
    expect(timeAgo('2026-10-28T11:59:50Z', now)).toBe('just now');
    expect(timeAgo('2026-10-28T11:30:00Z', now)).toBe('30 min ago');
    expect(timeAgo('2026-10-28T09:00:00Z', now)).toBe('3 h ago');
    expect(timeAgo('2026-10-26T12:00:00Z', now)).toBe('2 d ago');
  });

  it('avatarColor is stable for the same seed', () => {
    expect(avatarColor(7)).toBe(avatarColor(7));
  });

  it('todayIso looks like an ISO date', () => {
    expect(todayIso()).toMatch(/^\d{4}-\d{2}-\d{2}$/);
  });
});
