import { FormControl, FormGroup } from '@angular/forms';
import { defaultMessage, differsFrom, matches, notBlank, onOrAfter, phone, strongPassword, todayOrLater } from './validators';
import { todayIso } from './format';

describe('validators', () => {
  it('notBlank rejects only-space strings but accepts empty (required handles that)', () => {
    expect(notBlank(new FormControl('   '))).toEqual({ blank: true });
    expect(notBlank(new FormControl(''))).toBeNull();
    expect(notBlank(new FormControl('Design'))).toBeNull();
  });

  it('phone accepts plausible numbers and rejects junk', () => {
    expect(phone(new FormControl('+91 98765 43210'))).toBeNull();
    expect(phone(new FormControl(''))).toBeNull();
    expect(phone(new FormControl('abc'))).toEqual({ phone: true });
    expect(phone(new FormControl('123'))).toEqual({ phone: true });
  });

  it('strongPassword needs letters and numbers', () => {
    expect(strongPassword(new FormControl('abcdefgh'))).toEqual({ weakPassword: true });
    expect(strongPassword(new FormControl('12345678'))).toEqual({ weakPassword: true });
    expect(strongPassword(new FormControl('Abcdef12'))).toBeNull();
  });

  it('todayOrLater blocks past dates', () => {
    expect(todayOrLater(new FormControl('2000-01-01'))).toEqual({ pastDate: true });
    expect(todayOrLater(new FormControl(todayIso()))).toBeNull();
    expect(todayOrLater(new FormControl(''))).toBeNull();
  });

  it('onOrAfter compares the end date with the sibling start date', () => {
    const form = new FormGroup({ start: new FormControl('2026-10-10'), end: new FormControl('2026-10-01', [onOrAfter('start')]) });
    form.controls.end.updateValueAndValidity(); // sibling is only reachable once the control is in the group
    expect(form.controls.end.errors).toEqual({ dateOrder: true });
    form.controls.end.setValue('2026-10-10');
    expect(form.controls.end.errors).toBeNull();
  });

  it('matches and differsFrom compare sibling controls', () => {
    const form = new FormGroup({
      current: new FormControl('Old12345'),
      next: new FormControl('Old12345', [differsFrom('current')]),
      confirm: new FormControl('x', [matches('next')]),
    });
    form.controls.next.updateValueAndValidity();
    form.controls.confirm.updateValueAndValidity();
    expect(form.controls.next.errors).toEqual({ same: true });
    expect(form.controls.confirm.errors).toEqual({ mismatch: true });
    form.controls.next.setValue('New12345');
    form.controls.confirm.setValue('New12345');
    expect(form.controls.next.errors).toBeNull();
    expect(form.controls.confirm.errors).toBeNull();
  });

  it('defaultMessage explains each rule in words', () => {
    expect(defaultMessage('required', true)).toContain('required');
    expect(defaultMessage('minlength', { requiredLength: 8 })).toContain('8');
    expect(defaultMessage('dateOrder', true)).toContain('End date');
  });
});
