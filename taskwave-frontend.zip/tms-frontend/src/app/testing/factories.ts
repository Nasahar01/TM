import { CurrentUser } from '../features/auth/entities/current-user.entity';
import { Member, Project, ProjectDetail } from '../features/projects/entities/project.entity';
import { Task } from '../features/tasks/entities/task.entity';
import { User } from '../features/users/entities/user.entity';

export const makeUser = (o: Partial<User> = {}): User => ({
  id: 1, name: 'Asha Rao', email: 'asha@tms.com', role: 'TEAM_MEMBER', phone: null, department: null, active: true,
  createdAt: '2026-10-01T10:00:00', updatedAt: '2026-10-01T10:00:00', ...o,
});

export const makeSession = (o: Partial<CurrentUser> = {}): CurrentUser => ({ userId: 1, name: 'Asha Rao', email: 'asha@tms.com', role: 'TEAM_MEMBER', ...o });

export const makeTask = (o: Partial<Task> = {}): Task => ({
  id: 10, projectId: 5, title: 'Design login', description: null, priority: 'MEDIUM', status: 'TODO', assigneeId: 1, createdById: 2,
  createdByName: 'Manu Manager', dueDate: null, overdue: false, completedAt: null, createdAt: '2026-10-01T10:00:00', updatedAt: '2026-10-01T10:00:00', ...o,
});

export const makeProject = (o: Partial<Project> = {}): Project => ({
  id: 5, projectCode: 'PRJ-ABC12345', name: 'Website relaunch', description: null, startDate: '2026-10-01', endDate: null, status: 'ACTIVE',
  managerId: 2, managerName: 'Manu Manager', memberCount: 2, createdAt: '2026-10-01T10:00:00', updatedAt: '2026-10-01T10:00:00', ...o,
});

export const makeMember = (o: Partial<Member> = {}): Member => ({ userId: 1, name: 'Asha Rao', email: 'asha@tms.com', role: 'TEAM_MEMBER', addedAt: '2026-10-01T10:00:00', ...o });

export const makeDetail = (o: Partial<Project> = {}, members: Member[] = [makeMember(), makeMember({ userId: 2, name: 'Manu Manager', role: 'PROJECT_MANAGER' })]): ProjectDetail => ({
  project: makeProject(o),
  members,
  progress: { projectId: 5, total: 0, todo: 0, inProgress: 0, inReview: 0, done: 0, overdue: 0, completionPercentage: 0, available: true },
});
