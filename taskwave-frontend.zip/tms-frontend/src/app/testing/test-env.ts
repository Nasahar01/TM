import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { provideRouter } from '@angular/router';
import { provideEffects } from '@ngrx/effects';
import { provideStore } from '@ngrx/store';
import { authReducer } from '../features/auth/state/auth.reducer';
import { commentsReducer } from '../features/comments/state/comments.reducer';
import { projectsReducer } from '../features/projects/state/projects.reducer';
import { tasksReducer } from '../features/tasks/state/tasks.reducer';
import { usersReducer } from '../features/users/state/users.reducer';
import { uiReducer } from '../state/ui/ui.reducer';

/** Providers for component specs: real reducers, no effects running, a mocked HTTP layer and an empty router. */
export function provideTestEnv() {
  return [
    provideHttpClient(),
    provideHttpClientTesting(),
    provideRouter([]),
    provideStore({ auth: authReducer, users: usersReducer, projects: projectsReducer, tasks: tasksReducer, comments: commentsReducer, ui: uiReducer }),
    provideEffects([]),
  ];
}
