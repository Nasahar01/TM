import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from './testing/test-env';
import { App } from './app';

describe('App', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [App], providers: provideTestEnv() }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(App);
    expect(fixture.componentInstance).toBeTruthy();
  });

  it('should render the background and the router outlet', () => {
    const fixture = TestBed.createComponent(App);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('app-animated-bg')).toBeTruthy();
    expect(el.querySelector('router-outlet')).toBeTruthy();
  });
});
