import { HttpClient, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { API_URL } from '../../../core/config/api.config';
import { Page } from '../../../shared/entities/page.entity';
import { AssignTaskRequestDTO } from '../dtos/AssignTaskRequestDTO';
import { CreateTaskRequestDTO } from '../dtos/CreateTaskRequestDTO';
import { TaskQueryDTO } from '../dtos/TaskQueryDTO';
import { UpdateStatusRequestDTO } from '../dtos/UpdateStatusRequestDTO';
import { UpdateTaskRequestDTO } from '../dtos/UpdateTaskRequestDTO';
import { KanbanBoard, Task, TaskSummary } from '../entities/task.entity';

function toParams(query: TaskQueryDTO): HttpParams {
  let params = new HttpParams().set('page', query.page).set('size', query.size);
  if (query.status) params = params.set('status', query.status);
  if (query.priority) params = params.set('priority', query.priority);
  if (query.assigneeId !== undefined && query.assigneeId !== null) params = params.set('assigneeId', query.assigneeId);
  if (query.q?.trim()) params = params.set('q', query.q.trim());
  if (query.sort) params = params.set('sort', query.sort);
  return params;
}

@Injectable({ providedIn: 'root' })
export class TaskService {
  private http = inject(HttpClient);
  private api = inject(API_URL);

  createTask(dto: CreateTaskRequestDTO): Observable<Task> {
    return this.http.post<Task>(`${this.api}/tasks`, dto);
  }

  getMyTasks(query: TaskQueryDTO): Observable<Page<Task>> {
    return this.http.get<Page<Task>>(`${this.api}/tasks/my`, { params: toParams(query) });
  }

  getTasksByProject(projectId: number, query: TaskQueryDTO): Observable<Page<Task>> {
    return this.http.get<Page<Task>>(`${this.api}/tasks/project/${projectId}`, { params: toParams(query) });
  }

  getBoard(projectId: number): Observable<KanbanBoard> {
    return this.http.get<KanbanBoard>(`${this.api}/tasks/project/${projectId}/board`);
  }

  getProjectSummary(projectId: number): Observable<TaskSummary> {
    return this.http.get<TaskSummary>(`${this.api}/tasks/project/${projectId}/summary`);
  }

  getTaskById(taskId: number): Observable<Task> {
    return this.http.get<Task>(`${this.api}/tasks/${taskId}`);
  }

  updateTask(taskId: number, dto: UpdateTaskRequestDTO): Observable<Task> {
    return this.http.put<Task>(`${this.api}/tasks/${taskId}`, dto);
  }

  /** Completed tasks stay in the project history and cannot be deleted (400). */
  deleteTask(taskId: number): Observable<void> {
    return this.http.delete<void>(`${this.api}/tasks/${taskId}`);
  }

  updateStatus(taskId: number, status: UpdateStatusRequestDTO['status']): Observable<Task> {
    const body: UpdateStatusRequestDTO = { status };
    return this.http.patch<Task>(`${this.api}/tasks/${taskId}/status`, body);
  }

  assignTask(taskId: number, assigneeId: number | null): Observable<Task> {
    const body: AssignTaskRequestDTO = { assigneeId };
    return this.http.put<Task>(`${this.api}/tasks/${taskId}/assignee`, body);
  }
}
