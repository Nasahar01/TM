import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { API_URL } from '../../../core/config/api.config';
import { TaskService } from './task-service';

describe('TaskService', () => {
  let service: TaskService;
  let http: HttpTestingController;
  let api: string;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    service = TestBed.inject(TaskService);
    http = TestBed.inject(HttpTestingController);
    api = TestBed.inject(API_URL);
  });

  afterEach(() => http.verify());

  it('creates a task with POST /tasks', () => {
    const dto = { projectId: 5, title: 'T', description: null, priority: 'HIGH' as const, dueDate: null, assigneeId: 1 };
    service.createTask(dto).subscribe();
    const req = http.expectOne(`${api}/tasks`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(dto);
    req.flush({});
  });

  it('lists my tasks with paging, filter and sort params', () => {
    service.getMyTasks({ status: 'TODO', page: 1, size: 8, sort: 'dueDate,asc' }).subscribe();
    const req = http.expectOne((r) => r.url === `${api}/tasks/my`);
    expect(req.request.params.get('status')).toBe('TODO');
    expect(req.request.params.get('page')).toBe('1');
    expect(req.request.params.get('size')).toBe('8');
    expect(req.request.params.get('sort')).toBe('dueDate,asc');
    req.flush({});
  });

  it('leaves empty filters out of the query string', () => {
    service.getTasksByProject(5, { q: '  ', page: 0, size: 10 }).subscribe();
    const req = http.expectOne((r) => r.url === `${api}/tasks/project/5`);
    expect(req.request.params.has('q')).toBe(false);
    expect(req.request.params.has('status')).toBe(false);
    req.flush({});
  });

  it('filters a project list by assignee id', () => {
    service.getTasksByProject(5, { assigneeId: 3, priority: 'HIGH', page: 0, size: 10 }).subscribe();
    const req = http.expectOne((r) => r.url === `${api}/tasks/project/5`);
    expect(req.request.params.get('assigneeId')).toBe('3');
    expect(req.request.params.get('priority')).toBe('HIGH');
    req.flush({});
  });

  it('reads the board and the summary of a project', () => {
    service.getBoard(5).subscribe();
    http.expectOne(`${api}/tasks/project/5/board`).flush({});
    service.getProjectSummary(5).subscribe();
    http.expectOne(`${api}/tasks/project/5/summary`).flush({});
  });

  it('changes status with PATCH /tasks/{id}/status', () => {
    service.updateStatus(10, 'DONE').subscribe();
    const req = http.expectOne(`${api}/tasks/10/status`);
    expect(req.request.method).toBe('PATCH');
    expect(req.request.body).toEqual({ status: 'DONE' });
    req.flush({});
  });

  it('assigns and un-assigns with PUT /tasks/{id}/assignee', () => {
    service.assignTask(10, null).subscribe();
    const req = http.expectOne(`${api}/tasks/10/assignee`);
    expect(req.request.method).toBe('PUT');
    expect(req.request.body).toEqual({ assigneeId: null });
    req.flush({});
  });

  it('updates and deletes a task', () => {
    service.updateTask(10, { title: 'X', description: null, priority: 'LOW', dueDate: null }).subscribe();
    expect(http.expectOne(`${api}/tasks/10`).request.method).toBe('PUT');
    service.deleteTask(10).subscribe();
    const del = http.expectOne(`${api}/tasks/10`);
    expect(del.request.method).toBe('DELETE');
    del.flush(null);
  });
});
