import { createReducer, on } from '@ngrx/store';
import { TaskStatus } from '../../../core/config/task-meta';
import { failed, idleStatus, pending, succeeded } from '../../../shared/state/request-status';
import { emptyColumns, KanbanBoard, Task } from '../entities/task.entity';
import { initialTasksState, TasksState } from './tasks.state';
import * as TasksActions from './tasks.actions';
import * as AuthActions from '../../auth/state/auth.actions';

const withoutTask = (columns: KanbanBoard['columns'], taskId: number): KanbanBoard['columns'] => {
  const next = emptyColumns();
  (Object.keys(next) as TaskStatus[]).forEach((s) => (next[s] = (columns[s] ?? []).filter((t) => t.id !== taskId)));
  return next;
};

/** Puts a task (new or changed) on top of its column, like the server's "updated last first" ordering. */
const placeOnBoard = (board: KanbanBoard | null, task: Task): KanbanBoard | null => {
  if (!board || board.projectId !== task.projectId) return board;
  const columns = withoutTask(board.columns, task.id);
  columns[task.status] = [task, ...columns[task.status]];
  return { ...board, columns };
};

const swapInPage = (page: TasksState['myTasks'], task: Task): TasksState['myTasks'] =>
  page ? { ...page, content: page.content.map((t) => (t.id === task.id ? task : t)) } : page;

/** Applies a server-confirmed task to every place the app shows it. */
const applyTask = (state: TasksState, task: Task): Partial<TasksState> => ({
  board: placeOnBoard(state.board, task),
  projectTasks: swapInPage(state.projectTasks, task),
  myTasks: swapInPage(state.myTasks, task),
  selectedTask: state.selectedTask?.id === task.id ? task : state.selectedTask,
});

/** Moves a card between columns / rows without waiting for the server. */
const moveLocally = (state: TasksState, taskId: number, status: TaskStatus): Partial<TasksState> => {
  const patch = (t: Task): Task => (t.id === taskId ? { ...t, status } : t);
  let board = state.board;
  if (board) {
    const current = (Object.values(board.columns).flat() as Task[]).find((t) => t.id === taskId);
    if (current) board = placeOnBoard(board, { ...current, status });
  }
  return {
    board,
    projectTasks: state.projectTasks ? { ...state.projectTasks, content: state.projectTasks.content.map(patch) } : null,
    myTasks: state.myTasks ? { ...state.myTasks, content: state.myTasks.content.map(patch) } : null,
    selectedTask: state.selectedTask ? patch(state.selectedTask) : null,
  };
};

export const tasksReducer = createReducer(
  initialTasksState,
  on(TasksActions.loadBoard, (state): TasksState => ({ ...state, loadBoardStatus: pending() })),
  on(TasksActions.loadBoardSuccess, (state, r): TasksState => ({
    ...state,
    loadBoardStatus: succeeded(),
    board: { ...r.board, columns: { ...emptyColumns(), ...r.board.columns } },
  })),
  on(TasksActions.loadBoardFailure, (state, { error }): TasksState => ({ ...state, loadBoardStatus: failed(error) })),

  on(TasksActions.loadProjectTasks, (state): TasksState => ({ ...state, loadProjectTasksStatus: pending() })),
  on(TasksActions.loadProjectTasksSuccess, (state, r): TasksState => ({ ...state, loadProjectTasksStatus: succeeded(), projectTasks: r.page })),
  on(TasksActions.loadProjectTasksFailure, (state, { error }): TasksState => ({ ...state, loadProjectTasksStatus: failed(error) })),

  on(TasksActions.loadMyTasks, (state): TasksState => ({ ...state, loadMyTasksStatus: pending() })),
  on(TasksActions.loadMyTasksSuccess, (state, r): TasksState => ({ ...state, loadMyTasksStatus: succeeded(), myTasks: r.page })),
  on(TasksActions.loadMyTasksFailure, (state, { error }): TasksState => ({ ...state, loadMyTasksStatus: failed(error) })),

  on(TasksActions.loadTask, (state): TasksState => ({ ...state, loadTaskStatus: pending() })),
  on(TasksActions.loadTaskSuccess, (state, r): TasksState => ({ ...state, loadTaskStatus: succeeded(), selectedTask: r.task })),
  on(TasksActions.loadTaskFailure, (state, { error }): TasksState => ({ ...state, loadTaskStatus: failed(error), selectedTask: null })),

  on(TasksActions.createTask, (state): TasksState => ({ ...state, createTaskStatus: pending() })),
  on(TasksActions.createTaskSuccess, (state, r): TasksState => ({
    ...state,
    createTaskStatus: succeeded(),
    board: placeOnBoard(state.board, r.task),
    projectTasks: state.projectTasks && state.projectTasks.page === 0
      ? { ...state.projectTasks, content: [r.task, ...state.projectTasks.content].slice(0, Math.max(state.projectTasks.size, 1)), totalElements: state.projectTasks.totalElements + 1 }
      : state.projectTasks,
  })),
  on(TasksActions.createTaskFailure, (state, { error }): TasksState => ({ ...state, createTaskStatus: failed(error) })),

  on(TasksActions.updateTask, (state, a): TasksState => ({ ...state, updateTaskStatus: pending(a.taskId) })),
  on(TasksActions.updateTaskSuccess, (state, r): TasksState => ({ ...state, ...applyTask(state, r.task), updateTaskStatus: succeeded() })),
  on(TasksActions.updateTaskFailure, (state, { error }): TasksState => ({ ...state, updateTaskStatus: failed(error) })),

  on(TasksActions.deleteTask, (state, a): TasksState => ({ ...state, deleteTaskStatus: pending(a.taskId) })),
  on(TasksActions.deleteTaskSuccess, (state, r): TasksState => ({
    ...state,
    deleteTaskStatus: succeeded(),
    board: state.board ? { ...state.board, columns: withoutTask(state.board.columns, r.taskId) } : null,
    projectTasks: state.projectTasks ? { ...state.projectTasks, content: state.projectTasks.content.filter((t) => t.id !== r.taskId), totalElements: Math.max(0, state.projectTasks.totalElements - 1) } : null,
    myTasks: state.myTasks ? { ...state.myTasks, content: state.myTasks.content.filter((t) => t.id !== r.taskId), totalElements: Math.max(0, state.myTasks.totalElements - 1) } : null,
    selectedTask: state.selectedTask?.id === r.taskId ? null : state.selectedTask,
  })),
  on(TasksActions.deleteTaskFailure, (state, { error }): TasksState => ({ ...state, deleteTaskStatus: failed(error) })),

  // optimistic status change: move first, confirm (or roll back) when the server answers
  on(TasksActions.updateTaskStatus, (state, a): TasksState => ({ ...state, ...moveLocally(state, a.taskId, a.status), updateTaskStatusStatus: pending(a.taskId) })),
  on(TasksActions.updateTaskStatusSuccess, (state, r): TasksState => ({ ...state, ...applyTask(state, r.task), updateTaskStatusStatus: succeeded() })),
  on(TasksActions.updateTaskStatusFailure, (state, r): TasksState => ({ ...state, ...moveLocally(state, r.taskId, r.from), updateTaskStatusStatus: failed(r.error) })),

  on(TasksActions.assignTask, (state, a): TasksState => ({ ...state, assignTaskStatus: pending(a.taskId) })),
  on(TasksActions.assignTaskSuccess, (state, r): TasksState => ({ ...state, ...applyTask(state, r.task), assignTaskStatus: succeeded() })),
  on(TasksActions.assignTaskFailure, (state, { error }): TasksState => ({ ...state, assignTaskStatus: failed(error) })),

  on(TasksActions.clearTasks, (state): TasksState => ({ ...state, board: null, projectTasks: null, selectedTask: null, loadBoardStatus: idleStatus, loadProjectTasksStatus: idleStatus, loadTaskStatus: idleStatus })),
  on(TasksActions.resetTasksStatuses, (state): TasksState => ({
    ...state,
    loadBoardStatus: idleStatus, loadProjectTasksStatus: idleStatus, loadMyTasksStatus: idleStatus, loadTaskStatus: idleStatus, createTaskStatus: idleStatus,
    updateTaskStatus: idleStatus, deleteTaskStatus: idleStatus, updateTaskStatusStatus: idleStatus, assignTaskStatus: idleStatus,
  })),
  on(AuthActions.logoutSuccess, AuthActions.sessionExpired, (): TasksState => initialTasksState),
);
