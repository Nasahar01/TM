import { createFeatureSelector, createSelector } from '@ngrx/store';
import { TaskStatus } from '../../../core/config/task-meta';
import { percent } from '../../../shared/utils/format';
import { emptyColumns, Task, TaskSummary } from '../entities/task.entity';
import { TasksState } from './tasks.state';

export const selectTasksState = createFeatureSelector<TasksState>('tasks');
export const selectBoard = createSelector(selectTasksState, (s) => s.board);
export const selectBoardColumns = createSelector(selectBoard, (b) => b?.columns ?? emptyColumns());
export const selectProjectTasksPage = createSelector(selectTasksState, (s) => s.projectTasks);
export const selectMyTasksPage = createSelector(selectTasksState, (s) => s.myTasks);
export const selectMyTasks = createSelector(selectMyTasksPage, (p) => p?.content ?? []);
export const selectSelectedTask = createSelector(selectTasksState, (s) => s.selectedTask);
export const selectLoadBoardStatus = createSelector(selectTasksState, (s) => s.loadBoardStatus);
export const selectLoadProjectTasksStatus = createSelector(selectTasksState, (s) => s.loadProjectTasksStatus);
export const selectLoadMyTasksStatus = createSelector(selectTasksState, (s) => s.loadMyTasksStatus);
export const selectLoadTaskStatus = createSelector(selectTasksState, (s) => s.loadTaskStatus);
export const selectCreateTaskStatus = createSelector(selectTasksState, (s) => s.createTaskStatus);
export const selectUpdateTaskStatus = createSelector(selectTasksState, (s) => s.updateTaskStatus);
export const selectDeleteTaskStatus = createSelector(selectTasksState, (s) => s.deleteTaskStatus);
export const selectUpdateTaskStatusStatus = createSelector(selectTasksState, (s) => s.updateTaskStatusStatus);
export const selectAssignTaskStatus = createSelector(selectTasksState, (s) => s.assignTaskStatus);

/** Completion summary computed from the live board, so progress moves the moment a card moves. */
export const selectBoardSummary = createSelector(selectBoard, (board): TaskSummary | null => {
  if (!board) return null;
  const c = board.columns;
  const count = (s: TaskStatus) => (c[s] ?? []).length;
  const all = (Object.values(c).flat() as Task[]);
  const total = all.length;
  return {
    projectId: board.projectId,
    total,
    todo: count('TODO'),
    inProgress: count('IN_PROGRESS'),
    inReview: count('IN_REVIEW'),
    done: count('DONE'),
    overdue: all.filter((t) => t.overdue).length,
    completionPercentage: percent(count('DONE'), total),
    available: true,
  };
});
