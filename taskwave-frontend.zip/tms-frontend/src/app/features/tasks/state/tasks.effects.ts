import { inject, Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, delay, map, mergeMap, of, switchMap } from 'rxjs';
import { LOADING_DELAY, toMessage } from '../../../shared/state/request-status';
import * as ProjectsActions from '../../projects/state/projects.actions';
import { TaskService } from '../services/task-service';
import * as TasksActions from './tasks.actions';

@Injectable()
export class TasksEffects {
  private actions$ = inject(Actions);
  private api = inject(TaskService);

  loadBoard$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TasksActions.loadBoard),
      switchMap((a) =>
        this.api.getBoard(a.projectId).pipe(
          delay(LOADING_DELAY),
          map((res) => TasksActions.loadBoardSuccess({ board: res })),
          catchError((err) => of(TasksActions.loadBoardFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  /** Removing a member un-assigns their tasks on the server: refresh the board so the cards show it. */
  reloadBoardAfterMemberRemoval$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProjectsActions.removeMemberSuccess),
      map(({ projectId }) => TasksActions.loadBoard({ projectId })),
    ),
  );

  loadProjectTasks$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TasksActions.loadProjectTasks),
      switchMap((a) =>
        this.api.getTasksByProject(a.projectId, a.query).pipe(
          delay(LOADING_DELAY),
          map((res) => TasksActions.loadProjectTasksSuccess({ page: res })),
          catchError((err) => of(TasksActions.loadProjectTasksFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  loadMyTasks$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TasksActions.loadMyTasks),
      switchMap((a) =>
        this.api.getMyTasks(a.query).pipe(
          delay(LOADING_DELAY),
          map((res) => TasksActions.loadMyTasksSuccess({ page: res })),
          catchError((err) => of(TasksActions.loadMyTasksFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  loadTask$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TasksActions.loadTask),
      switchMap((a) =>
        this.api.getTaskById(a.taskId).pipe(
          delay(LOADING_DELAY),
          map((res) => TasksActions.loadTaskSuccess({ task: res })),
          catchError((err) => of(TasksActions.loadTaskFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  createTask$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TasksActions.createTask),
      mergeMap((a) =>
        this.api.createTask(a.dto).pipe(
          delay(LOADING_DELAY),
          map((res) => TasksActions.createTaskSuccess({ task: res })),
          catchError((err) => of(TasksActions.createTaskFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  updateTask$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TasksActions.updateTask),
      mergeMap((a) =>
        this.api.updateTask(a.taskId, a.dto).pipe(
          delay(LOADING_DELAY),
          map((res) => TasksActions.updateTaskSuccess({ task: res })),
          catchError((err) => of(TasksActions.updateTaskFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  deleteTask$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TasksActions.deleteTask),
      mergeMap((a) =>
        this.api.deleteTask(a.taskId).pipe(
          delay(LOADING_DELAY),
          map(() => TasksActions.deleteTaskSuccess({ taskId: a.taskId })),
          catchError((err) => of(TasksActions.deleteTaskFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  updateTaskStatus$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TasksActions.updateTaskStatus),
      mergeMap((a) =>
        this.api.updateStatus(a.taskId, a.status).pipe(
          delay(LOADING_DELAY),
          map((res) => TasksActions.updateTaskStatusSuccess({ task: res })),
          catchError((err) =>
            of(TasksActions.updateTaskStatusFailure({ error: toMessage(err), taskId: a.taskId, from: a.from })).pipe(delay(LOADING_DELAY)),
          ),
        ),
      ),
    ),
  );

  assignTask$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TasksActions.assignTask),
      mergeMap((a) =>
        this.api.assignTask(a.taskId, a.assigneeId).pipe(
          delay(LOADING_DELAY),
          map((res) => TasksActions.assignTaskSuccess({ task: res })),
          catchError((err) => of(TasksActions.assignTaskFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );
}
