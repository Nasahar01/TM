import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Action } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { API_URL } from '../../../core/config/api.config';
import { makeTask } from '../../../testing/factories';
import * as ProjectsActions from '../../projects/state/projects.actions';
import * as A from './tasks.actions';
import { TasksEffects } from './tasks.effects';

describe('TasksEffects', () => {
  let actions$: Observable<Action>;
  let effects: TasksEffects;
  let http: HttpTestingController;
  let api: string;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TasksEffects, provideMockActions(() => actions$), provideHttpClient(), provideHttpClientTesting()],
    });
    effects = TestBed.inject(TasksEffects);
    http = TestBed.inject(HttpTestingController);
    api = TestBed.inject(API_URL);
  });

  afterEach(() => http.verify());

  it('loadBoard: success after the 1s loading delay', fakeAsync(() => {
    actions$ = of(A.loadBoard({ projectId: 5 }));
    let out: any;
    effects.loadBoard$.subscribe((a) => (out = a));
    http.expectOne(`${api}/tasks/project/5/board`).flush({ projectId: 5, columns: { TODO: [], IN_PROGRESS: [], IN_REVIEW: [], DONE: [] } });
    expect(out).toBeUndefined();
    tick(1000);
    expect(out.type).toBe(A.loadBoardSuccess.type);
  }));

  it('updateTaskStatus: confirms with the server task', fakeAsync(() => {
    actions$ = of(A.updateTaskStatus({ taskId: 10, status: 'DONE', from: 'IN_REVIEW' }));
    let out: any;
    effects.updateTaskStatus$.subscribe((a) => (out = a));
    http.expectOne(`${api}/tasks/10/status`).flush(makeTask({ status: 'DONE' }));
    tick(1000);
    expect(out.type).toBe(A.updateTaskStatusSuccess.type);
    expect(out.task.status).toBe('DONE');
  }));

  it('updateTaskStatus: a refusal carries the old column so the card can go back', fakeAsync(() => {
    actions$ = of(A.updateTaskStatus({ taskId: 10, status: 'DONE', from: 'IN_REVIEW' }));
    let out: any;
    effects.updateTaskStatus$.subscribe((a) => (out = a));
    http.expectOne(`${api}/tasks/10/status`).flush({ message: 'Only the assignee can do that' }, { status: 403, statusText: 'Forbidden' });
    tick(1000);
    expect(out).toEqual(A.updateTaskStatusFailure({ error: 'Only the assignee can do that', taskId: 10, from: 'IN_REVIEW' }));
  }));

  it('createTask: failure shows the validation message', fakeAsync(() => {
    actions$ = of(A.createTask({ dto: { projectId: 5, title: 'x', description: null, priority: 'LOW', dueDate: null, assigneeId: null } }));
    let out: any;
    effects.createTask$.subscribe((a) => (out = a));
    http.expectOne(`${api}/tasks`).flush({ message: 'Assignee must be a project member' }, { status: 400, statusText: 'Bad Request' });
    tick(1000);
    expect(out).toEqual(A.createTaskFailure({ error: 'Assignee must be a project member' }));
  }));

  it('reloads the board after a member was removed (their tasks are un-assigned)', () => {
    actions$ = of(ProjectsActions.removeMemberSuccess({ projectId: 5, userId: 1 }));
    let out: any;
    effects.reloadBoardAfterMemberRemoval$.subscribe((a) => (out = a));
    expect(out).toEqual(A.loadBoard({ projectId: 5 }));
  });
});
