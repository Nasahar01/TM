import { makeTask } from '../../../testing/factories';
import { emptyColumns } from '../entities/task.entity';
import * as A from './tasks.actions';
import { tasksReducer } from './tasks.reducer';
import { selectBoardSummary } from './tasks.selectors';
import { initialTasksState, TasksState } from './tasks.state';

const boardState = (): TasksState => ({
  ...initialTasksState,
  board: { projectId: 5, columns: { ...emptyColumns(), TODO: [makeTask({ id: 1 }), makeTask({ id: 2 })], DONE: [makeTask({ id: 3, status: 'DONE' })] } },
});

describe('tasksReducer', () => {
  it('stores the board and fills missing columns', () => {
    const s = tasksReducer(initialTasksState, A.loadBoardSuccess({ board: { projectId: 5, columns: { TODO: [makeTask()] } as any } }));
    expect(s.board!.columns.TODO.length).toBe(1);
    expect(s.board!.columns.DONE).toEqual([]);
  });

  it('moves a card at once (optimistic) and marks that task as saving', () => {
    const s = tasksReducer(boardState(), A.updateTaskStatus({ taskId: 1, status: 'IN_PROGRESS', from: 'TODO' }));
    expect(s.board!.columns.TODO.map((t) => t.id)).toEqual([2]);
    expect(s.board!.columns.IN_PROGRESS.map((t) => t.id)).toEqual([1]);
    expect(s.updateTaskStatusStatus.loading).toBe(true);
    expect(s.updateTaskStatusStatus.target).toBe(1);
  });

  it('puts the card back when the server refuses', () => {
    let s = tasksReducer(boardState(), A.updateTaskStatus({ taskId: 1, status: 'DONE', from: 'TODO' }));
    s = tasksReducer(s, A.updateTaskStatusFailure({ error: 'Forbidden', taskId: 1, from: 'TODO' }));
    expect(s.board!.columns.DONE.map((t) => t.id)).toEqual([3]);
    expect(s.board!.columns.TODO.map((t) => t.id)).toContain(1);
    expect(s.updateTaskStatusStatus.error).toBe('Forbidden');
  });

  it('applies the confirmed task from the server everywhere it is shown', () => {
    let s = tasksReducer(boardState(), A.updateTaskStatus({ taskId: 1, status: 'DONE', from: 'TODO' }));
    s = { ...s, selectedTask: makeTask({ id: 1 }) };
    s = tasksReducer(s, A.updateTaskStatusSuccess({ task: makeTask({ id: 1, status: 'DONE', completedAt: '2026-10-28T10:00:00' }) }));
    expect(s.board!.columns.DONE[0].completedAt).toBe('2026-10-28T10:00:00');
    expect(s.selectedTask!.status).toBe('DONE');
    expect(s.updateTaskStatusStatus.success).toBe(true);
  });

  it('adds a created task to its column and to the first list page', () => {
    const start = { ...boardState(), projectTasks: { content: [], page: 0, size: 10, totalElements: 0, totalPages: 0, last: true } };
    const s = tasksReducer(start, A.createTaskSuccess({ task: makeTask({ id: 9, status: 'TODO' }) }));
    expect(s.board!.columns.TODO[0].id).toBe(9);
    expect(s.projectTasks!.totalElements).toBe(1);
  });

  it('removes a deleted task from board, lists and the open drawer', () => {
    const s0 = { ...boardState(), selectedTask: makeTask({ id: 1 }) };
    const s = tasksReducer(s0, A.deleteTaskSuccess({ taskId: 1 }));
    expect(s.board!.columns.TODO.map((t) => t.id)).toEqual([2]);
    expect(s.selectedTask).toBeNull();
  });

  it('clears everything on logout', () => {
    expect(tasksReducer(boardState(), { type: '[Auth] Logout Success' })).toEqual(initialTasksState);
  });

  it('derives live progress from the board', () => {
    const summary = selectBoardSummary.projector(boardState().board);
    expect(summary!.total).toBe(3);
    expect(summary!.todo).toBe(2);
    expect(summary!.done).toBe(1);
    expect(summary!.completionPercentage).toBe(33);
  });
});
