import { createAction, props } from '@ngrx/store';
import { Page } from '../../../shared/entities/page.entity';
import { TaskStatus } from '../../../core/config/task-meta';
import { CreateTaskRequestDTO } from '../dtos/CreateTaskRequestDTO';
import { TaskQueryDTO } from '../dtos/TaskQueryDTO';
import { UpdateTaskRequestDTO } from '../dtos/UpdateTaskRequestDTO';
import { KanbanBoard, Task } from '../entities/task.entity';

export const loadBoard = createAction('[Tasks] Load Board', props<{ projectId: number }>());
export const loadBoardSuccess = createAction('[Tasks] Load Board Success', props<{ board: KanbanBoard }>());
export const loadBoardFailure = createAction('[Tasks] Load Board Failure', props<{ error: string }>());

export const loadProjectTasks = createAction('[Tasks] Load Project Tasks', props<{ projectId: number; query: TaskQueryDTO }>());
export const loadProjectTasksSuccess = createAction('[Tasks] Load Project Tasks Success', props<{ page: Page<Task> }>());
export const loadProjectTasksFailure = createAction('[Tasks] Load Project Tasks Failure', props<{ error: string }>());

export const loadMyTasks = createAction('[Tasks] Load My Tasks', props<{ query: TaskQueryDTO }>());
export const loadMyTasksSuccess = createAction('[Tasks] Load My Tasks Success', props<{ page: Page<Task> }>());
export const loadMyTasksFailure = createAction('[Tasks] Load My Tasks Failure', props<{ error: string }>());

export const loadTask = createAction('[Tasks] Load Task', props<{ taskId: number }>());
export const loadTaskSuccess = createAction('[Tasks] Load Task Success', props<{ task: Task }>());
export const loadTaskFailure = createAction('[Tasks] Load Task Failure', props<{ error: string }>());

export const createTask = createAction('[Tasks] Create Task', props<{ dto: CreateTaskRequestDTO }>());
export const createTaskSuccess = createAction('[Tasks] Create Task Success', props<{ task: Task }>());
export const createTaskFailure = createAction('[Tasks] Create Task Failure', props<{ error: string }>());

export const updateTask = createAction('[Tasks] Update Task', props<{ taskId: number; dto: UpdateTaskRequestDTO }>());
export const updateTaskSuccess = createAction('[Tasks] Update Task Success', props<{ task: Task }>());
export const updateTaskFailure = createAction('[Tasks] Update Task Failure', props<{ error: string }>());

export const deleteTask = createAction('[Tasks] Delete Task', props<{ taskId: number }>());
export const deleteTaskSuccess = createAction('[Tasks] Delete Task Success', props<{ taskId: number }>());
export const deleteTaskFailure = createAction('[Tasks] Delete Task Failure', props<{ error: string }>());

/** Optimistic: the card moves at once; `from` lets the reducer put it back if the server says no. */
export const updateTaskStatus = createAction('[Tasks] Update Task Status', props<{ taskId: number; status: TaskStatus; from: TaskStatus }>());
export const updateTaskStatusSuccess = createAction('[Tasks] Update Task Status Success', props<{ task: Task }>());
export const updateTaskStatusFailure = createAction('[Tasks] Update Task Status Failure', props<{ error: string; taskId: number; from: TaskStatus }>());

export const assignTask = createAction('[Tasks] Assign Task', props<{ taskId: number; assigneeId: number | null }>());
export const assignTaskSuccess = createAction('[Tasks] Assign Task Success', props<{ task: Task }>());
export const assignTaskFailure = createAction('[Tasks] Assign Task Failure', props<{ error: string }>());

export const clearTasks = createAction('[Tasks] Clear Tasks');
export const resetTasksStatuses = createAction('[Tasks] Reset Statuses');
