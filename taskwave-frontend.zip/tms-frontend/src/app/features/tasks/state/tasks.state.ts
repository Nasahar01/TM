import { Page } from '../../../shared/entities/page.entity';
import { idleStatus, RequestStatus } from '../../../shared/state/request-status';
import { KanbanBoard, Task } from '../entities/task.entity';

export interface TasksState {
  board: KanbanBoard | null;
  projectTasks: Page<Task> | null;
  myTasks: Page<Task> | null;
  selectedTask: Task | null;
  loadBoardStatus: RequestStatus;
  loadProjectTasksStatus: RequestStatus;
  loadMyTasksStatus: RequestStatus;
  loadTaskStatus: RequestStatus;
  createTaskStatus: RequestStatus;
  updateTaskStatus: RequestStatus;
  deleteTaskStatus: RequestStatus;
  updateTaskStatusStatus: RequestStatus;
  assignTaskStatus: RequestStatus;
}

export const initialTasksState: TasksState = {
  board: null,
  projectTasks: null,
  myTasks: null,
  selectedTask: null,
  loadBoardStatus: idleStatus,
  loadProjectTasksStatus: idleStatus,
  loadMyTasksStatus: idleStatus,
  loadTaskStatus: idleStatus,
  createTaskStatus: idleStatus,
  updateTaskStatus: idleStatus,
  deleteTaskStatus: idleStatus,
  updateTaskStatusStatus: idleStatus,
  assignTaskStatus: idleStatus,
};
