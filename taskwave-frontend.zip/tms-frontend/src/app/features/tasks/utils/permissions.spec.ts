import { makeDetail, makeTask } from '../../../testing/factories';
import { canAssignTask, canCreateTask, canDeleteTask, canEditTask, canManageProject, canMoveTask, isProjectMember } from './permissions';

const admin = { userId: 99, role: 'ADMIN' as const };
const manager = { userId: 2, role: 'PROJECT_MANAGER' as const };
const otherManager = { userId: 3, role: 'PROJECT_MANAGER' as const };
const member = { userId: 1, role: 'TEAM_MEMBER' as const };
const outsider = { userId: 50, role: 'TEAM_MEMBER' as const };

describe('task permissions (mirror of the backend rules)', () => {
  const detail = makeDetail();

  it('admin and the owning project manager manage a project, other managers do not', () => {
    expect(canManageProject(detail, admin)).toBe(true);
    expect(canManageProject(detail, manager)).toBe(true);
    expect(canManageProject(detail, otherManager)).toBe(false);
    expect(canManageProject(detail, member)).toBe(false);
  });

  it('only people in the project can create and assign tasks', () => {
    expect(isProjectMember(detail, member)).toBe(true);
    expect(canCreateTask(detail, member)).toBe(true);
    expect(canCreateTask(detail, outsider)).toBe(false);
    expect(canAssignTask(detail, outsider)).toBe(false);
  });

  it('a team member moves only tasks assigned to them', () => {
    expect(canMoveTask(makeTask({ assigneeId: 1 }), detail, member)).toBe(true);
    expect(canMoveTask(makeTask({ assigneeId: 7 }), detail, member)).toBe(false);
    expect(canMoveTask(makeTask({ assigneeId: 7 }), detail, manager)).toBe(true);
  });

  it('a team member edits only tasks they created', () => {
    expect(canEditTask(makeTask({ createdById: 1 }), detail, member)).toBe(true);
    expect(canEditTask(makeTask({ createdById: 2 }), detail, member)).toBe(false);
    expect(canEditTask(makeTask({ createdById: 2 }), detail, admin)).toBe(true);
  });

  it('completed tasks can never be deleted', () => {
    expect(canDeleteTask(makeTask({ status: 'DONE' }), detail, admin)).toBe(false);
    expect(canDeleteTask(makeTask({ status: 'TODO' }), detail, admin)).toBe(true);
  });

  it('an archived project is read-only for everybody', () => {
    const archived = makeDetail({ status: 'ARCHIVED' });
    expect(canCreateTask(archived, admin)).toBe(false);
    expect(canMoveTask(makeTask(), archived, admin)).toBe(false);
    expect(canEditTask(makeTask(), archived, admin)).toBe(false);
    expect(canAssignTask(archived, admin)).toBe(false);
  });
});
