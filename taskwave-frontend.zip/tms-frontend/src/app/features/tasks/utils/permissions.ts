import { Role } from '../../../core/config/roles';
import { ProjectDetail } from '../../projects/entities/project.entity';
import { Task } from '../entities/task.entity';

/** The signed-in person as the permission helpers need it. */
export interface Actor { userId: number; role: Role }

/**
 * Client-side mirror of the backend rules (project-service ProjectService / task-service TaskService).
 * They only decide what the UI offers; the API still enforces everything.
 */
export const isArchived = (d: ProjectDetail | null): boolean => d?.project.status === 'ARCHIVED';

/** Admin: any project. Project manager: only the projects they manage. */
export function canManageProject(d: ProjectDetail | null, a: Actor | null): boolean {
  if (!d || !a) return false;
  return a.role === 'ADMIN' || (a.role === 'PROJECT_MANAGER' && d.project.managerId === a.userId);
}

export function isProjectMember(d: ProjectDetail | null, a: Actor | null): boolean {
  if (!d || !a) return false;
  return canManageProject(d, a) || d.project.managerId === a.userId || d.members.some((m) => m.userId === a.userId);
}

/** Anyone in the project may create and assign tasks (team members: "assigned projects"). */
export const canCreateTask = (d: ProjectDetail | null, a: Actor | null): boolean => !isArchived(d) && isProjectMember(d, a);

/** Admin / project manager: any task. Team member: only tasks they created. */
export function canEditTask(t: Task, d: ProjectDetail | null, a: Actor | null): boolean {
  if (!a || isArchived(d)) return false;
  return canManageProject(d, a) || t.createdById === a.userId;
}

/** Completed tasks are kept as project history. */
export const canDeleteTask = (t: Task, d: ProjectDetail | null, a: Actor | null): boolean => t.status !== 'DONE' && canEditTask(t, d, a);

/** Admin / project manager: any task. Team member: only tasks assigned to them (including marking them Done). */
export function canMoveTask(t: Task, d: ProjectDetail | null, a: Actor | null): boolean {
  if (!a || isArchived(d)) return false;
  return canManageProject(d, a) || t.assigneeId === a.userId;
}

export const canAssignTask = (d: ProjectDetail | null, a: Actor | null): boolean => !isArchived(d) && isProjectMember(d, a);
