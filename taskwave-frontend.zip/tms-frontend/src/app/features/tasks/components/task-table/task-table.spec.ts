import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { TaskTable } from './task-table';

describe('TaskTable', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [TaskTable], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(TaskTable);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
