import { Component, computed, DestroyRef, inject, input, OnInit, output, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Store } from '@ngrx/store';
import { debounceTime, distinctUntilChanged, Subject } from 'rxjs';
import { Avatar } from '../../../../shared/components/avatar/avatar';
import { Badge } from '../../../../shared/components/badge/badge';
import { Icon } from '../../../../shared/components/icon/icon';
import { Pagination } from '../../../../shared/components/pagination/pagination';
import { TASK_PRIORITIES, TASK_STATUSES, statusLabel } from '../../../../core/config/task-meta';
import { fmtDate, pretty, timeAgo } from '../../../../shared/utils/format';
import { Member } from '../../../projects/entities/project.entity';
import { loadProjectTasks } from '../../state/tasks.actions';
import { selectLoadProjectTasksStatus, selectProjectTasksPage } from '../../state/tasks.selectors';

const PAGE_SIZE = 10;

/** Server-side filtered, sorted and paginated list of a project's tasks (GET /tasks/project/{id}). */
@Component({
  selector: 'app-task-table',
  templateUrl: './task-table.html',
  styleUrl: './task-table.css',
  imports: [Avatar, Badge, Icon, Pagination]
})
export class TaskTable implements OnInit {

  private store = inject(Store);
  private destroyRef = inject(DestroyRef);

  projectId = input.required<number>();
  members = input<Member[]>([]);
  opened = output<number>();

  page = this.store.selectSignal(selectProjectTasksPage);
  status = this.store.selectSignal(selectLoadProjectTasksStatus);
  rows = computed(() => this.page()?.content ?? []);

  statuses = TASK_STATUSES;
  priorities = TASK_PRIORITIES;
  statusLabel = statusLabel;
  pretty = pretty;
  fmt = fmtDate;
  ago = timeAgo;
  sorts = [
    { value: 'dueDate,asc', label: 'Due date (soonest)' },
    { value: 'updatedAt,desc', label: 'Recently updated' },
    { value: 'priority,desc', label: 'Priority' },
    { value: 'createdAt,desc', label: 'Newest' },
  ];

  q = signal('');
  statusFilter = signal('');
  priorityFilter = signal('');
  assigneeFilter = signal('');
  sort = signal('updatedAt,desc');
  pageIndex = signal(0);
  search$ = new Subject<string>();

  constructor() {
    this.search$.pipe(debounceTime(350), distinctUntilChanged(), takeUntilDestroyed(this.destroyRef)).subscribe((v) => {
      this.q.set(v);
      this.pageIndex.set(0);
      this.load();
    });
  }

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    const assignee = this.assigneeFilter();
    this.store.dispatch(loadProjectTasks({
      projectId: this.projectId(),
      query: {
        q: this.q(),
        status: this.statusFilter() || undefined,
        priority: this.priorityFilter() || undefined,
        assigneeId: assignee ? Number(assignee) : undefined,
        page: this.pageIndex(),
        size: PAGE_SIZE,
        sort: this.sort(),
      },
    }));
  }

  filter(kind: 'status' | 'priority' | 'assignee' | 'sort', value: string): void {
    ({ status: this.statusFilter, priority: this.priorityFilter, assignee: this.assigneeFilter, sort: this.sort })[kind].set(value);
    this.pageIndex.set(0);
    this.load();
  }

  goTo(p: number): void {
    this.pageIndex.set(p);
    this.load();
  }

  assignee(id: number | null): string {
    return id ? this.members().find((m) => m.userId === id)?.name ?? '' : '';
  }
}
