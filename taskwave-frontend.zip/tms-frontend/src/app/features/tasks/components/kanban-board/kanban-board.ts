import { CdkDrag, CdkDragDrop, CdkDropList, CdkDropListGroup } from '@angular/cdk/drag-drop';
import { Component, input, output } from '@angular/core';
import { Icon } from '../../../../shared/components/icon/icon';
import { BOARD_COLUMNS, TaskStatus } from '../../../../core/config/task-meta';
import { Member } from '../../../projects/entities/project.entity';
import { Task } from '../../entities/task.entity';
import { TaskCard } from '../task-card/task-card';

export interface TaskMove { task: Task; to: TaskStatus; }

/** Four-column drag and drop board. Which cards may be dragged is decided by the parent (`canMove`). */
@Component({
  selector: 'app-kanban-board',
  templateUrl: './kanban-board.html',
  styleUrl: './kanban-board.css',
  imports: [CdkDropListGroup, CdkDropList, CdkDrag, Icon, TaskCard]
})
export class KanbanBoard {

  columns = input.required<Record<TaskStatus, Task[]>>();
  members = input<Member[]>([]);
  canMove = input<(task: Task) => boolean>(() => false);
  savingTaskId = input<number | null>(null);
  opened = output<number>();
  moved = output<TaskMove>();

  cols = BOARD_COLUMNS;
  private dragging = false;

  assignee(task: Task): string {
    return this.members().find((m) => m.userId === task.assigneeId)?.name ?? '';
  }

  onDragStart(): void {
    this.dragging = true;
  }

  onDragEnd(): void {
    // a drag must not be mistaken for a click that opens the task
    setTimeout(() => (this.dragging = false), 0);
  }

  open(id: number): void {
    if (!this.dragging) this.opened.emit(id);
  }

  drop(event: CdkDragDrop<Task[]>, to: TaskStatus): void {
    if (event.previousContainer === event.container) return;
    const task = event.item.data as Task;
    if (task.status === to || !this.canMove()(task)) return;
    this.moved.emit({ task, to });
  }
}
