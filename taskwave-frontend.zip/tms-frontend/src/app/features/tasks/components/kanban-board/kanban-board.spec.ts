import { TestBed } from '@angular/core/testing';
import { makeTask } from '../../../../testing/factories';
import { emptyColumns } from '../../entities/task.entity';
import { KanbanBoard } from './kanban-board';

describe('KanbanBoard', () => {
  const setup = () => {
    TestBed.configureTestingModule({ imports: [KanbanBoard] });
    const f = TestBed.createComponent(KanbanBoard);
    f.componentRef.setInput('columns', { ...emptyColumns(), TODO: [makeTask({ id: 1, title: 'Write docs' })], DONE: [makeTask({ id: 2, status: 'DONE', title: 'Set up CI' })] });
    f.componentRef.setInput('canMove', () => true);
    f.detectChanges();
    return f;
  };

  it('renders the four columns with their cards', () => {
    const f = setup();
    const host = f.nativeElement as HTMLElement;
    expect(host.querySelectorAll('section.col').length).toBe(4);
    expect(host.textContent).toContain('Write docs');
    expect(host.textContent).toContain('Set up CI');
  });

  it('only emits a move when the card really changes column and the user may move it', () => {
    const f = setup();
    const moves: unknown[] = [];
    f.componentInstance.moved.subscribe((m) => moves.push(m));
    const task = makeTask({ id: 1, status: 'TODO' });
    const drop = (to: string, sameList = false) => {
      const container = {} as any;
      f.componentInstance.drop({ item: { data: task }, previousContainer: sameList ? container : ({} as any), container } as any, to as any);
    };
    drop('TODO', true);
    drop('TODO');
    expect(moves.length).toBe(0);
    drop('IN_PROGRESS');
    expect(moves.length).toBe(1);
    f.componentRef.setInput('canMove', () => false);
    drop('DONE');
    expect(moves.length).toBe(1);
  });

  it('does not open a task right after a drag', async () => {
    const f = setup();
    const opened: number[] = [];
    f.componentInstance.opened.subscribe((id) => opened.push(id));
    f.componentInstance.onDragStart();
    f.componentInstance.open(1);
    f.componentInstance.onDragEnd();
    await new Promise((r) => setTimeout(r, 5));
    f.componentInstance.open(1);
    expect(opened).toEqual([1]);
  });
});
