import { Component, effect, inject, input, output, untracked } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Btn } from '../../../../shared/components/btn/btn';
import { Field } from '../../../../shared/components/field/field';
import { TASK_PRIORITIES, TaskPriority } from '../../../../core/config/task-meta';
import { notBlank, todayOrLater } from '../../../../shared/utils/validators';
import { pretty, todayIso } from '../../../../shared/utils/format';
import { Member } from '../../../projects/entities/project.entity';
import { Task } from '../../entities/task.entity';
import { createTask, resetTasksStatuses, updateTask } from '../../state/tasks.actions';
import { selectCreateTaskStatus, selectUpdateTaskStatus } from '../../state/tasks.selectors';

/** Create (no `task` input) or edit (with `task`) form, shown inside a modal. */
@Component({
  selector: 'app-task-form',
  templateUrl: './task-form.html',
  styleUrl: './task-form.css',
  imports: [ReactiveFormsModule, Btn, Field]
})
export class TaskForm {

  private store = inject(Store);

  projectId = input.required<number>();
  members = input<Member[]>([]);
  task = input<Task | null>(null);
  /** open flag of the parent modal: the form resets every time it opens */
  active = input<boolean>(false);
  done = output<void>();
  cancelled = output<void>();

  createStatus = this.store.selectSignal(selectCreateTaskStatus);
  updateStatus = this.store.selectSignal(selectUpdateTaskStatus);
  priorities = TASK_PRIORITIES;
  pretty = pretty;
  today = todayIso();
  private submitted = false;

  form = new FormGroup({
    title: new FormControl('', { nonNullable: true, validators: [Validators.required, notBlank, Validators.maxLength(200)] }),
    description: new FormControl('', { nonNullable: true, validators: [Validators.maxLength(2000)] }),
    priority: new FormControl<TaskPriority>('MEDIUM', { nonNullable: true, validators: [Validators.required] }),
    dueDate: new FormControl('', { nonNullable: true }),
    assigneeId: new FormControl<number | null>(null),
  });

  constructor() {
    // reset / pre-fill whenever the dialog opens
    effect(() => {
      if (!this.active()) return;
      // only `active` triggers a reset: the task changing after a save must not wipe the "submitted" flag
      const t = untracked(() => this.task());
      this.submitted = false;
      this.store.dispatch(resetTasksStatuses());
      this.form.reset({ title: t?.title ?? '', description: t?.description ?? '', priority: t?.priority ?? 'MEDIUM', dueDate: t?.dueDate ?? '', assigneeId: t?.assigneeId ?? null });
      // only a NEW task must not start in the past; existing tasks may already be overdue
      this.form.controls.dueDate.setValidators(t ? [] : [todayOrLater]);
      this.form.controls.dueDate.updateValueAndValidity();
    });
    // close the dialog when the request that THIS form sent succeeds
    effect(() => {
      const s = this.task() ? this.updateStatus() : this.createStatus();
      if (this.submitted && s.success) {
        this.submitted = false;
        this.done.emit();
      }
    });
  }

  status() {
    return this.task() ? this.updateStatus() : this.createStatus();
  }

  submit(): void {
    if (this.form.invalid || this.status().loading) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    const base = { title: v.title.trim(), description: v.description.trim() || null, priority: v.priority, dueDate: v.dueDate || null };
    this.submitted = true;
    const t = this.task();
    if (t) {
      this.store.dispatch(updateTask({ taskId: t.id, dto: base }));
    } else {
      this.store.dispatch(createTask({ dto: { ...base, projectId: this.projectId(), assigneeId: v.assigneeId } }));
    }
  }
}
