import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { TaskForm } from './task-form';

describe('TaskForm', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [TaskForm], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(TaskForm);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
