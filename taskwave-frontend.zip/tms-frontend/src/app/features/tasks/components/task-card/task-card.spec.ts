import { TestBed } from '@angular/core/testing';
import { makeTask } from '../../../../testing/factories';
import { TaskCard } from './task-card';

describe('TaskCard', () => {
  const setup = (task = makeTask({ title: 'Design login' })) => {
    TestBed.configureTestingModule({ imports: [TaskCard] });
    const f = TestBed.createComponent(TaskCard);
    f.componentRef.setInput('task', task);
    f.detectChanges();
    return f;
  };

  it('shows title and priority', () => {
    const text = (setup().nativeElement as HTMLElement).textContent;
    expect(text).toContain('Design login');
    expect(text).toContain('Medium');
  });

  it('flags overdue tasks', () => {
    const host = setup(makeTask({ dueDate: '2020-01-01', overdue: true })).nativeElement as HTMLElement;
    expect(host.querySelector('.due.over')).toBeTruthy();
  });

  it('opens on click', () => {
    const f = setup();
    let id = 0;
    f.componentInstance.opened.subscribe((v) => (id = v));
    (f.nativeElement as HTMLElement).querySelector<HTMLElement>('article')!.click();
    expect(id).toBe(10);
  });
});
