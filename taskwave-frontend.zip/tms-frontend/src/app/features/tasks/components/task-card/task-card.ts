import { Component, computed, input, output } from '@angular/core';
import { Avatar } from '../../../../shared/components/avatar/avatar';
import { Icon } from '../../../../shared/components/icon/icon';
import { fmtDate, pretty } from '../../../../shared/utils/format';
import { PRIORITY_COLOR } from '../../../../core/config/task-meta';
import { Task } from '../../entities/task.entity';

/** One card on the board. Presentational: the board decides when it can be dragged. */
@Component({
  selector: 'app-task-card',
  templateUrl: './task-card.html',
  styleUrl: './task-card.css',
  imports: [Avatar, Icon]
})
export class TaskCard {

  task = input.required<Task>();
  assigneeName = input<string>('');
  draggable = input<boolean>(false);
  saving = input<boolean>(false);
  opened = output<number>();

  color = computed(() => PRIORITY_COLOR[this.task().priority]);
  priority = computed(() => pretty(this.task().priority));
  due = computed(() => fmtDate(this.task().dueDate));
}
