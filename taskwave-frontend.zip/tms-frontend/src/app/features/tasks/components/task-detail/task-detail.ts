import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { Store } from '@ngrx/store';
import { Avatar } from '../../../../shared/components/avatar/avatar';
import { Badge } from '../../../../shared/components/badge/badge';
import { Btn } from '../../../../shared/components/btn/btn';
import { Icon } from '../../../../shared/components/icon/icon';
import { TASK_STATUSES, TaskStatus, statusLabel } from '../../../../core/config/task-meta';
import { fmtDate, fmtDateTime } from '../../../../shared/utils/format';
import { selectUser } from '../../../auth/state/auth.selectors';
import { CommentThread } from '../../../comments/components/comment-thread/comment-thread';
import { HistoryTimeline } from '../../../comments/components/history-timeline/history-timeline';
import { loadComments, loadHistory } from '../../../comments/state/comments.actions';
import { selectComments } from '../../../comments/state/comments.selectors';
import { ProjectDetail } from '../../../projects/entities/project.entity';
import { assignTask, deleteTask, loadTask, resetTasksStatuses, updateTaskStatus } from '../../state/tasks.actions';
import {
  selectAssignTaskStatus, selectDeleteTaskStatus, selectLoadTaskStatus, selectSelectedTask, selectUpdateTaskStatusStatus,
} from '../../state/tasks.selectors';
import { canAssignTask, canDeleteTask, canEditTask, canMoveTask, isArchived } from '../../utils/permissions';
import { Task } from '../../entities/task.entity';

/** Body of the task drawer: details, quick status / assignee changes, comments and audit history. */
@Component({
  selector: 'app-task-detail',
  templateUrl: './task-detail.html',
  styleUrl: './task-detail.css',
  imports: [Avatar, Badge, Btn, Icon, CommentThread, HistoryTimeline]
})
export class TaskDetail {

  private store = inject(Store);

  taskId = input.required<number>();
  detail = input<ProjectDetail | null>(null);
  edit = output<Task>();
  gone = output<void>();

  user = this.store.selectSignal(selectUser);
  selected = this.store.selectSignal(selectSelectedTask);
  loadStatus = this.store.selectSignal(selectLoadTaskStatus);
  statusStatus = this.store.selectSignal(selectUpdateTaskStatusStatus);
  assignStatus = this.store.selectSignal(selectAssignTaskStatus);
  deleteStatus = this.store.selectSignal(selectDeleteTaskStatus);
  comments = this.store.selectSignal(selectComments);

  statuses = TASK_STATUSES;
  statusLabel = statusLabel;
  fmtDate = fmtDate;
  fmtDateTime = fmtDateTime;
  tab = signal<'comments' | 'history'>('comments');
  confirming = signal(false);
  private deleting = false;

  task = computed(() => (this.selected()?.id === this.taskId() ? this.selected() : null));
  members = computed(() => this.detail()?.members ?? []);
  assigneeName = computed(() => this.members().find((m) => m.userId === this.task()?.assigneeId)?.name ?? '');
  actor = computed(() => { const u = this.user(); return u ? { userId: u.userId, role: u.role } : null; });
  archived = computed(() => isArchived(this.detail()));

  canMove = computed(() => { const t = this.task(); return !!t && canMoveTask(t, this.detail(), this.actor()); });
  canEdit = computed(() => { const t = this.task(); return !!t && canEditTask(t, this.detail(), this.actor()); });
  canDelete = computed(() => { const t = this.task(); return !!t && canDeleteTask(t, this.detail(), this.actor()); });
  canAssign = computed(() => canAssignTask(this.detail(), this.actor()));
  savingStatus = computed(() => this.statusStatus().loading && this.statusStatus().target === this.taskId());
  savingAssignee = computed(() => this.assignStatus().loading && this.assignStatus().target === this.taskId());
  isDeleting = computed(() => this.deleteStatus().loading && this.deleteStatus().target === this.taskId());

  constructor() {
    // (re)load everything whenever another task is opened
    effect(() => {
      const id = this.taskId();
      this.tab.set('comments');
      this.confirming.set(false);
      this.store.dispatch(resetTasksStatuses());
      this.store.dispatch(loadTask({ taskId: id }));
      this.store.dispatch(loadComments({ taskId: id }));
      this.store.dispatch(loadHistory({ taskId: id }));
    });
    // a deleted task closes its own drawer
    effect(() => {
      if (this.deleting && this.deleteStatus().success) {
        this.deleting = false;
        this.gone.emit();
      }
    });
  }

  changeStatus(status: string): void {
    const t = this.task();
    if (!t || t.status === status || !this.canMove()) return;
    this.store.dispatch(updateTaskStatus({ taskId: t.id, status: status as TaskStatus, from: t.status }));
  }

  changeAssignee(value: string): void {
    const t = this.task();
    if (!t || !this.canAssign()) return;
    const assigneeId = value === '' ? null : Number(value);
    if (assigneeId === t.assigneeId) return;
    this.store.dispatch(assignTask({ taskId: t.id, assigneeId }));
  }

  remove(): void {
    const t = this.task();
    if (!t) return;
    this.deleting = true;
    this.confirming.set(false);
    this.store.dispatch(deleteTask({ taskId: t.id }));
  }
}
