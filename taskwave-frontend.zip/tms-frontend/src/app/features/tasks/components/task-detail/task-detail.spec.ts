import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { TaskDetail } from './task-detail';

describe('TaskDetail', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [TaskDetail], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(TaskDetail);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
