import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { Badge } from '../../../../shared/components/badge/badge';
import { EmptyState } from '../../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../../shared/components/icon/icon';
import { PageHeader } from '../../../../shared/components/page-header/page-header';
import { Pagination } from '../../../../shared/components/pagination/pagination';
import { BOARD_COLUMNS, PRIORITY_COLOR, TaskStatus } from '../../../../core/config/task-meta';
import { fmtDate } from '../../../../shared/utils/format';
import { loadProjects } from '../../../projects/state/projects.actions';
import { selectProjectNames } from '../../../projects/state/projects.selectors';
import { Task } from '../../entities/task.entity';
import { loadMyTasks, resetTasksStatuses, updateTaskStatus } from '../../state/tasks.actions';
import { selectLoadMyTasksStatus, selectMyTasksPage, selectUpdateTaskStatusStatus } from '../../state/tasks.selectors';

const PAGE_SIZE = 8;

/** Everything assigned to me across all projects (GET /tasks/my). */
@Component({
  selector: 'app-my-tasks',
  templateUrl: './my-tasks.html',
  styleUrl: './my-tasks.css',
  imports: [RouterLink, Badge, EmptyState, Icon, PageHeader, Pagination]
})
export class MyTasks implements OnInit {

  private store = inject(Store);
  page = this.store.selectSignal(selectMyTasksPage);
  status = this.store.selectSignal(selectLoadMyTasksStatus);
  moveStatus = this.store.selectSignal(selectUpdateTaskStatusStatus);
  names = this.store.selectSignal(selectProjectNames);

  cols = BOARD_COLUMNS;
  priorityColor = PRIORITY_COLOR;
  fmt = fmtDate;
  statusFilter = signal<string>('');
  sort = signal('dueDate,asc');
  pageIndex = signal(0);
  rows = computed(() => this.page()?.content ?? []);

  sorts = [
    { value: 'dueDate,asc', label: 'Due date (soonest)' },
    { value: 'priority,desc', label: 'Priority' },
    { value: 'updatedAt,desc', label: 'Recently updated' },
  ];

  ngOnInit(): void {
    this.store.dispatch(resetTasksStatuses());
    // project names for the rows (the task payload only carries projectId)
    this.store.dispatch(loadProjects({ query: { page: 0, size: 100, includeArchived: true } }));
    this.load();
  }

  load(): void {
    this.store.dispatch(loadMyTasks({ query: { status: this.statusFilter() || undefined, page: this.pageIndex(), size: PAGE_SIZE, sort: this.sort() } }));
  }

  setStatus(s: string): void {
    this.statusFilter.set(s);
    this.pageIndex.set(0);
    this.load();
  }

  setSort(s: string): void {
    this.sort.set(s);
    this.pageIndex.set(0);
    this.load();
  }

  goTo(p: number): void {
    this.pageIndex.set(p);
    this.load();
  }

  saving(t: Task): boolean {
    return this.moveStatus().loading && this.moveStatus().target === t.id;
  }

  change(t: Task, status: string): void {
    if (status === t.status) return;
    this.store.dispatch(updateTaskStatus({ taskId: t.id, status: status as TaskStatus, from: t.status }));
  }
}
