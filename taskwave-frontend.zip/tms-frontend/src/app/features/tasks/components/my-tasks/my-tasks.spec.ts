import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { MyTasks } from './my-tasks';

describe('MyTasks', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [MyTasks], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(MyTasks);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
