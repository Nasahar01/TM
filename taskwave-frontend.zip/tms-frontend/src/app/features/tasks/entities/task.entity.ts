import { TaskPriority, TaskStatus } from '../../../core/config/task-meta';

/** TaskResponse (task-service). */
export interface Task {
  id: number;
  projectId: number;
  title: string;
  description: string | null;
  priority: TaskPriority;
  status: TaskStatus;
  assigneeId: number | null;
  createdById: number;
  createdByName: string;
  dueDate: string | null;
  overdue: boolean;
  completedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

/** KanbanBoardResponse: one column per status, ready for drag and drop. */
export interface KanbanBoard {
  projectId: number;
  columns: Record<TaskStatus, Task[]>;
}

/** TaskSummaryResponse: completion summary of a project's tasks. */
export interface TaskSummary {
  projectId: number;
  total: number;
  todo: number;
  inProgress: number;
  inReview: number;
  done: number;
  overdue: number;
  completionPercentage: number;
  available: boolean;
}

export const emptyColumns = (): Record<TaskStatus, Task[]> => ({ TODO: [], IN_PROGRESS: [], IN_REVIEW: [], DONE: [] });
