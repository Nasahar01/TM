/** assigneeId = null un-assigns the task. */
export interface AssignTaskRequestDTO {
  assigneeId: number | null;
}
