/** Query string of GET /tasks/project/{id} and GET /tasks/my (0-based page, size 1-100). */
export interface TaskQueryDTO {
  status?: string;
  priority?: string;
  assigneeId?: number | null;
  q?: string;
  page: number;
  size: number;
  sort?: string;
}
