import { TaskPriority } from '../../../core/config/task-meta';

export interface UpdateTaskRequestDTO {
  title: string;
  description: string | null;
  priority: TaskPriority;
  dueDate: string | null;
}
