import { TaskStatus } from '../../../core/config/task-meta';

export interface UpdateStatusRequestDTO {
  status: TaskStatus;
}
