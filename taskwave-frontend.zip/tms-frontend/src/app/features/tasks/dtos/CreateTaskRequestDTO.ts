import { TaskPriority } from '../../../core/config/task-meta';

export interface CreateTaskRequestDTO {
  projectId: number;
  title: string;
  description: string | null;
  priority: TaskPriority;
  dueDate: string | null;
  /** must be a member of the project */
  assigneeId: number | null;
}
