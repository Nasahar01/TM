import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { Overview } from './overview';

describe('Overview', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [Overview], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(Overview);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
