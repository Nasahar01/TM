import { Component, computed, inject, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { Badge } from '../../../../shared/components/badge/badge';
import { EmptyState } from '../../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../../shared/components/icon/icon';
import { ProgressBar } from '../../../../shared/components/progress-bar/progress-bar';
import { StatCard } from '../../../../shared/components/stat-card/stat-card';
import { fmtDate, percent } from '../../../../shared/utils/format';
import { PRIORITY_COLOR } from '../../../../core/config/task-meta';
import { roleInfo } from '../../../../core/config/roles';
import { selectUser } from '../../../auth/state/auth.selectors';
import { ProjectCard } from '../../../projects/components/project-card/project-card';
import { loadProjects } from '../../../projects/state/projects.actions';
import { selectLoadProjectsStatus, selectProjectNames, selectProjects, selectProjectsPage, selectProjectSummaries } from '../../../projects/state/projects.selectors';
import { loadMyTasks, resetTasksStatuses } from '../../../tasks/state/tasks.actions';
import { selectLoadMyTasksStatus, selectMyTasks } from '../../../tasks/state/tasks.selectors';
import { loadUsers } from '../../../users/state/users.actions';
import { selectUsersPage } from '../../../users/state/users.selectors';

@Component({
  selector: 'app-overview',
  templateUrl: './overview.html',
  styleUrl: './overview.css',
  imports: [RouterLink, Badge, EmptyState, Icon, ProgressBar, StatCard, ProjectCard]
})
export class Overview implements OnInit {

  private store = inject(Store);
  user = this.store.selectSignal(selectUser);
  tasks = this.store.selectSignal(selectMyTasks);
  tasksStatus = this.store.selectSignal(selectLoadMyTasksStatus);
  projects = this.store.selectSignal(selectProjects);
  projectsPage = this.store.selectSignal(selectProjectsPage);
  projectsStatus = this.store.selectSignal(selectLoadProjectsStatus);
  summaries = this.store.selectSignal(selectProjectSummaries);
  names = this.store.selectSignal(selectProjectNames);
  usersPage = this.store.selectSignal(selectUsersPage);
  priorityColor = PRIORITY_COLOR;

  isAdmin = computed(() => this.user()?.role === 'ADMIN');
  canCreate = computed(() => this.user()?.role !== 'TEAM_MEMBER');
  role = computed(() => roleInfo(this.user()?.role));
  firstName = computed(() => (this.user()?.name ?? '').split(' ')[0]);

  greeting = (() => {
    const h = new Date().getHours();
    return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
  })();

  open = computed(() => this.tasks().filter((t) => t.status !== 'DONE').length);
  inProgress = computed(() => this.tasks().filter((t) => t.status === 'IN_PROGRESS').length);
  overdue = computed(() => this.tasks().filter((t) => t.overdue).length);
  done = computed(() => this.tasks().filter((t) => t.status === 'DONE').length);
  completion = computed(() => percent(this.done(), this.tasks().length));

  /** open tasks, nearest deadline first; tasks without a date go last */
  upNext = computed(() =>
    this.tasks()
      .filter((t) => t.status !== 'DONE')
      .sort((a, b) => (a.dueDate ?? '9999-12-31').localeCompare(b.dueDate ?? '9999-12-31'))
      .slice(0, 6),
  );

  ngOnInit(): void {
    this.store.dispatch(resetTasksStatuses());
    this.store.dispatch(loadMyTasks({ query: { page: 0, size: 100, sort: 'dueDate,asc' } }));
    this.store.dispatch(loadProjects({ query: { page: 0, size: 100, includeArchived: false, sort: 'updatedAt,desc' } }));
    if (this.isAdmin()) this.store.dispatch(loadUsers({ query: { page: 0, size: 1 } }));
  }

  date(v: string | null): string {
    return fmtDate(v);
  }
}
