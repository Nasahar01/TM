import { Component, computed, inject, signal } from '@angular/core';
import { NavigationEnd, Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { Store } from '@ngrx/store';
import { filter } from 'rxjs';
import { Avatar } from '../../../../shared/components/avatar/avatar';
import { Badge } from '../../../../shared/components/badge/badge';
import { Btn } from '../../../../shared/components/btn/btn';
import { Icon } from '../../../../shared/components/icon/icon';
import { NAV_BY_ROLE, roleInfo } from '../../../../core/config/roles';
import { logout } from '../../../auth/state/auth.actions';
import { selectLogoutStatus, selectUser } from '../../../auth/state/auth.selectors';
import { selectProfile } from '../../../users/state/users.selectors';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-dashboard-layout',
  templateUrl: './dashboard-layout.html',
  styleUrl: './dashboard-layout.css',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, Icon, Avatar, Badge, Btn]
})
export class DashboardLayout {

  private store = inject(Store);
  private router = inject(Router);

  user = this.store.selectSignal(selectUser);
  profile = this.store.selectSignal(selectProfile);
  logoutStatus = this.store.selectSignal(selectLogoutStatus);
  menu = signal(false);

  /** shows the edited name as soon as the profile page saved it */
  displayName = computed(() => this.profile()?.name ?? this.user()?.name ?? '');
  nav = computed(() => NAV_BY_ROLE[this.user()?.role ?? 'TEAM_MEMBER']);
  roleLabel = computed(() => roleInfo(this.user()?.role)?.label ?? '');

  constructor() {
    this.router.events.pipe(filter((e) => e instanceof NavigationEnd), takeUntilDestroyed()).subscribe(() => this.menu.set(false));
  }

  signOut(): void {
    this.store.dispatch(logout());
  }
}
