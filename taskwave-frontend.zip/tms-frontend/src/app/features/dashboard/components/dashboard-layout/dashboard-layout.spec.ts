import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { DashboardLayout } from './dashboard-layout';

describe('DashboardLayout', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [DashboardLayout], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(DashboardLayout);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
