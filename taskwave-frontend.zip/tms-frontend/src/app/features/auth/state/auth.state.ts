import { idleStatus, RequestStatus } from '../../../shared/state/request-status';
import { CurrentUser } from '../entities/current-user.entity';

export interface AuthState {
  user: CurrentUser | null;
  /** true once the first session check has finished (success or not) */
  checked: boolean;
  loginStatus: RequestStatus;
  loadCurrentUserStatus: RequestStatus;
  logoutStatus: RequestStatus;
}

export const initialAuthState: AuthState = {
  user: null,
  checked: false,
  loginStatus: idleStatus,
  loadCurrentUserStatus: idleStatus,
  logoutStatus: idleStatus,
};
