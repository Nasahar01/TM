import { createAction, props } from '@ngrx/store';
import { LoginRequestDTO } from '../dtos/LoginRequestDTO';
import { CurrentUser } from '../entities/current-user.entity';
import { Role } from '../../../core/config/roles';

/** `portal` is the role card the user picked on the home page; the account must match it. */
export const login = createAction('[Auth] Login', props<{ dto: LoginRequestDTO; portal: Role | null }>());
export const loginSuccess = createAction('[Auth] Login Success', props<{ user: CurrentUser }>());
export const loginFailure = createAction('[Auth] Login Failure', props<{ error: string }>());

/** GET /auth/validate - restores the session from the stored JWT. */
export const loadCurrentUser = createAction('[Auth] Load Current User');
export const loadCurrentUserSuccess = createAction('[Auth] Load Current User Success', props<{ user: CurrentUser }>());
export const loadCurrentUserFailure = createAction('[Auth] Load Current User Failure', props<{ error: string }>());

export const logout = createAction('[Auth] Logout');
export const logoutSuccess = createAction('[Auth] Logout Success');
export const logoutFailure = createAction('[Auth] Logout Failure', props<{ error: string }>());

/** Dispatched by the interceptor when the token cannot be refreshed any more. */
export const sessionExpired = createAction('[Auth] Session Expired');
export const resetAuthStatuses = createAction('[Auth] Reset Statuses');
