import { createReducer, on } from '@ngrx/store';
import { failed, idleStatus, pending, succeeded } from '../../../shared/state/request-status';
import { AuthState, initialAuthState } from './auth.state';
import * as AuthActions from './auth.actions';

export const authReducer = createReducer(
  initialAuthState,
  on(AuthActions.login, (state): AuthState => ({ ...state, loginStatus: pending() })),
  on(AuthActions.loginSuccess, (state, { user }): AuthState => ({ ...state, user, checked: true, loginStatus: succeeded() })),
  on(AuthActions.loginFailure, (state, { error }): AuthState => ({ ...state, loginStatus: failed(error) })),

  on(AuthActions.loadCurrentUser, (state): AuthState => ({ ...state, loadCurrentUserStatus: pending() })),
  on(AuthActions.loadCurrentUserSuccess, (state, { user }): AuthState => ({ ...state, user, checked: true, loadCurrentUserStatus: succeeded() })),
  on(AuthActions.loadCurrentUserFailure, (state, { error }): AuthState => ({ ...state, user: null, checked: true, loadCurrentUserStatus: failed(error) })),

  on(AuthActions.logout, (state): AuthState => ({ ...state, logoutStatus: pending() })),
  on(AuthActions.logoutSuccess, (): AuthState => ({ ...initialAuthState, checked: true, logoutStatus: succeeded() })),
  on(AuthActions.logoutFailure, (state, { error }): AuthState => ({ ...state, logoutStatus: failed(error) })),

  on(AuthActions.sessionExpired, (): AuthState => ({ ...initialAuthState, checked: true })),
  on(AuthActions.resetAuthStatuses, (state): AuthState => ({ ...state, loginStatus: idleStatus, logoutStatus: idleStatus })),
);
