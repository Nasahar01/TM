import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AuthState } from './auth.state';

export const selectAuthState = createFeatureSelector<AuthState>('auth');
export const selectUser = createSelector(selectAuthState, (s) => s.user);
export const selectAuthChecked = createSelector(selectAuthState, (s) => s.checked);
export const selectUserId = createSelector(selectUser, (u) => u?.userId ?? null);
export const selectRole = createSelector(selectUser, (u) => u?.role ?? null);
export const selectLoginStatus = createSelector(selectAuthState, (s) => s.loginStatus);
export const selectLoadCurrentUserStatus = createSelector(selectAuthState, (s) => s.loadCurrentUserStatus);
export const selectLogoutStatus = createSelector(selectAuthState, (s) => s.logoutStatus);
