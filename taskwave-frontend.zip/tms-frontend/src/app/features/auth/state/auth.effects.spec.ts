import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideMockActions } from '@ngrx/effects/testing';
import { Action } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { API_URL } from '../../../core/config/api.config';
import { TokenStorage } from '../services/token-storage';
import * as A from './auth.actions';
import { AuthEffects } from './auth.effects';

const authResponse = { accessToken: 'acc', refreshToken: 'ref', tokenType: 'Bearer', expiresInSeconds: 900, userId: 3, name: 'Manu', email: 'manager@tms.com', role: 'PROJECT_MANAGER' };

describe('AuthEffects', () => {
  let actions$: Observable<Action>;
  let effects: AuthEffects;
  let http: HttpTestingController;
  let tokens: TokenStorage;
  let api: string;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthEffects, provideMockActions(() => actions$), provideHttpClient(), provideHttpClientTesting(), provideRouter([])],
    });
    effects = TestBed.inject(AuthEffects);
    http = TestBed.inject(HttpTestingController);
    tokens = TestBed.inject(TokenStorage);
    api = TestBed.inject(API_URL);
    tokens.clear();
  });

  afterEach(() => http.verify());

  it('login: waits one second, keeps the tokens and returns the user', fakeAsync(() => {
    actions$ = of(A.login({ dto: { email: 'manager@tms.com', password: 'x' }, portal: null }));
    let out: Action | undefined;
    effects.login$.subscribe((a) => (out = a));
    http.expectOne(`${api}/auth/login`).flush(authResponse);
    expect(out).toBeUndefined();
    tick(1000);
    expect(out).toEqual(A.loginSuccess({ user: { userId: 3, name: 'Manu', email: 'manager@tms.com', role: 'PROJECT_MANAGER' } }));
    expect(tokens.access()).toBe('acc');
    expect(tokens.refresh()).toBe('ref');
  }));

  it('login: wrong portal signs the account out again and reports it', fakeAsync(() => {
    actions$ = of(A.login({ dto: { email: 'manager@tms.com', password: 'x' }, portal: 'ADMIN' }));
    let out: any;
    effects.login$.subscribe((a) => (out = a));
    http.expectOne(`${api}/auth/login`).flush(authResponse);
    http.expectOne(`${api}/auth/logout`).flush(null, { status: 204, statusText: 'No Content' });
    tick(1000);
    expect(out.type).toBe(A.loginFailure.type);
    expect(out.error).toContain('Project Manager');
    expect(tokens.hasSession()).toBe(false);
  }));

  it('login: bad credentials become a failure with the server message', fakeAsync(() => {
    actions$ = of(A.login({ dto: { email: 'a@b.com', password: 'bad' }, portal: null }));
    let out: any;
    effects.login$.subscribe((a) => (out = a));
    http.expectOne(`${api}/auth/login`).flush({ message: 'Invalid email or password' }, { status: 401, statusText: 'Unauthorized' });
    tick(1000);
    expect(out).toEqual(A.loginFailure({ error: 'Invalid email or password' }));
  }));

  it('restore: no stored token fails at once without calling the server', fakeAsync(() => {
    actions$ = of(A.loadCurrentUser());
    let out: any;
    effects.loadCurrentUser$.subscribe((a) => (out = a));
    expect(out).toEqual(A.loadCurrentUserFailure({ error: '' }));
  }));

  it('restore: a stored token is validated and turned into the user', fakeAsync(() => {
    tokens.save({ accessToken: 'acc', refreshToken: 'ref' });
    actions$ = of(A.loadCurrentUser());
    let out: any;
    effects.loadCurrentUser$.subscribe((a) => (out = a));
    http.expectOne(`${api}/auth/validate`).flush({ valid: true, userId: 3, email: 'm@tms.com', name: 'Manu', role: 'PROJECT_MANAGER' });
    tick(1000);
    expect(out.type).toBe(A.loadCurrentUserSuccess.type);
    expect(out.user.userId).toBe(3);
  }));

  it('logout: forgets the tokens', fakeAsync(() => {
    tokens.save({ accessToken: 'acc', refreshToken: 'ref' });
    actions$ = of(A.logout());
    let out: any;
    effects.logout$.subscribe((a) => (out = a));
    http.expectOne(`${api}/auth/logout`).flush(null, { status: 204, statusText: 'No Content' });
    tick(1000);
    expect(out).toEqual(A.logoutSuccess());
    expect(tokens.hasSession()).toBe(false);
  }));
});
