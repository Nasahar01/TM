import { HttpErrorResponse } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, delay, map, of, switchMap, tap, throwError } from 'rxjs';
import { LOADING_DELAY, toMessage } from '../../../shared/state/request-status';
import { pretty } from '../../../shared/utils/format';
import { homeFor } from '../../../core/config/roles';
import { AuthResponseDTO } from '../dtos/AuthResponseDTO';
import { CurrentUser } from '../entities/current-user.entity';
import { AuthService } from '../services/auth-service';
import { TokenStorage } from '../services/token-storage';
import * as AuthActions from './auth.actions';

const toUser = (res: AuthResponseDTO): CurrentUser => ({ userId: res.userId, name: res.name, email: res.email, role: res.role });

@Injectable()
export class AuthEffects {
  private actions$ = inject(Actions);
  private api = inject(AuthService);
  private tokens = inject(TokenStorage);
  private router = inject(Router);

  /** POST /auth/login, keep the JWT pair, and make sure the account fits the portal that was chosen. */
  login$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthActions.login),
      switchMap(({ dto, portal }) =>
        this.api.login(dto).pipe(
          tap((res) => this.tokens.save(res)),
          map(toUser),
          switchMap((user) =>
            portal && user.role !== portal
              ? this.api.logout().pipe(
                  catchError(() => of(null)),
                  tap(() => this.tokens.clear()),
                  switchMap(() =>
                    throwError(() => new Error(`This is a ${pretty(user.role)} account. Please use the ${pretty(user.role)} sign-in.`)),
                  ),
                )
              : of(user),
          ),
          delay(LOADING_DELAY),
          map((user) => AuthActions.loginSuccess({ user })),
          catchError((err) => {
            this.tokens.clear();
            return of(AuthActions.loginFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY));
          }),
        ),
      ),
    ),
  );

  loginNavigate$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(AuthActions.loginSuccess),
        tap(({ user }) => {
          const redirect = this.router.parseUrl(this.router.url).queryParams['redirect'] as string | undefined;
          const safe = redirect && redirect.startsWith('/app') ? redirect : null;
          this.router.navigateByUrl(safe ?? homeFor(user.role));
        }),
      ),
    { dispatch: false },
  );

  /** Boot: if a token is stored, ask GET /auth/validate who it belongs to (the interceptor refreshes it if needed). */
  loadCurrentUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthActions.loadCurrentUser),
      switchMap(() =>
        !this.tokens.hasSession()
          ? of(AuthActions.loadCurrentUserFailure({ error: '' }))
          : this.api.validate().pipe(
              delay(LOADING_DELAY),
              map((info) => AuthActions.loadCurrentUserSuccess({ user: { userId: info.userId, name: info.name, email: info.email, role: info.role } })),
              catchError((err) => {
                const expired = err instanceof HttpErrorResponse && err.status === 401;
                if (expired) this.tokens.clear();
                return of(AuthActions.loadCurrentUserFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY));
              }),
            ),
      ),
    ),
  );

  /** The server logs the user out of every device; locally we always forget the tokens unless the server is unreachable. */
  logout$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthActions.logout),
      switchMap(() =>
        this.api.logout().pipe(
          delay(LOADING_DELAY),
          tap(() => this.tokens.clear()),
          map(() => AuthActions.logoutSuccess()),
          catchError((err) => {
            if (err instanceof HttpErrorResponse && err.status === 0) {
              return of(AuthActions.logoutFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY));
            }
            this.tokens.clear();
            return of(AuthActions.logoutSuccess()).pipe(delay(LOADING_DELAY));
          }),
        ),
      ),
    ),
  );

  logoutNavigate$ = createEffect(
    () => this.actions$.pipe(ofType(AuthActions.logoutSuccess), tap(() => this.router.navigate(['/']))),
    { dispatch: false },
  );

  sessionExpiredNavigate$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(AuthActions.sessionExpired),
        tap(() => this.router.navigate(['/login'], { queryParams: { redirect: this.router.url } })),
      ),
    { dispatch: false },
  );
}
