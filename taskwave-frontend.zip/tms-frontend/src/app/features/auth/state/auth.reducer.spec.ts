import { makeSession } from '../../../testing/factories';
import * as A from './auth.actions';
import { authReducer } from './auth.reducer';
import { initialAuthState } from './auth.state';

describe('authReducer', () => {
  it('login: pending -> success stores the user and marks the session as checked', () => {
    let s = authReducer(initialAuthState, A.login({ dto: { email: 'a@b.com', password: 'x' }, portal: null }));
    expect(s.loginStatus.loading).toBe(true);
    s = authReducer(s, A.loginSuccess({ user: makeSession({ role: 'ADMIN' }) }));
    expect(s.user!.role).toBe('ADMIN');
    expect(s.checked).toBe(true);
    expect(s.loginStatus.success).toBe(true);
  });

  it('login failure keeps the user signed out and shows the message', () => {
    const s = authReducer(initialAuthState, A.loginFailure({ error: 'Invalid email or password' }));
    expect(s.user).toBeNull();
    expect(s.loginStatus.error).toBe('Invalid email or password');
  });

  it('a failed session restore still finishes the boot check', () => {
    const s = authReducer(initialAuthState, A.loadCurrentUserFailure({ error: '' }));
    expect(s.checked).toBe(true);
    expect(s.user).toBeNull();
  });

  it('logout and session expiry reset to a checked, signed-out state', () => {
    const signedIn = authReducer(initialAuthState, A.loginSuccess({ user: makeSession() }));
    expect(authReducer(signedIn, A.logoutSuccess()).user).toBeNull();
    const expired = authReducer(signedIn, A.sessionExpired());
    expect(expired.user).toBeNull();
    expect(expired.checked).toBe(true);
  });

  it('resetAuthStatuses clears errors', () => {
    const s0 = authReducer(initialAuthState, A.loginFailure({ error: 'x' }));
    expect(authReducer(s0, A.resetAuthStatuses()).loginStatus.error).toBe('');
  });
});
