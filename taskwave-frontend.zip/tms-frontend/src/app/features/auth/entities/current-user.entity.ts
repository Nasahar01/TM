import { Role } from '../../../core/config/roles';

/** The signed-in person (from login/refresh, or restored with GET /auth/validate). */
export interface CurrentUser {
  userId: number;
  name: string;
  email: string;
  role: Role;
}

/** Body of GET /auth/validate (TokenInfoDTO). */
export interface TokenInfo {
  valid: boolean;
  userId: number;
  email: string;
  name: string;
  role: Role;
}
