import { Role } from '../../../core/config/roles';

/** Body of POST /auth/login and POST /auth/refresh (AuthResponseDTO in auth-service). */
export interface AuthResponseDTO {
  accessToken: string;
  refreshToken: string;
  tokenType: string;
  expiresInSeconds: number;
  userId: number;
  name: string;
  email: string;
  role: Role;
}
