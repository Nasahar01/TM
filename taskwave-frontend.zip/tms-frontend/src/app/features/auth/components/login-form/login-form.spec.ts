import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Store } from '@ngrx/store';
import { provideTestEnv } from '../../../../testing/test-env';
import { loginFailure } from '../../state/auth.actions';
import { LoginForm } from './login-form';

describe('LoginForm', () => {
  let fixture: ComponentFixture<LoginForm>;
  const host = () => fixture.nativeElement as HTMLElement;
  const submit = () => host().querySelector('button[type=submit]') as HTMLButtonElement;
  const type = (selector: string, value: string) => {
    const el = host().querySelector(selector) as HTMLInputElement;
    el.value = value;
    el.dispatchEvent(new Event('input'));
    fixture.detectChanges();
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [LoginForm], providers: provideTestEnv() }).compileComponents();
    fixture = TestBed.createComponent(LoginForm);
    fixture.detectChanges();
  });

  it('blocks the sign-in button until both fields are valid', () => {
    expect(submit().disabled).toBe(true);
    type('input[type=email]', 'not-an-email');
    type('input[formControlName=password]', 'secret');
    expect(submit().disabled).toBe(true);
    type('input[type=email]', 'asha@tms.com');
    expect(submit().disabled).toBe(false);
  });

  it('marks a wrong email red once the user has typed it', () => {
    type('input[type=email]', 'nope');
    expect(host().querySelector('.field--invalid')).toBeTruthy();
    expect(host().textContent).toContain('valid email');
  });

  it('shows the server error', () => {
    TestBed.inject(Store).dispatch(loginFailure({ error: 'Invalid email or password' }));
    fixture.detectChanges();
    expect(host().querySelector('.alert-error')?.textContent).toContain('Invalid email or password');
  });

  it('can switch portal and offers the demo account of that role', () => {
    const tabs = Array.from(host().querySelectorAll('.tab')) as HTMLButtonElement[];
    tabs.find((t) => t.textContent?.includes('Admin'))!.click();
    fixture.detectChanges();
    expect(host().querySelector('.demo')?.textContent).toContain('admin@tms.com');
  });
});
