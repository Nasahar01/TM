import { Component, inject, OnDestroy, OnInit, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { Btn } from '../../../../shared/components/btn/btn';
import { Field } from '../../../../shared/components/field/field';
import { Icon } from '../../../../shared/components/icon/icon';
import { notBlank } from '../../../../shared/utils/validators';
import { homeFor, ROLE_INFO, RoleInfo, roleBySlug } from '../../../../core/config/roles';
import { login, resetAuthStatuses } from '../../state/auth.actions';
import { selectLoginStatus, selectUser } from '../../state/auth.selectors';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.html',
  styleUrl: './login-form.css',
  imports: [ReactiveFormsModule, RouterLink, Field, Btn, Icon]
})
export class LoginForm implements OnInit, OnDestroy {

  private store = inject(Store);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  status = this.store.selectSignal(selectLoginStatus);
  user = this.store.selectSignal(selectUser);
  roles = ROLE_INFO;
  portal = signal<RoleInfo | null>(null);
  showPassword = signal(false);

  form = new FormGroup({
    email: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.email, Validators.maxLength(150)] }),
    password: new FormControl('', { nonNullable: true, validators: [Validators.required, notBlank, Validators.maxLength(64)] }),
  });

  ngOnInit(): void {
    this.store.dispatch(resetAuthStatuses());
    this.portal.set(roleBySlug(this.route.snapshot.queryParamMap.get('portal')) ?? null);
    // already signed in: skip the form
    const u = this.user();
    if (u) this.router.navigateByUrl(homeFor(u.role));
  }

  ngOnDestroy(): void {
    this.store.dispatch(resetAuthStatuses());
  }

  pick(role: RoleInfo | null): void {
    this.portal.set(role);
    this.router.navigate([], { queryParams: { portal: role?.slug ?? null }, queryParamsHandling: 'merge', replaceUrl: true });
  }

  fillDemo(): void {
    const demo = this.portal()?.demo;
    if (!demo) return;
    this.form.setValue({ email: demo.email, password: demo.password });
    this.form.markAsDirty();
  }

  submit(): void {
    if (this.form.invalid || this.status().loading) {
      this.form.markAllAsTouched();
      return;
    }
    this.store.dispatch(login({ dto: this.form.getRawValue(), portal: this.portal()?.role ?? null }));
  }
}
