import { TestBed } from '@angular/core/testing';
import { ActivatedRouteSnapshot, provideRouter, RouterStateSnapshot, UrlTree } from '@angular/router';
import { provideStore, Store } from '@ngrx/store';
import { firstValueFrom, isObservable, Observable } from 'rxjs';
import { makeSession } from '../../../testing/factories';
import { loadCurrentUserFailure, loginSuccess } from '../state/auth.actions';
import { authReducer } from '../state/auth.reducer';
import { authGuard } from './authGuard';
import { roleGuard } from './roleGuard';
import { roleHomeGuard } from './roleHomeGuard';

const run = async (guard: any, route: Partial<ActivatedRouteSnapshot> = {}, state: Partial<RouterStateSnapshot> = { url: '/app/projects' }) =>
  firstValueFrom(TestBed.runInInjectionContext(() => guard(route as ActivatedRouteSnapshot, state as RouterStateSnapshot)) as Observable<boolean | UrlTree>);

describe('route guards', () => {
  let store: Store;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideRouter([]), provideStore({ auth: authReducer })] });
    store = TestBed.inject(Store);
  });

  it('authGuard sends signed-out visitors to /login and remembers where they wanted to go', async () => {
    store.dispatch(loadCurrentUserFailure({ error: '' }));
    const result = (await run(authGuard)) as UrlTree;
    expect(result.toString()).toContain('/login');
    expect(result.toString()).toContain('redirect=%2Fapp%2Fprojects');
  });

  it('authGuard lets signed-in users in', async () => {
    store.dispatch(loginSuccess({ user: makeSession() }));
    expect(await run(authGuard)).toBe(true);
  });

  it('authGuard waits for the session check to finish', async () => {
    const pendingResult = run(authGuard);
    store.dispatch(loginSuccess({ user: makeSession() }));
    expect(await pendingResult).toBe(true);
  });

  it('roleGuard allows the listed roles and bounces the others to their dashboard', async () => {
    store.dispatch(loginSuccess({ user: makeSession({ role: 'TEAM_MEMBER' }) }));
    const bounced = (await run(roleGuard, { data: { roles: ['ADMIN'] } })) as UrlTree;
    expect(bounced.toString()).toBe('/app/dashboard');
    store.dispatch(loginSuccess({ user: makeSession({ role: 'ADMIN' }) }));
    expect(await run(roleGuard, { data: { roles: ['ADMIN'] } })).toBe(true);
  });

  it('roleHomeGuard redirects /app to the dashboard', async () => {
    store.dispatch(loginSuccess({ user: makeSession({ role: 'PROJECT_MANAGER' }) }));
    expect(isObservable(TestBed.runInInjectionContext(() => roleHomeGuard({} as any, {} as any)))).toBe(true);
    const result = (await run(roleHomeGuard)) as UrlTree;
    expect(result.toString()).toBe('/app/dashboard');
  });
});
