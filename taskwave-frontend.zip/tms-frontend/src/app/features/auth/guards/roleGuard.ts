import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { filter, map, switchMap, take } from 'rxjs';
import { homeFor, Role } from '../../../core/config/roles';
import { selectAuthChecked, selectUser } from '../state/auth.selectors';

/** Route data: { roles: ['ADMIN', ...] }. A wrong role is bounced to that user's own dashboard. */
export const roleGuard: CanActivateFn = (route) => {
  const store = inject(Store);
  const router = inject(Router);
  const allowed = (route.data['roles'] ?? []) as Role[];
  return store.select(selectAuthChecked).pipe(
    filter((checked) => checked),
    take(1),
    switchMap(() => store.select(selectUser).pipe(take(1))),
    map((user) => {
      if (!user) return router.createUrlTree(['/login']);
      return allowed.includes(user.role) ? true : router.createUrlTree([homeFor(user.role)]);
    }),
  );
};
