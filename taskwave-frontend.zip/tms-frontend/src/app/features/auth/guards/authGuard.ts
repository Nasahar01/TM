import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { filter, map, switchMap, take } from 'rxjs';
import { selectAuthChecked, selectUser } from '../state/auth.selectors';

/** Waits for the boot session check (GET /auth/validate), then lets signed-in users through. */
export const authGuard: CanActivateFn = (_route, state) => {
  const store = inject(Store);
  const router = inject(Router);
  return store.select(selectAuthChecked).pipe(
    filter((checked) => checked),
    take(1),
    switchMap(() => store.select(selectUser).pipe(take(1))),
    map((user) => (user ? true : router.createUrlTree(['/login'], { queryParams: { redirect: state.url } }))),
  );
};
