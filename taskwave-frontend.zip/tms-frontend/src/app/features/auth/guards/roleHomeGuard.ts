import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { filter, map, switchMap, take } from 'rxjs';
import { homeFor } from '../../../core/config/roles';
import { selectAuthChecked, selectUser } from '../state/auth.selectors';

/** Used on /app itself: sends each role to its dashboard. */
export const roleHomeGuard: CanActivateFn = () => {
  const store = inject(Store);
  const router = inject(Router);
  return store.select(selectAuthChecked).pipe(
    filter((checked) => checked),
    take(1),
    switchMap(() => store.select(selectUser).pipe(take(1))),
    map((user) => router.createUrlTree([user ? homeFor(user.role) : '/login'])),
  );
};
