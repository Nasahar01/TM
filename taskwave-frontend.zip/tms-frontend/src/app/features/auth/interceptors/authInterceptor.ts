import { HttpErrorResponse, HttpInterceptorFn, HttpRequest } from '@angular/common/http';
import { inject } from '@angular/core';
import { Store } from '@ngrx/store';
import { BehaviorSubject, catchError, filter, switchMap, take, throwError } from 'rxjs';
import { API_URL } from '../../../core/config/api.config';
import { AuthService } from '../services/auth-service';
import { TokenStorage } from '../services/token-storage';
import { sessionExpired } from '../state/auth.actions';
import { selectUser } from '../state/auth.selectors';

/** null = no refresh finished yet, '' = the refresh failed, anything else = the new access token. */
const refreshed$ = new BehaviorSubject<string | null>(null);
let refreshing = false;

const withToken = (req: HttpRequest<unknown>, token: string | null): HttpRequest<unknown> =>
  token ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }) : req;

/**
 * Adds `Authorization: Bearer <access token>` to every gateway call. When the gateway answers 401 the
 * interceptor swaps the refresh token for a new pair once (parallel calls wait for it) and replays the request.
 * If that fails too, the session ends.
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const api = inject(API_URL);
  if (!req.url.startsWith(api)) return next(req);

  const tokens = inject(TokenStorage);
  const store = inject(Store);
  const authApi = inject(AuthService);

  const path = req.url.slice(api.length);
  const isPublicAuthCall = path.startsWith('/auth/login') || path.startsWith('/auth/refresh');
  const outgoing = isPublicAuthCall ? req : withToken(req, tokens.access());

  const endSession = () => {
    tokens.clear();
    if (store.selectSignal(selectUser)()) store.dispatch(sessionExpired());
  };

  return next(outgoing).pipe(
    catchError((err: HttpErrorResponse) => {
      if (err.status !== 401 || isPublicAuthCall) return throwError(() => err);

      const refreshToken = tokens.refresh();
      if (!refreshToken) {
        endSession();
        return throwError(() => err);
      }

      if (refreshing) {
        return refreshed$.pipe(
          filter((t) => t !== null),
          take(1),
          switchMap((t) => (t ? next(withToken(req, t)) : throwError(() => err))),
        );
      }

      refreshing = true;
      refreshed$.next(null);
      return authApi.refresh(refreshToken).pipe(
        switchMap((res) => {
          tokens.save(res);
          refreshing = false;
          refreshed$.next(res.accessToken);
          return next(withToken(req, res.accessToken));
        }),
        catchError(() => {
          refreshing = false;
          refreshed$.next('');
          endSession();
          return throwError(() => err);
        }),
      );
    }),
  );
};
