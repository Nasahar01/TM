import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideStore } from '@ngrx/store';
import { API_URL } from '../../../core/config/api.config';
import { TokenStorage } from '../services/token-storage';
import { authReducer } from '../state/auth.reducer';
import { authInterceptor } from './authInterceptor';

const pair = { accessToken: 'new-acc', refreshToken: 'new-ref', tokenType: 'Bearer', expiresInSeconds: 900, userId: 1, name: 'A', email: 'a@b.c', role: 'TEAM_MEMBER' };

describe('authInterceptor', () => {
  let client: HttpClient;
  let http: HttpTestingController;
  let tokens: TokenStorage;
  let api: string;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(withInterceptors([authInterceptor])), provideHttpClientTesting(), provideStore({ auth: authReducer })],
    });
    client = TestBed.inject(HttpClient);
    http = TestBed.inject(HttpTestingController);
    tokens = TestBed.inject(TokenStorage);
    api = TestBed.inject(API_URL);
    tokens.save({ accessToken: 'old-acc', refreshToken: 'old-ref' });
  });

  afterEach(() => {
    http.verify();
    tokens.clear();
  });

  it('adds the bearer token to gateway calls', () => {
    client.get(`${api}/projects`).subscribe();
    const req = http.expectOne(`${api}/projects`);
    expect(req.request.headers.get('Authorization')).toBe('Bearer old-acc');
    req.flush({});
  });

  it('does not attach a token to login or to other hosts', () => {
    client.post(`${api}/auth/login`, {}).subscribe();
    expect(http.expectOne(`${api}/auth/login`).request.headers.has('Authorization')).toBe(false);
    client.get('https://example.com/data').subscribe();
    expect(http.expectOne('https://example.com/data').request.headers.has('Authorization')).toBe(false);
  });

  it('on 401 swaps the refresh token for a new pair and replays the call', () => {
    let body: unknown;
    client.get(`${api}/tasks/my`).subscribe((b) => (body = b));
    http.expectOne(`${api}/tasks/my`).flush({}, { status: 401, statusText: 'Unauthorized' });

    const refresh = http.expectOne(`${api}/auth/refresh`);
    expect(refresh.request.body).toEqual({ refreshToken: 'old-ref' });
    refresh.flush(pair);

    const retry = http.expectOne(`${api}/tasks/my`);
    expect(retry.request.headers.get('Authorization')).toBe('Bearer new-acc');
    retry.flush({ ok: true });
    expect(body).toEqual({ ok: true });
    expect(tokens.refresh()).toBe('new-ref');
  });

  it('when the refresh also fails, the tokens are dropped and the error surfaces', () => {
    let status = 0;
    client.get(`${api}/tasks/my`).subscribe({ error: (e) => (status = e.status) });
    http.expectOne(`${api}/tasks/my`).flush({}, { status: 401, statusText: 'Unauthorized' });
    http.expectOne(`${api}/auth/refresh`).flush({}, { status: 401, statusText: 'Unauthorized' });
    expect(status).toBe(401);
    expect(tokens.hasSession()).toBe(false);
  });
});
