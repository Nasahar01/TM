import { Injectable } from '@angular/core';

const ACCESS_KEY = 'tw.access';
const REFRESH_KEY = 'tw.refresh';

/** Keeps the JWT pair in localStorage (falls back to memory when storage is blocked). */
@Injectable({ providedIn: 'root' })
export class TokenStorage {
  private memory: Record<string, string> = {};

  access(): string | null {
    return this.read(ACCESS_KEY);
  }

  refresh(): string | null {
    return this.read(REFRESH_KEY);
  }

  hasSession(): boolean {
    return !!(this.access() || this.refresh());
  }

  save(tokens: { accessToken: string; refreshToken: string }): void {
    this.write(ACCESS_KEY, tokens.accessToken);
    this.write(REFRESH_KEY, tokens.refreshToken);
  }

  clear(): void {
    this.remove(ACCESS_KEY);
    this.remove(REFRESH_KEY);
  }

  private read(key: string): string | null {
    try {
      return localStorage.getItem(key) ?? this.memory[key] ?? null;
    } catch {
      return this.memory[key] ?? null;
    }
  }

  private write(key: string, value: string): void {
    this.memory[key] = value;
    try { localStorage.setItem(key, value); } catch { /* storage blocked: memory copy is enough */ }
  }

  private remove(key: string): void {
    delete this.memory[key];
    try { localStorage.removeItem(key); } catch { /* ignore */ }
  }
}
