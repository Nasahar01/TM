import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { API_URL } from '../../../core/config/api.config';
import { LoginRequestDTO } from '../dtos/LoginRequestDTO';
import { RefreshRequestDTO } from '../dtos/RefreshRequestDTO';
import { AuthResponseDTO } from '../dtos/AuthResponseDTO';
import { TokenInfo } from '../entities/current-user.entity';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private api = inject(API_URL);

  login(dto: LoginRequestDTO): Observable<AuthResponseDTO> {
    return this.http.post<AuthResponseDTO>(`${this.api}/auth/login`, dto);
  }

  /** Refresh tokens are rotated by the server: the response carries a brand-new pair. */
  refresh(refreshToken: string): Observable<AuthResponseDTO> {
    const body: RefreshRequestDTO = { refreshToken };
    return this.http.post<AuthResponseDTO>(`${this.api}/auth/refresh`, body);
  }

  /** Needs a valid access token; signs the caller out of every device (204). */
  logout(): Observable<void> {
    return this.http.post<void>(`${this.api}/auth/logout`, {});
  }

  /** Validates the stored access token and returns its claims. */
  validate(): Observable<TokenInfo> {
    return this.http.get<TokenInfo>(`${this.api}/auth/validate`);
  }
}
