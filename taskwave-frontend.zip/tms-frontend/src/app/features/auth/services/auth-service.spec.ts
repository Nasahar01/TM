import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { API_URL } from '../../../core/config/api.config';
import { AuthService } from './auth-service';
import { TokenStorage } from './token-storage';

describe('AuthService', () => {
  let service: AuthService;
  let http: HttpTestingController;
  let api: string;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    service = TestBed.inject(AuthService);
    http = TestBed.inject(HttpTestingController);
    api = TestBed.inject(API_URL);
  });

  afterEach(() => http.verify());

  it('logs in with POST /auth/login', () => {
    service.login({ email: 'a@b.com', password: 'x' }).subscribe();
    const req = http.expectOne(`${api}/auth/login`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ email: 'a@b.com', password: 'x' });
    req.flush({});
  });

  it('refreshes with the refresh token in the body', () => {
    service.refresh('r-token').subscribe();
    const req = http.expectOne(`${api}/auth/refresh`);
    expect(req.request.body).toEqual({ refreshToken: 'r-token' });
    req.flush({});
  });

  it('validates and logs out', () => {
    service.validate().subscribe();
    http.expectOne(`${api}/auth/validate`).flush({});
    service.logout().subscribe();
    const out = http.expectOne(`${api}/auth/logout`);
    expect(out.request.method).toBe('POST');
    out.flush(null);
  });
});

describe('TokenStorage', () => {
  beforeEach(() => TestBed.inject(TokenStorage).clear());

  it('keeps and clears the token pair', () => {
    const tokens = TestBed.inject(TokenStorage);
    expect(tokens.hasSession()).toBe(false);
    tokens.save({ accessToken: 'a', refreshToken: 'r' });
    expect(tokens.access()).toBe('a');
    expect(tokens.refresh()).toBe('r');
    expect(tokens.hasSession()).toBe(true);
    tokens.clear();
    expect(tokens.access()).toBeNull();
  });
});
