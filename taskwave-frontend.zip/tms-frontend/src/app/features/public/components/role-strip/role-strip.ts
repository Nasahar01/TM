import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Icon } from '../../../../shared/components/icon/icon';
import { ROLE_INFO } from '../../../../core/config/roles';

/** Three role cards on the home page. Each opens the login page for that portal. */
@Component({
  selector: 'app-role-strip',
  templateUrl: './role-strip.html',
  styleUrl: './role-strip.css',
  imports: [RouterLink, Icon]
})
export class RoleStrip {

  roles = ROLE_INFO;
}
