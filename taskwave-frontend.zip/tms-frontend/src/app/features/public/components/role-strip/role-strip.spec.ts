import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { RoleStrip } from './role-strip';

describe('RoleStrip', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [RoleStrip], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(RoleStrip);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
