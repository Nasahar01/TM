import { Component, HostListener, inject, signal } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { Store } from '@ngrx/store';
import { Icon } from '../../../../shared/components/icon/icon';
import { selectUser } from '../../../auth/state/auth.selectors';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.html',
  styleUrl: './navbar.css',
  imports: [RouterLink, RouterLinkActive, Icon]
})
export class Navbar {

  private store = inject(Store);
  user = this.store.selectSignal(selectUser);
  open = signal(false);
  scrolled = signal(false);

  links = [
    { label: 'Home', path: '/', exact: true },
    { label: 'Features', path: '/features', exact: false },
    { label: 'How it works', path: '/about', exact: false },
  ];

  @HostListener('window:scroll')
  onScroll(): void {
    this.scrolled.set(window.scrollY > 12);
  }
}
