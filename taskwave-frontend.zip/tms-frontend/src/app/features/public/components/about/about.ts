import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Icon } from '../../../../shared/components/icon/icon';
import { Reveal } from '../../../../shared/directives/reveal';
import { ROLE_INFO } from '../../../../core/config/roles';
import { STEPS } from '../../../../core/config/marketing';

@Component({
  selector: 'app-about',
  templateUrl: './about.html',
  styleUrl: './about.css',
  imports: [RouterLink, Icon, Reveal]
})
export class About {

  steps = STEPS;
  roles = ROLE_INFO;

  rules = [
    'Only an Admin can create user accounts and choose their role.',
    'A project always has exactly one project manager, who is also a team member.',
    'Tasks can only be assigned to members of the same project.',
    'Team members can change the status of tasks assigned to them.',
    'Completed tasks cannot be deleted: they stay as project history.',
    'Archived projects are read-only.',
    'Every status, assignee or detail change is written to the task history.',
  ];
}
