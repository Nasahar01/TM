import { Component, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { Icon } from '../../../../shared/components/icon/icon';
import { Reveal } from '../../../../shared/directives/reveal';
import { CountUp } from '../../../../shared/directives/count-up';
import { FAQS, FEATURES, MARQUEE, MATRIX, STEPS } from '../../../../core/config/marketing';
import { selectUser } from '../../../auth/state/auth.selectors';
import { BoardPreview } from '../board-preview/board-preview';
import { RoleStrip } from '../role-strip/role-strip';

@Component({
  selector: 'app-home',
  templateUrl: './home.html',
  styleUrl: './home.css',
  imports: [RouterLink, Icon, Reveal, CountUp, BoardPreview, RoleStrip]
})
export class Home {

  private store = inject(Store);
  user = this.store.selectSignal(selectUser);

  features = FEATURES;
  steps = STEPS;
  matrix = MATRIX;
  faqs = FAQS;
  marquee = [...MARQUEE, ...MARQUEE];
  openFaq = signal<number | null>(0);

  toggle(i: number): void {
    this.openFaq.set(this.openFaq() === i ? null : i);
  }
}
