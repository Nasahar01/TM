import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { NotFound } from './not-found';

describe('NotFound', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [NotFound], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(NotFound);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
