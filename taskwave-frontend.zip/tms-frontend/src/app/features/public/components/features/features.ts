import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Icon } from '../../../../shared/components/icon/icon';
import { Reveal } from '../../../../shared/directives/reveal';

interface Module { icon: string; title: string; lead: string; points: string[]; tone: string; }

@Component({
  selector: 'app-features',
  templateUrl: './features.html',
  styleUrl: './features.css',
  imports: [RouterLink, Icon, Reveal]
})
export class Features {

  modules: Module[] = [
    { icon: 'users', title: 'User management', tone: 'brand', lead: 'Admins create accounts and decide who is a Project Manager or Team Member.',
      points: ['Create, edit and deactivate users', 'Search and filter by name, role and status', 'Deactivated users keep their history'] },
    { icon: 'folder', title: 'Project management', tone: 'mint', lead: 'Every project has an owner, dates, a status and a team.',
      points: ['Planning, Active, On Hold, Completed and Archived states', 'Unique project code', 'Archived projects become read-only'] },
    { icon: 'user-plus', title: 'Team membership', tone: 'sky', lead: 'Managers build the team and control who sees the project.',
      points: ['Add several members at once', 'Removing someone un-assigns their tasks', 'Members only see projects they belong to'] },
    { icon: 'check-square', title: 'Task management', tone: 'sun', lead: 'Priority, due date and assignee on every task.',
      points: ['Low, Medium, High and Critical priorities', 'Overdue tasks are flagged automatically', 'Completed tasks are kept as history'] },
    { icon: 'columns', title: 'Kanban board', tone: 'coral', lead: 'A live board that feels like moving sticky notes.',
      points: ['Drag cards between To Do, In Progress, In Review and Done', 'Cards move instantly and roll back if the server refuses', 'Team members move only their own tasks'] },
    { icon: 'message', title: 'Collaboration', tone: 'brand', lead: 'Talk about the work where the work lives.',
      points: ['Comments on every task', 'Audit trail of status, assignee and detail changes', 'Who did it and when, always visible'] },
  ];
}
