import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { BoardPreview } from './board-preview';

describe('BoardPreview', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [BoardPreview], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(BoardPreview);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
