import { Component } from '@angular/core';
import { Icon } from '../../../../shared/components/icon/icon';

/** Pure-CSS animated mini Kanban board for the hero: cards glide from column to column in a loop. */
@Component({
  selector: 'app-board-preview',
  templateUrl: './board-preview.html',
  styleUrl: './board-preview.css',
  imports: [Icon]
})
export class BoardPreview {

  columns = [
    { label: 'To Do', color: '#8a86b8', count: 4, card: 'Write API docs' },
    { label: 'In Progress', color: '#3aa8ff', count: 3, card: 'Sprint planning' },
    { label: 'In Review', color: '#ffb429', count: 2, card: 'Fix login bug' },
    { label: 'Done', color: '#14c8a0', count: 8, card: 'Set up CI' },
  ];
}
