import { Role } from '../../../core/config/roles';

/** UserResponse (user-service). */
export interface User {
  id: number;
  name: string;
  email: string;
  role: Role;
  phone: string | null;
  department: string | null;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

/** UserSummaryDto: the light view used by pickers (GET /users/directory). */
export interface UserSummary {
  id: number;
  name: string;
  email: string;
  role: Role;
  active: boolean;
}
