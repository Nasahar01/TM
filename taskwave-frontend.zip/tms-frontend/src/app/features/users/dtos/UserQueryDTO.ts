/** Query string of GET /admin/users and GET /users/directory (0-based page, size 1-100). */
export interface UserQueryDTO {
  q?: string;
  role?: string;
  active?: boolean | null;
  page: number;
  size: number;
  sort?: string;
}
