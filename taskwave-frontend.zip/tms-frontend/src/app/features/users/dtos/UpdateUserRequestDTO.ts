import { Role } from '../../../core/config/roles';

/** Admin-only update of another user's account. */
export interface UpdateUserRequestDTO {
  name: string;
  role: Role;
  phone: string | null;
  department: string | null;
  active: boolean;
}
