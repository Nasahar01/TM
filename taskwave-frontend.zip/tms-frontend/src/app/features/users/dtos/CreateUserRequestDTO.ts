import { Role } from '../../../core/config/roles';

export interface CreateUserRequestDTO {
  name: string;
  email: string;
  password: string;
  role: Role;
  phone: string | null;
  department: string | null;
}
