export interface UpdateProfileRequestDTO {
  name: string;
  phone: string | null;
  department: string | null;
}
