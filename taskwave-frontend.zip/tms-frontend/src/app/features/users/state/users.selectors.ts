import { createFeatureSelector, createSelector } from '@ngrx/store';
import { UsersState } from './users.state';

export const selectUsersState = createFeatureSelector<UsersState>('users');
export const selectProfile = createSelector(selectUsersState, (s) => s.profile);
export const selectUsersPage = createSelector(selectUsersState, (s) => s.usersPage);
export const selectDirectory = createSelector(selectUsersState, (s) => s.directory);
export const selectLoadProfileStatus = createSelector(selectUsersState, (s) => s.loadProfileStatus);
export const selectUpdateProfileStatus = createSelector(selectUsersState, (s) => s.updateProfileStatus);
export const selectChangePasswordStatus = createSelector(selectUsersState, (s) => s.changePasswordStatus);
export const selectLoadUsersStatus = createSelector(selectUsersState, (s) => s.loadUsersStatus);
export const selectCreateUserStatus = createSelector(selectUsersState, (s) => s.createUserStatus);
export const selectUpdateUserStatus = createSelector(selectUsersState, (s) => s.updateUserStatus);
export const selectDeactivateUserStatus = createSelector(selectUsersState, (s) => s.deactivateUserStatus);
export const selectLoadDirectoryStatus = createSelector(selectUsersState, (s) => s.loadDirectoryStatus);
