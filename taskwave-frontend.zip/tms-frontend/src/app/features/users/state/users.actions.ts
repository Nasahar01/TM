import { createAction, props } from '@ngrx/store';
import { Page } from '../../../shared/entities/page.entity';
import { ChangePasswordRequestDTO } from '../dtos/ChangePasswordRequestDTO';
import { CreateUserRequestDTO } from '../dtos/CreateUserRequestDTO';
import { UpdateProfileRequestDTO } from '../dtos/UpdateProfileRequestDTO';
import { UpdateUserRequestDTO } from '../dtos/UpdateUserRequestDTO';
import { UserQueryDTO } from '../dtos/UserQueryDTO';
import { User, UserSummary } from '../entities/user.entity';

export const loadProfile = createAction('[Users] Load Profile');
export const loadProfileSuccess = createAction('[Users] Load Profile Success', props<{ profile: User }>());
export const loadProfileFailure = createAction('[Users] Load Profile Failure', props<{ error: string }>());

export const updateProfile = createAction('[Users] Update Profile', props<{ dto: UpdateProfileRequestDTO }>());
export const updateProfileSuccess = createAction('[Users] Update Profile Success', props<{ profile: User }>());
export const updateProfileFailure = createAction('[Users] Update Profile Failure', props<{ error: string }>());

export const changePassword = createAction('[Users] Change Password', props<{ dto: ChangePasswordRequestDTO }>());
export const changePasswordSuccess = createAction('[Users] Change Password Success');
export const changePasswordFailure = createAction('[Users] Change Password Failure', props<{ error: string }>());

export const loadUsers = createAction('[Users] Load Users', props<{ query: UserQueryDTO }>());
export const loadUsersSuccess = createAction('[Users] Load Users Success', props<{ page: Page<User> }>());
export const loadUsersFailure = createAction('[Users] Load Users Failure', props<{ error: string }>());

export const createUser = createAction('[Users] Create User', props<{ dto: CreateUserRequestDTO }>());
export const createUserSuccess = createAction('[Users] Create User Success', props<{ user: User }>());
export const createUserFailure = createAction('[Users] Create User Failure', props<{ error: string }>());

export const updateUser = createAction('[Users] Update User', props<{ userId: number; dto: UpdateUserRequestDTO }>());
export const updateUserSuccess = createAction('[Users] Update User Success', props<{ user: User }>());
export const updateUserFailure = createAction('[Users] Update User Failure', props<{ error: string }>());

export const deactivateUser = createAction('[Users] Deactivate User', props<{ userId: number }>());
export const deactivateUserSuccess = createAction('[Users] Deactivate User Success', props<{ userId: number }>());
export const deactivateUserFailure = createAction('[Users] Deactivate User Failure', props<{ error: string }>());

export const loadDirectory = createAction('[Users] Load Directory', props<{ query: UserQueryDTO }>());
export const loadDirectorySuccess = createAction('[Users] Load Directory Success', props<{ page: Page<UserSummary> }>());
export const loadDirectoryFailure = createAction('[Users] Load Directory Failure', props<{ error: string }>());

export const resetUsersStatuses = createAction('[Users] Reset Statuses');
