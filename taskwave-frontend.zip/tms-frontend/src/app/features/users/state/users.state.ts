import { Page } from '../../../shared/entities/page.entity';
import { idleStatus, RequestStatus } from '../../../shared/state/request-status';
import { User, UserSummary } from '../entities/user.entity';

export interface UsersState {
  profile: User | null;
  usersPage: Page<User> | null;
  directory: UserSummary[];
  loadProfileStatus: RequestStatus;
  updateProfileStatus: RequestStatus;
  changePasswordStatus: RequestStatus;
  loadUsersStatus: RequestStatus;
  createUserStatus: RequestStatus;
  updateUserStatus: RequestStatus;
  deactivateUserStatus: RequestStatus;
  loadDirectoryStatus: RequestStatus;
}

export const initialUsersState: UsersState = {
  profile: null,
  usersPage: null,
  directory: [],
  loadProfileStatus: idleStatus,
  updateProfileStatus: idleStatus,
  changePasswordStatus: idleStatus,
  loadUsersStatus: idleStatus,
  createUserStatus: idleStatus,
  updateUserStatus: idleStatus,
  deactivateUserStatus: idleStatus,
  loadDirectoryStatus: idleStatus,
};
