import { createReducer, on } from '@ngrx/store';
import { failed, idleStatus, pending, succeeded } from '../../../shared/state/request-status';
import { initialUsersState, UsersState } from './users.state';
import * as UsersActions from './users.actions';
import * as AuthActions from '../../auth/state/auth.actions';

export const usersReducer = createReducer(
  initialUsersState,
  on(UsersActions.loadProfile, (state): UsersState => ({ ...state, loadProfileStatus: pending() })),
  on(UsersActions.loadProfileSuccess, (state, r): UsersState => ({ ...state, loadProfileStatus: succeeded(), profile: r.profile })),
  on(UsersActions.loadProfileFailure, (state, { error }): UsersState => ({ ...state, loadProfileStatus: failed(error) })),

  on(UsersActions.updateProfile, (state): UsersState => ({ ...state, updateProfileStatus: pending() })),
  on(UsersActions.updateProfileSuccess, (state, r): UsersState => ({ ...state, updateProfileStatus: succeeded(), profile: r.profile })),
  on(UsersActions.updateProfileFailure, (state, { error }): UsersState => ({ ...state, updateProfileStatus: failed(error) })),

  on(UsersActions.changePassword, (state): UsersState => ({ ...state, changePasswordStatus: pending() })),
  on(UsersActions.changePasswordSuccess, (state): UsersState => ({ ...state, changePasswordStatus: succeeded() })),
  on(UsersActions.changePasswordFailure, (state, { error }): UsersState => ({ ...state, changePasswordStatus: failed(error) })),

  on(UsersActions.loadUsers, (state): UsersState => ({ ...state, loadUsersStatus: pending() })),
  on(UsersActions.loadUsersSuccess, (state, r): UsersState => ({ ...state, loadUsersStatus: succeeded(), usersPage: r.page })),
  on(UsersActions.loadUsersFailure, (state, { error }): UsersState => ({ ...state, loadUsersStatus: failed(error) })),

  on(UsersActions.createUser, (state): UsersState => ({ ...state, createUserStatus: pending() })),
  on(UsersActions.createUserSuccess, (state, r): UsersState => ({
    ...state,
    createUserStatus: succeeded(),
    usersPage: state.usersPage
      ? { ...state.usersPage, content: [r.user, ...state.usersPage.content].slice(0, Math.max(state.usersPage.size, 1)), totalElements: state.usersPage.totalElements + 1 }
      : state.usersPage,
  })),
  on(UsersActions.createUserFailure, (state, { error }): UsersState => ({ ...state, createUserStatus: failed(error) })),

  on(UsersActions.updateUser, (state, a): UsersState => ({ ...state, updateUserStatus: pending(a.userId) })),
  on(UsersActions.updateUserSuccess, (state, r): UsersState => ({
    ...state,
    updateUserStatus: succeeded(),
    usersPage: state.usersPage ? { ...state.usersPage, content: state.usersPage.content.map((u) => (u.id === r.user.id ? r.user : u)) } : state.usersPage,
  })),
  on(UsersActions.updateUserFailure, (state, { error }): UsersState => ({ ...state, updateUserStatus: failed(error) })),

  on(UsersActions.deactivateUser, (state, a): UsersState => ({ ...state, deactivateUserStatus: pending(a.userId) })),
  on(UsersActions.deactivateUserSuccess, (state, r): UsersState => ({
    ...state,
    deactivateUserStatus: succeeded(),
    usersPage: state.usersPage ? { ...state.usersPage, content: state.usersPage.content.map((u) => (u.id === r.userId ? { ...u, active: false } : u)) } : state.usersPage,
  })),
  on(UsersActions.deactivateUserFailure, (state, { error }): UsersState => ({ ...state, deactivateUserStatus: failed(error) })),

  on(UsersActions.loadDirectory, (state): UsersState => ({ ...state, loadDirectoryStatus: pending() })),
  on(UsersActions.loadDirectorySuccess, (state, r): UsersState => ({ ...state, loadDirectoryStatus: succeeded(), directory: r.page.content })),
  on(UsersActions.loadDirectoryFailure, (state, { error }): UsersState => ({ ...state, loadDirectoryStatus: failed(error) })),

  on(UsersActions.resetUsersStatuses, (state): UsersState => ({
    ...state,
    loadProfileStatus: idleStatus, updateProfileStatus: idleStatus, changePasswordStatus: idleStatus, loadUsersStatus: idleStatus,
    createUserStatus: idleStatus, updateUserStatus: idleStatus, deactivateUserStatus: idleStatus, loadDirectoryStatus: idleStatus,
  })),
  on(AuthActions.logoutSuccess, AuthActions.sessionExpired, (): UsersState => initialUsersState),
);
