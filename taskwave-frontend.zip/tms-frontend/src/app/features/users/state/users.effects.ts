import { inject, Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, delay, map, mergeMap, of, switchMap } from 'rxjs';
import { LOADING_DELAY, toMessage } from '../../../shared/state/request-status';
import { UserService } from '../services/user-service';
import * as UsersActions from './users.actions';

@Injectable()
export class UsersEffects {
  private actions$ = inject(Actions);
  private api = inject(UserService);

  loadProfile$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UsersActions.loadProfile),
      switchMap(() =>
        this.api.getMe().pipe(
          delay(LOADING_DELAY),
          map((res) => UsersActions.loadProfileSuccess({ profile: res })),
          catchError((err) => of(UsersActions.loadProfileFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  updateProfile$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UsersActions.updateProfile),
      mergeMap((a) =>
        this.api.updateMe(a.dto).pipe(
          delay(LOADING_DELAY),
          map((res) => UsersActions.updateProfileSuccess({ profile: res })),
          catchError((err) => of(UsersActions.updateProfileFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  changePassword$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UsersActions.changePassword),
      mergeMap((a) =>
        this.api.changePassword(a.dto).pipe(
          delay(LOADING_DELAY),
          map(() => UsersActions.changePasswordSuccess()),
          catchError((err) => of(UsersActions.changePasswordFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  loadUsers$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UsersActions.loadUsers),
      switchMap((a) =>
        this.api.getUsers(a.query).pipe(
          delay(LOADING_DELAY),
          map((res) => UsersActions.loadUsersSuccess({ page: res })),
          catchError((err) => of(UsersActions.loadUsersFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  createUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UsersActions.createUser),
      mergeMap((a) =>
        this.api.createUser(a.dto).pipe(
          delay(LOADING_DELAY),
          map((res) => UsersActions.createUserSuccess({ user: res })),
          catchError((err) => of(UsersActions.createUserFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  updateUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UsersActions.updateUser),
      mergeMap((a) =>
        this.api.updateUser(a.userId, a.dto).pipe(
          delay(LOADING_DELAY),
          map((res) => UsersActions.updateUserSuccess({ user: res })),
          catchError((err) => of(UsersActions.updateUserFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  deactivateUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UsersActions.deactivateUser),
      mergeMap((a) =>
        this.api.deactivateUser(a.userId).pipe(
          delay(LOADING_DELAY),
          map(() => UsersActions.deactivateUserSuccess({ userId: a.userId })),
          catchError((err) => of(UsersActions.deactivateUserFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  loadDirectory$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UsersActions.loadDirectory),
      switchMap((a) =>
        this.api.getDirectory(a.query).pipe(
          delay(LOADING_DELAY),
          map((res) => UsersActions.loadDirectorySuccess({ page: res })),
          catchError((err) => of(UsersActions.loadDirectoryFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );
}
