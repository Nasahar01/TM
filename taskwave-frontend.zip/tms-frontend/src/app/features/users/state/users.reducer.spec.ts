import { makeUser } from '../../../testing/factories';
import * as A from './users.actions';
import { usersReducer } from './users.reducer';
import { initialUsersState } from './users.state';

const page = (users = [makeUser()]) => ({ content: users, page: 0, size: 10, totalElements: users.length, totalPages: 1, last: true });

describe('usersReducer', () => {
  it('stores the profile and updates it after an edit', () => {
    let s = usersReducer(initialUsersState, A.loadProfileSuccess({ profile: makeUser() }));
    s = usersReducer(s, A.updateProfileSuccess({ profile: makeUser({ name: 'New Name' }) }));
    expect(s.profile!.name).toBe('New Name');
  });

  it('puts a newly created user on top of the page', () => {
    const start = { ...initialUsersState, usersPage: page() };
    const s = usersReducer(start, A.createUserSuccess({ user: makeUser({ id: 8, name: 'Newbie' }) }));
    expect(s.usersPage!.content[0].name).toBe('Newbie');
    expect(s.usersPage!.totalElements).toBe(2);
  });

  it('deactivating flips the row to inactive without removing it', () => {
    const start = { ...initialUsersState, usersPage: page() };
    const s = usersReducer(start, A.deactivateUserSuccess({ userId: 1 }));
    expect(s.usersPage!.content[0].active).toBe(false);
  });

  it('marks only the targeted row as busy', () => {
    const s = usersReducer(initialUsersState, A.deactivateUser({ userId: 4 }));
    expect(s.deactivateUserStatus).toEqual({ loading: true, success: false, error: '', target: 4 });
  });

  it('keeps the member directory as a plain list', () => {
    const s = usersReducer(initialUsersState, A.loadDirectorySuccess({ page: { content: [{ id: 1, name: 'A', email: 'a@b.c', role: 'TEAM_MEMBER', active: true }], page: 0, size: 50, totalElements: 1, totalPages: 1, last: true } }));
    expect(s.directory.length).toBe(1);
  });
});
