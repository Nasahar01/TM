import { HttpClient, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { API_URL } from '../../../core/config/api.config';
import { Page } from '../../../shared/entities/page.entity';
import { ChangePasswordRequestDTO } from '../dtos/ChangePasswordRequestDTO';
import { CreateUserRequestDTO } from '../dtos/CreateUserRequestDTO';
import { UpdateProfileRequestDTO } from '../dtos/UpdateProfileRequestDTO';
import { UpdateUserRequestDTO } from '../dtos/UpdateUserRequestDTO';
import { UserQueryDTO } from '../dtos/UserQueryDTO';
import { User, UserSummary } from '../entities/user.entity';

function toParams(query: UserQueryDTO): HttpParams {
  let params = new HttpParams().set('page', query.page).set('size', query.size);
  if (query.q?.trim()) params = params.set('q', query.q.trim());
  if (query.role) params = params.set('role', query.role);
  if (query.active !== undefined && query.active !== null) params = params.set('active', String(query.active));
  if (query.sort) params = params.set('sort', query.sort);
  return params;
}

@Injectable({ providedIn: 'root' })
export class UserService {
  private http = inject(HttpClient);
  private api = inject(API_URL);

  // ---- own profile (any signed-in user)
  getMe(): Observable<User> {
    return this.http.get<User>(`${this.api}/users/me`);
  }

  updateMe(dto: UpdateProfileRequestDTO): Observable<User> {
    return this.http.put<User>(`${this.api}/users/me`, dto);
  }

  changePassword(dto: ChangePasswordRequestDTO): Observable<void> {
    return this.http.put<void>(`${this.api}/users/me/password`, dto);
  }

  // ---- member picker (admin + project manager): active users only
  getDirectory(query: UserQueryDTO): Observable<Page<UserSummary>> {
    return this.http.get<Page<UserSummary>>(`${this.api}/users/directory`, { params: toParams(query) });
  }

  // ---- admin: manage users
  createUser(dto: CreateUserRequestDTO): Observable<User> {
    return this.http.post<User>(`${this.api}/admin/users`, dto);
  }

  getUsers(query: UserQueryDTO): Observable<Page<User>> {
    return this.http.get<Page<User>>(`${this.api}/admin/users`, { params: toParams(query) });
  }

  getUserById(id: number): Observable<User> {
    return this.http.get<User>(`${this.api}/admin/users/${id}`);
  }

  updateUser(id: number, dto: UpdateUserRequestDTO): Observable<User> {
    return this.http.put<User>(`${this.api}/admin/users/${id}`, dto);
  }

  /** Soft delete: the account is deactivated so project and task history stay intact. */
  deactivateUser(id: number): Observable<void> {
    return this.http.delete<void>(`${this.api}/admin/users/${id}`);
  }
}
