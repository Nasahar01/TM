import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { API_URL } from '../../../core/config/api.config';
import { UserService } from './user-service';

describe('UserService', () => {
  let service: UserService;
  let http: HttpTestingController;
  let api: string;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    service = TestBed.inject(UserService);
    http = TestBed.inject(HttpTestingController);
    api = TestBed.inject(API_URL);
  });

  afterEach(() => http.verify());

  it('reads and updates the own profile', () => {
    service.getMe().subscribe();
    http.expectOne(`${api}/users/me`).flush({});
    service.updateMe({ name: 'N', phone: null, department: null }).subscribe();
    expect(http.expectOne(`${api}/users/me`).request.method).toBe('PUT');
  });

  it('changes the password with PUT /users/me/password', () => {
    service.changePassword({ currentPassword: 'a', newPassword: 'b' }).subscribe();
    const req = http.expectOne(`${api}/users/me/password`);
    expect(req.request.method).toBe('PUT');
    expect(req.request.body).toEqual({ currentPassword: 'a', newPassword: 'b' });
    req.flush(null);
  });

  it('searches the admin list with role and active filters', () => {
    service.getUsers({ q: 'as', role: 'ADMIN', active: false, page: 0, size: 10 }).subscribe();
    const req = http.expectOne((r) => r.url === `${api}/admin/users`);
    expect(req.request.params.get('role')).toBe('ADMIN');
    expect(req.request.params.get('active')).toBe('false');
    req.flush({});
  });

  it('uses /users/directory for the member picker', () => {
    service.getDirectory({ q: 'a', page: 0, size: 50 }).subscribe();
    http.expectOne((r) => r.url === `${api}/users/directory`).flush({});
  });

  it('creates, updates and deactivates users through /admin/users', () => {
    service.createUser({ name: 'N', email: 'n@x.com', password: 'Passw0rd1', role: 'TEAM_MEMBER', phone: null, department: null }).subscribe();
    expect(http.expectOne(`${api}/admin/users`).request.method).toBe('POST');
    service.updateUser(3, { name: 'N', role: 'ADMIN', phone: null, department: null, active: true }).subscribe();
    expect(http.expectOne(`${api}/admin/users/3`).request.method).toBe('PUT');
    service.deactivateUser(3).subscribe();
    const del = http.expectOne(`${api}/admin/users/3`);
    expect(del.request.method).toBe('DELETE');
    del.flush(null);
  });
});
