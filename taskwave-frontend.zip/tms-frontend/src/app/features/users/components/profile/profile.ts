import { Component, effect, inject, OnInit, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Avatar } from '../../../../shared/components/avatar/avatar';
import { Badge } from '../../../../shared/components/badge/badge';
import { Btn } from '../../../../shared/components/btn/btn';
import { Field } from '../../../../shared/components/field/field';
import { Icon } from '../../../../shared/components/icon/icon';
import { PageHeader } from '../../../../shared/components/page-header/page-header';
import { differsFrom, matches, notBlank, phone, strongPassword } from '../../../../shared/utils/validators';
import { fmtDate } from '../../../../shared/utils/format';
import { selectUserId } from '../../../auth/state/auth.selectors';
import { changePassword, loadProfile, resetUsersStatuses, updateProfile } from '../../state/users.actions';
import { selectChangePasswordStatus, selectLoadProfileStatus, selectProfile, selectUpdateProfileStatus } from '../../state/users.selectors';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.html',
  styleUrl: './profile.css',
  imports: [ReactiveFormsModule, Avatar, Badge, Btn, Field, Icon, PageHeader]
})
export class Profile implements OnInit {

  private store = inject(Store);
  userId = this.store.selectSignal(selectUserId);
  profile = this.store.selectSignal(selectProfile);
  loadStatus = this.store.selectSignal(selectLoadProfileStatus);
  updateStatus = this.store.selectSignal(selectUpdateProfileStatus);
  passwordStatus = this.store.selectSignal(selectChangePasswordStatus);
  fmt = fmtDate;
  showPasswords = signal(false);
  private filled = false;
  private changing = false;

  form = new FormGroup({
    name: new FormControl('', { nonNullable: true, validators: [Validators.required, notBlank, Validators.maxLength(100)] }),
    phone: new FormControl('', { nonNullable: true, validators: [phone, Validators.maxLength(20)] }),
    department: new FormControl('', { nonNullable: true, validators: [Validators.maxLength(100)] }),
  });

  passwordForm = new FormGroup({
    currentPassword: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    newPassword: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.minLength(8), Validators.maxLength(64), strongPassword, differsFrom('currentPassword')] }),
    confirm: new FormControl('', { nonNullable: true, validators: [Validators.required, matches('newPassword')] }),
  });

  constructor() {
    effect(() => {
      const p = this.profile();
      if (p && !this.filled) {
        this.filled = true;
        this.form.reset({ name: p.name, phone: p.phone ?? '', department: p.department ?? '' });
      }
    });
    effect(() => {
      if (this.changing && this.passwordStatus().success) {
        this.changing = false;
        this.passwordForm.reset({ currentPassword: '', newPassword: '', confirm: '' });
      }
    });
    // changing the current / new password re-checks the rules that compare them
    this.passwordForm.controls.currentPassword.valueChanges.subscribe(() => this.passwordForm.controls.newPassword.updateValueAndValidity());
    this.passwordForm.controls.newPassword.valueChanges.subscribe(() => this.passwordForm.controls.confirm.updateValueAndValidity());
  }

  ngOnInit(): void {
    this.store.dispatch(resetUsersStatuses());
    this.store.dispatch(loadProfile());
  }

  save(): void {
    if (this.form.invalid || this.updateStatus().loading) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    this.store.dispatch(updateProfile({ dto: { name: v.name.trim(), phone: v.phone.trim() || null, department: v.department.trim() || null } }));
  }

  savePassword(): void {
    if (this.passwordForm.invalid || this.passwordStatus().loading) {
      this.passwordForm.markAllAsTouched();
      return;
    }
    const v = this.passwordForm.getRawValue();
    this.changing = true;
    this.store.dispatch(changePassword({ dto: { currentPassword: v.currentPassword, newPassword: v.newPassword } }));
  }
}
