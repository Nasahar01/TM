import { Component, computed, DestroyRef, inject, OnInit, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Store } from '@ngrx/store';
import { debounceTime, distinctUntilChanged, Subject } from 'rxjs';
import { Avatar } from '../../../../shared/components/avatar/avatar';
import { Badge } from '../../../../shared/components/badge/badge';
import { Btn } from '../../../../shared/components/btn/btn';
import { Icon } from '../../../../shared/components/icon/icon';
import { Modal } from '../../../../shared/components/modal/modal';
import { PageHeader } from '../../../../shared/components/page-header/page-header';
import { Pagination } from '../../../../shared/components/pagination/pagination';
import { ROLES } from '../../../../core/config/roles';
import { fmtDate, pretty } from '../../../../shared/utils/format';
import { selectUserId } from '../../../auth/state/auth.selectors';
import { User } from '../../entities/user.entity';
import { UserForm } from '../user-form/user-form';
import { deactivateUser, loadUsers, resetUsersStatuses } from '../../state/users.actions';
import { selectDeactivateUserStatus, selectLoadUsersStatus, selectUsersPage } from '../../state/users.selectors';

const PAGE_SIZE = 10;

@Component({
  selector: 'app-admin-users',
  templateUrl: './admin-users.html',
  styleUrl: './admin-users.css',
  imports: [Avatar, Badge, Btn, Icon, Modal, PageHeader, Pagination, UserForm]
})
export class AdminUsers implements OnInit {

  private store = inject(Store);
  private destroyRef = inject(DestroyRef);

  page = this.store.selectSignal(selectUsersPage);
  status = this.store.selectSignal(selectLoadUsersStatus);
  deactivateStatus = this.store.selectSignal(selectDeactivateUserStatus);
  me = this.store.selectSignal(selectUserId);
  rows = computed(() => this.page()?.content ?? []);

  roles = ROLES;
  pretty = pretty;
  fmt = fmtDate;
  q = signal('');
  roleFilter = signal('');
  activeFilter = signal('');
  pageIndex = signal(0);
  search$ = new Subject<string>();

  formOpen = signal(false);
  editing = signal<User | null>(null);
  confirming = signal<number | null>(null);

  constructor() {
    this.search$.pipe(debounceTime(350), distinctUntilChanged(), takeUntilDestroyed(this.destroyRef)).subscribe((v) => {
      this.q.set(v);
      this.pageIndex.set(0);
      this.load();
    });
  }

  ngOnInit(): void {
    this.store.dispatch(resetUsersStatuses());
    this.load();
  }

  load(): void {
    const active = this.activeFilter();
    this.store.dispatch(loadUsers({
      query: { q: this.q(), role: this.roleFilter() || undefined, active: active === '' ? undefined : active === 'true', page: this.pageIndex(), size: PAGE_SIZE, sort: 'name,asc' },
    }));
  }

  setRole(v: string): void { this.roleFilter.set(v); this.pageIndex.set(0); this.load(); }
  setActive(v: string): void { this.activeFilter.set(v); this.pageIndex.set(0); this.load(); }
  goTo(p: number): void { this.pageIndex.set(p); this.load(); }

  create(): void { this.editing.set(null); this.formOpen.set(true); }
  edit(u: User): void { this.editing.set(u); this.formOpen.set(true); }

  busy(u: User): boolean {
    return this.deactivateStatus().loading && this.deactivateStatus().target === u.id;
  }

  deactivate(u: User): void {
    this.confirming.set(null);
    this.store.dispatch(deactivateUser({ userId: u.id }));
  }
}
