import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { AdminUsers } from './admin-users';

describe('AdminUsers', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [AdminUsers], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(AdminUsers);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
