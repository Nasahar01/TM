import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { UserForm } from './user-form';

describe('UserForm', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [UserForm], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(UserForm);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
