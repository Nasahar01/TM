import { Component, effect, inject, input, output, untracked } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Btn } from '../../../../shared/components/btn/btn';
import { Field } from '../../../../shared/components/field/field';
import { ROLES, Role } from '../../../../core/config/roles';
import { notBlank, phone, strongPassword } from '../../../../shared/utils/validators';
import { pretty } from '../../../../shared/utils/format';
import { selectUserId } from '../../../auth/state/auth.selectors';
import { User } from '../../entities/user.entity';
import { createUser, resetUsersStatuses, updateUser } from '../../state/users.actions';
import { selectCreateUserStatus, selectUpdateUserStatus } from '../../state/users.selectors';

/** Admin form inside a modal: creates a user, or edits one when `user` is given. */
@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.html',
  styleUrl: './user-form.css',
  imports: [ReactiveFormsModule, Btn, Field]
})
export class UserForm {

  private store = inject(Store);

  user = input<User | null>(null);
  active = input<boolean>(false);
  done = output<void>();
  cancelled = output<void>();

  me = this.store.selectSignal(selectUserId);
  createStatus = this.store.selectSignal(selectCreateUserStatus);
  updateStatus = this.store.selectSignal(selectUpdateUserStatus);
  roles = ROLES;
  pretty = pretty;
  showPassword = false;
  private submitted = false;

  form = new FormGroup({
    name: new FormControl('', { nonNullable: true, validators: [Validators.required, notBlank, Validators.maxLength(100)] }),
    email: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.email, Validators.maxLength(150)] }),
    password: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.minLength(8), Validators.maxLength(64), strongPassword] }),
    role: new FormControl<Role>('TEAM_MEMBER', { nonNullable: true, validators: [Validators.required] }),
    phone: new FormControl('', { nonNullable: true, validators: [phone, Validators.maxLength(20)] }),
    department: new FormControl('', { nonNullable: true, validators: [Validators.maxLength(100)] }),
    active: new FormControl(true, { nonNullable: true }),
  });

  constructor() {
    effect(() => {
      if (!this.active()) return;
      const u = untracked(() => this.user());
      this.submitted = false;
      this.store.dispatch(resetUsersStatuses());
      this.form.reset({ name: u?.name ?? '', email: u?.email ?? '', password: '', role: u?.role ?? 'TEAM_MEMBER', phone: u?.phone ?? '', department: u?.department ?? '', active: u?.active ?? true });
      // editing: the email is fixed and no password is asked for
      const editing = !!u;
      if (editing) { this.form.controls.email.disable(); this.form.controls.password.disable(); }
      else { this.form.controls.email.enable(); this.form.controls.password.enable(); }
      // an admin cannot demote or deactivate themselves
      if (u && u.id === this.me()) { this.form.controls.role.disable(); this.form.controls.active.disable(); }
      else { this.form.controls.role.enable(); this.form.controls.active.enable(); }
    });
    effect(() => {
      const s = this.user() ? this.updateStatus() : this.createStatus();
      if (this.submitted && s.success) {
        this.submitted = false;
        this.done.emit();
      }
    });
  }

  status() {
    return this.user() ? this.updateStatus() : this.createStatus();
  }

  submit(): void {
    if (this.form.invalid || this.status().loading) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    const u = this.user();
    this.submitted = true;
    if (u) {
      this.store.dispatch(updateUser({ userId: u.id, dto: { name: v.name.trim(), role: v.role, phone: v.phone.trim() || null, department: v.department.trim() || null, active: v.active } }));
    } else {
      this.store.dispatch(createUser({ dto: { name: v.name.trim(), email: v.email.trim(), password: v.password, role: v.role, phone: v.phone.trim() || null, department: v.department.trim() || null } }));
    }
  }
}
