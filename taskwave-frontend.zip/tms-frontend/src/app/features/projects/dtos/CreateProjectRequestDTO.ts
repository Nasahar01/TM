export interface CreateProjectRequestDTO {
  name: string;
  description: string | null;
  startDate: string;
  endDate: string | null;
  /** Admin only: assign another project manager. Defaults to the caller. */
  managerId: number | null;
  /** Optional initial members (the manager is added automatically). */
  memberIds: number[];
}
