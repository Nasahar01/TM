/** Query string of GET /projects (0-based page, size 1-100). */
export interface ProjectQueryDTO {
  q?: string;
  status?: string;
  includeArchived?: boolean;
  page: number;
  size: number;
  sort?: string;
}
