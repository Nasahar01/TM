export interface AddMembersRequestDTO {
  userIds: number[];
}
