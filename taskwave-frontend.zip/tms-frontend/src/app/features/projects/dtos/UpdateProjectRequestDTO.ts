import { ProjectStatus } from '../../../core/config/task-meta';

export interface UpdateProjectRequestDTO {
  name: string;
  description: string | null;
  startDate: string;
  endDate: string | null;
  /** PLANNING | ACTIVE | ON_HOLD | COMPLETED (ARCHIVED goes through the archive endpoint) */
  status: ProjectStatus;
  /** Admin only: reassign the project manager. */
  managerId: number | null;
}
