import { ProjectStatus } from '../../../core/config/task-meta';
import { Role } from '../../../core/config/roles';
import { TaskSummary } from '../../tasks/entities/task.entity';

/** ProjectResponse (project-service). */
export interface Project {
  id: number;
  /** unique, human friendly identifier, e.g. PRJ-3F9A12BC */
  projectCode: string;
  name: string;
  description: string | null;
  startDate: string;
  endDate: string | null;
  status: ProjectStatus;
  managerId: number;
  managerName: string;
  memberCount: number;
  createdAt: string;
  updatedAt: string;
}

/** MemberResponse. The project manager is always one of the members. */
export interface Member {
  userId: number;
  name: string;
  email: string | null;
  role: Role | null;
  addedAt: string;
}

/** ProjectDetailResponse: project + members + progress (progress.available=false when task-service is down). */
export interface ProjectDetail {
  project: Project;
  members: Member[];
  progress: TaskSummary;
}
