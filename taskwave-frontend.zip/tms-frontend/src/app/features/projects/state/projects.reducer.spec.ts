import { makeDetail, makeMember, makeProject } from '../../../testing/factories';
import * as A from './projects.actions';
import { projectsReducer } from './projects.reducer';
import { initialProjectsState } from './projects.state';

describe('projectsReducer', () => {
  it('tracks loading and stores the list', () => {
    let s = projectsReducer(initialProjectsState, A.loadProjects({ query: { page: 0, size: 9 } }));
    expect(s.loadProjectsStatus.loading).toBe(true);
    s = projectsReducer(s, A.loadProjectsSuccess({ page: { content: [makeProject()], page: 0, size: 9, totalElements: 1, totalPages: 1, last: true } }));
    expect(s.page!.content.length).toBe(1);
    expect(s.loadProjectsStatus.success).toBe(true);
  });

  it('keeps list row and open project in step after an edit', () => {
    const start = { ...initialProjectsState, selected: makeDetail(), page: { content: [makeProject()], page: 0, size: 9, totalElements: 1, totalPages: 1, last: true } };
    const s = projectsReducer(start, A.updateProjectSuccess({ detail: makeDetail({ name: 'Renamed' }) }));
    expect(s.selected!.project.name).toBe('Renamed');
    expect(s.page!.content[0].name).toBe('Renamed');
  });

  it('replaces members after adding and updates the count', () => {
    const start = { ...initialProjectsState, selected: makeDetail() };
    const members = [makeMember(), makeMember({ userId: 2 }), makeMember({ userId: 3, name: 'New Person' })];
    const s = projectsReducer(start, A.addMembersSuccess({ projectId: 5, members }));
    expect(s.selected!.members.length).toBe(3);
    expect(s.selected!.project.memberCount).toBe(3);
  });

  it('removes a member locally once the server confirms', () => {
    const start = { ...initialProjectsState, selected: makeDetail() };
    const s = projectsReducer(start, A.removeMemberSuccess({ projectId: 5, userId: 1 }));
    expect(s.selected!.members.map((m) => m.userId)).toEqual([2]);
  });

  it('remembers progress per project', () => {
    const summary = { projectId: 5, total: 4, todo: 1, inProgress: 1, inReview: 0, done: 2, overdue: 0, completionPercentage: 50, available: true };
    const s = projectsReducer(initialProjectsState, A.loadProjectSummarySuccess({ summary }));
    expect(s.summaries[5].completionPercentage).toBe(50);
  });

  it('stores the failure message', () => {
    const s = projectsReducer(initialProjectsState, A.createProjectFailure({ error: 'Start date is required' }));
    expect(s.createProjectStatus.error).toBe('Start date is required');
  });
});
