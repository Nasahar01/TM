import { inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, delay, map, mergeMap, of, switchMap, tap } from 'rxjs';
import { LOADING_DELAY, toMessage } from '../../../shared/state/request-status';
import { ProjectService } from '../services/project-service';
import * as ProjectsActions from './projects.actions';

@Injectable()
export class ProjectsEffects {
  private actions$ = inject(Actions);
  private api = inject(ProjectService);
  private router = inject(Router);

  loadProjects$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProjectsActions.loadProjects),
      switchMap((a) =>
        this.api.getProjects(a.query).pipe(
          delay(LOADING_DELAY),
          map((res) => ProjectsActions.loadProjectsSuccess({ page: res })),
          catchError((err) => of(ProjectsActions.loadProjectsFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  /** Cards show live progress: fetch the summary of the (at most nine) visible projects once the list arrives. */
  loadSummariesForList$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProjectsActions.loadProjectsSuccess),
      mergeMap(({ page }) => page.content.slice(0, 9).map((p) => ProjectsActions.loadProjectSummary({ projectId: p.id }))),
    ),
  );

  loadProject$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProjectsActions.loadProject),
      switchMap((a) =>
        this.api.getProjectById(a.projectId).pipe(
          delay(LOADING_DELAY),
          map((res) => ProjectsActions.loadProjectSuccess({ detail: res })),
          catchError((err) => of(ProjectsActions.loadProjectFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  createProject$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProjectsActions.createProject),
      mergeMap((a) =>
        this.api.createProject(a.dto).pipe(
          delay(LOADING_DELAY),
          map((res) => ProjectsActions.createProjectSuccess({ detail: res })),
          catchError((err) => of(ProjectsActions.createProjectFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  createProjectNavigate$ = createEffect(
    () => this.actions$.pipe(ofType(ProjectsActions.createProjectSuccess), tap(({ detail }) => this.router.navigate(['/app/projects', detail.project.id]))),
    { dispatch: false },
  );

  updateProject$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProjectsActions.updateProject),
      mergeMap((a) =>
        this.api.updateProject(a.projectId, a.dto).pipe(
          delay(LOADING_DELAY),
          map((res) => ProjectsActions.updateProjectSuccess({ detail: res })),
          catchError((err) => of(ProjectsActions.updateProjectFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  updateProjectNavigate$ = createEffect(
    () => this.actions$.pipe(ofType(ProjectsActions.updateProjectSuccess), tap(({ detail }) => this.router.navigate(['/app/projects', detail.project.id]))),
    { dispatch: false },
  );

  archiveProject$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProjectsActions.archiveProject),
      mergeMap((a) =>
        this.api.archiveProject(a.projectId).pipe(
          delay(LOADING_DELAY),
          map((res) => ProjectsActions.archiveProjectSuccess({ detail: res })),
          catchError((err) => of(ProjectsActions.archiveProjectFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  addMembers$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProjectsActions.addMembers),
      mergeMap((a) =>
        this.api.addMembers(a.projectId, a.userIds).pipe(
          delay(LOADING_DELAY),
          map((res) => ProjectsActions.addMembersSuccess({ projectId: a.projectId, members: res })),
          catchError((err) => of(ProjectsActions.addMembersFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  removeMember$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProjectsActions.removeMember),
      mergeMap((a) =>
        this.api.removeMember(a.projectId, a.userId).pipe(
          delay(LOADING_DELAY),
          map(() => ProjectsActions.removeMemberSuccess({ projectId: a.projectId, userId: a.userId })),
          catchError((err) => of(ProjectsActions.removeMemberFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  loadProjectSummary$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProjectsActions.loadProjectSummary),
      mergeMap((a) =>
        this.api.getSummary(a.projectId).pipe(
          delay(LOADING_DELAY),
          map((res) => ProjectsActions.loadProjectSummarySuccess({ summary: res })),
          catchError((err) => of(ProjectsActions.loadProjectSummaryFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );
}
