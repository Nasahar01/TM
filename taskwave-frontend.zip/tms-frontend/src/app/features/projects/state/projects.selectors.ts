import { createFeatureSelector, createSelector } from '@ngrx/store';
import { ProjectsState } from './projects.state';

export const selectProjectsState = createFeatureSelector<ProjectsState>('projects');
export const selectProjectsPage = createSelector(selectProjectsState, (s) => s.page);
export const selectProjects = createSelector(selectProjectsPage, (p) => p?.content ?? []);
export const selectSelectedProject = createSelector(selectProjectsState, (s) => s.selected);
export const selectProjectSummaries = createSelector(selectProjectsState, (s) => s.summaries);
/** id -> name, so task lists that only carry projectId can show a project name. */
export const selectProjectNames = createSelector(selectProjects, (list) => Object.fromEntries(list.map((p) => [p.id, p.name])) as Record<number, string>);
export const selectLoadProjectsStatus = createSelector(selectProjectsState, (s) => s.loadProjectsStatus);
export const selectLoadProjectStatus = createSelector(selectProjectsState, (s) => s.loadProjectStatus);
export const selectCreateProjectStatus = createSelector(selectProjectsState, (s) => s.createProjectStatus);
export const selectUpdateProjectStatus = createSelector(selectProjectsState, (s) => s.updateProjectStatus);
export const selectArchiveProjectStatus = createSelector(selectProjectsState, (s) => s.archiveProjectStatus);
export const selectAddMembersStatus = createSelector(selectProjectsState, (s) => s.addMembersStatus);
export const selectRemoveMemberStatus = createSelector(selectProjectsState, (s) => s.removeMemberStatus);
