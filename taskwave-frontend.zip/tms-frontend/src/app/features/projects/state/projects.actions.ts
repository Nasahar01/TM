import { createAction, props } from '@ngrx/store';
import { Page } from '../../../shared/entities/page.entity';
import { TaskSummary } from '../../tasks/entities/task.entity';
import { CreateProjectRequestDTO } from '../dtos/CreateProjectRequestDTO';
import { ProjectQueryDTO } from '../dtos/ProjectQueryDTO';
import { UpdateProjectRequestDTO } from '../dtos/UpdateProjectRequestDTO';
import { Member, Project, ProjectDetail } from '../entities/project.entity';

export const loadProjects = createAction('[Projects] Load Projects', props<{ query: ProjectQueryDTO }>());
export const loadProjectsSuccess = createAction('[Projects] Load Projects Success', props<{ page: Page<Project> }>());
export const loadProjectsFailure = createAction('[Projects] Load Projects Failure', props<{ error: string }>());

export const loadProject = createAction('[Projects] Load Project', props<{ projectId: number }>());
export const loadProjectSuccess = createAction('[Projects] Load Project Success', props<{ detail: ProjectDetail }>());
export const loadProjectFailure = createAction('[Projects] Load Project Failure', props<{ error: string }>());

export const createProject = createAction('[Projects] Create Project', props<{ dto: CreateProjectRequestDTO }>());
export const createProjectSuccess = createAction('[Projects] Create Project Success', props<{ detail: ProjectDetail }>());
export const createProjectFailure = createAction('[Projects] Create Project Failure', props<{ error: string }>());

export const updateProject = createAction('[Projects] Update Project', props<{ projectId: number; dto: UpdateProjectRequestDTO }>());
export const updateProjectSuccess = createAction('[Projects] Update Project Success', props<{ detail: ProjectDetail }>());
export const updateProjectFailure = createAction('[Projects] Update Project Failure', props<{ error: string }>());

export const archiveProject = createAction('[Projects] Archive Project', props<{ projectId: number }>());
export const archiveProjectSuccess = createAction('[Projects] Archive Project Success', props<{ detail: ProjectDetail }>());
export const archiveProjectFailure = createAction('[Projects] Archive Project Failure', props<{ error: string }>());

export const addMembers = createAction('[Projects] Add Members', props<{ projectId: number; userIds: number[] }>());
export const addMembersSuccess = createAction('[Projects] Add Members Success', props<{ projectId: number; members: Member[] }>());
export const addMembersFailure = createAction('[Projects] Add Members Failure', props<{ error: string }>());

export const removeMember = createAction('[Projects] Remove Member', props<{ projectId: number; userId: number }>());
export const removeMemberSuccess = createAction('[Projects] Remove Member Success', props<{ projectId: number; userId: number }>());
export const removeMemberFailure = createAction('[Projects] Remove Member Failure', props<{ error: string }>());

/** Progress numbers for one project card (GET /projects/{id}/summary). */
export const loadProjectSummary = createAction('[Projects] Load Project Summary', props<{ projectId: number }>());
export const loadProjectSummarySuccess = createAction('[Projects] Load Project Summary Success', props<{ summary: TaskSummary }>());
export const loadProjectSummaryFailure = createAction('[Projects] Load Project Summary Failure', props<{ error: string }>());

/** Empties the list so another screen's (differently sized) page never flashes. */
export const clearProjectsPage = createAction('[Projects] Clear Projects Page');
export const clearSelectedProject = createAction('[Projects] Clear Selected Project');
export const resetProjectsStatuses = createAction('[Projects] Reset Statuses');
