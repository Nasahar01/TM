import { Page } from '../../../shared/entities/page.entity';
import { idleStatus, RequestStatus } from '../../../shared/state/request-status';
import { TaskSummary } from '../../tasks/entities/task.entity';
import { Project, ProjectDetail } from '../entities/project.entity';

export interface ProjectsState {
  page: Page<Project> | null;
  selected: ProjectDetail | null;
  /** progress per project id, shown on the project cards and dashboard */
  summaries: Record<number, TaskSummary>;
  loadProjectsStatus: RequestStatus;
  loadProjectStatus: RequestStatus;
  createProjectStatus: RequestStatus;
  updateProjectStatus: RequestStatus;
  archiveProjectStatus: RequestStatus;
  addMembersStatus: RequestStatus;
  removeMemberStatus: RequestStatus;
  loadProjectSummaryStatus: RequestStatus;
}

export const initialProjectsState: ProjectsState = {
  page: null,
  selected: null,
  summaries: {},
  loadProjectsStatus: idleStatus,
  loadProjectStatus: idleStatus,
  createProjectStatus: idleStatus,
  updateProjectStatus: idleStatus,
  archiveProjectStatus: idleStatus,
  addMembersStatus: idleStatus,
  removeMemberStatus: idleStatus,
  loadProjectSummaryStatus: idleStatus,
};
