import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideMockActions } from '@ngrx/effects/testing';
import { Action } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { API_URL } from '../../../core/config/api.config';
import { makeDetail, makeProject } from '../../../testing/factories';
import * as A from './projects.actions';
import { ProjectsEffects } from './projects.effects';

describe('ProjectsEffects', () => {
  let actions$: Observable<Action>;
  let effects: ProjectsEffects;
  let http: HttpTestingController;
  let api: string;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProjectsEffects, provideMockActions(() => actions$), provideHttpClient(), provideHttpClientTesting(), provideRouter([])],
    });
    effects = TestBed.inject(ProjectsEffects);
    http = TestBed.inject(HttpTestingController);
    api = TestBed.inject(API_URL);
  });

  afterEach(() => http.verify());

  it('loadProjects: returns the page after the loading delay', fakeAsync(() => {
    actions$ = of(A.loadProjects({ query: { page: 0, size: 9 } }));
    let out: any;
    effects.loadProjects$.subscribe((a) => (out = a));
    http.expectOne((r) => r.url === `${api}/projects`).flush({ content: [makeProject()], page: 0, size: 9, totalElements: 1, totalPages: 1, last: true });
    tick(1000);
    expect(out.type).toBe(A.loadProjectsSuccess.type);
  }));

  it('asks for the progress of every project in a freshly loaded list', () => {
    const page = { content: [makeProject({ id: 1 }), makeProject({ id: 2 })], page: 0, size: 9, totalElements: 2, totalPages: 1, last: true };
    actions$ = of(A.loadProjectsSuccess({ page }));
    const out: Action[] = [];
    effects.loadSummariesForList$.subscribe((a) => out.push(a));
    expect(out).toEqual([A.loadProjectSummary({ projectId: 1 }), A.loadProjectSummary({ projectId: 2 })]);
  });

  it('createProject: maps the backend error to a failure action', fakeAsync(() => {
    actions$ = of(A.createProject({ dto: { name: '', description: null, startDate: '2026-10-01', endDate: null, managerId: null, memberIds: [] } }));
    let out: any;
    effects.createProject$.subscribe((a) => (out = a));
    http.expectOne(`${api}/projects`).flush({ message: 'Project name is required' }, { status: 400, statusText: 'Bad Request' });
    tick(1000);
    expect(out).toEqual(A.createProjectFailure({ error: 'Project name is required' }));
  }));

  it('addMembers: success carries the new member list', fakeAsync(() => {
    actions$ = of(A.addMembers({ projectId: 5, userIds: [7] }));
    let out: any;
    effects.addMembers$.subscribe((a) => (out = a));
    http.expectOne(`${api}/projects/5/members`).flush(makeDetail().members);
    tick(1000);
    expect(out.type).toBe(A.addMembersSuccess.type);
    expect(out.members.length).toBe(2);
  }));
});
