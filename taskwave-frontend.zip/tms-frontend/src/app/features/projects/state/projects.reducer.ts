import { createReducer, on } from '@ngrx/store';
import { failed, idleStatus, pending, succeeded } from '../../../shared/state/request-status';
import { initialProjectsState, ProjectsState } from './projects.state';
import * as ProjectsActions from './projects.actions';
import * as AuthActions from '../../auth/state/auth.actions';

/** Keeps the list row and the open project in step after an edit / archive. */
const syncProject = (state: ProjectsState, detail: ProjectsState['selected']): Partial<ProjectsState> => ({
  selected: detail,
  page: state.page && detail ? { ...state.page, content: state.page.content.map((p) => (p.id === detail.project.id ? detail.project : p)) } : state.page,
});

export const projectsReducer = createReducer(
  initialProjectsState,
  on(ProjectsActions.loadProjects, (state): ProjectsState => ({ ...state, loadProjectsStatus: pending() })),
  on(ProjectsActions.loadProjectsSuccess, (state, r): ProjectsState => ({ ...state, loadProjectsStatus: succeeded(), page: r.page })),
  on(ProjectsActions.loadProjectsFailure, (state, { error }): ProjectsState => ({ ...state, loadProjectsStatus: failed(error) })),

  on(ProjectsActions.loadProject, (state): ProjectsState => ({ ...state, loadProjectStatus: pending() })),
  on(ProjectsActions.loadProjectSuccess, (state, r): ProjectsState => ({ ...state, loadProjectStatus: succeeded(), selected: r.detail })),
  on(ProjectsActions.loadProjectFailure, (state, { error }): ProjectsState => ({ ...state, loadProjectStatus: failed(error), selected: null })),

  on(ProjectsActions.createProject, (state): ProjectsState => ({ ...state, createProjectStatus: pending() })),
  on(ProjectsActions.createProjectSuccess, (state, r): ProjectsState => ({ ...state, createProjectStatus: succeeded(), selected: r.detail })),
  on(ProjectsActions.createProjectFailure, (state, { error }): ProjectsState => ({ ...state, createProjectStatus: failed(error) })),

  on(ProjectsActions.updateProject, (state, a): ProjectsState => ({ ...state, updateProjectStatus: pending(a.projectId) })),
  on(ProjectsActions.updateProjectSuccess, (state, r): ProjectsState => ({ ...state, ...syncProject(state, r.detail), updateProjectStatus: succeeded() })),
  on(ProjectsActions.updateProjectFailure, (state, { error }): ProjectsState => ({ ...state, updateProjectStatus: failed(error) })),

  on(ProjectsActions.archiveProject, (state, a): ProjectsState => ({ ...state, archiveProjectStatus: pending(a.projectId) })),
  on(ProjectsActions.archiveProjectSuccess, (state, r): ProjectsState => ({ ...state, ...syncProject(state, r.detail), archiveProjectStatus: succeeded() })),
  on(ProjectsActions.archiveProjectFailure, (state, { error }): ProjectsState => ({ ...state, archiveProjectStatus: failed(error) })),

  on(ProjectsActions.addMembers, (state, a): ProjectsState => ({ ...state, addMembersStatus: pending(a.projectId) })),
  on(ProjectsActions.addMembersSuccess, (state, r): ProjectsState => {
    const selected = state.selected && state.selected.project.id === r.projectId
      ? { ...state.selected, members: r.members, project: { ...state.selected.project, memberCount: r.members.length } }
      : state.selected;
    return { ...state, addMembersStatus: succeeded(), ...syncProject(state, selected) };
  }),
  on(ProjectsActions.addMembersFailure, (state, { error }): ProjectsState => ({ ...state, addMembersStatus: failed(error) })),

  on(ProjectsActions.removeMember, (state, a): ProjectsState => ({ ...state, removeMemberStatus: pending(a.userId) })),
  on(ProjectsActions.removeMemberSuccess, (state, r): ProjectsState => {
    const selected = state.selected && state.selected.project.id === r.projectId
      ? {
          ...state.selected,
          members: state.selected.members.filter((m) => m.userId !== r.userId),
          project: { ...state.selected.project, memberCount: Math.max(0, state.selected.project.memberCount - 1) },
        }
      : state.selected;
    return { ...state, removeMemberStatus: succeeded(), ...syncProject(state, selected) };
  }),
  on(ProjectsActions.removeMemberFailure, (state, { error }): ProjectsState => ({ ...state, removeMemberStatus: failed(error) })),

  on(ProjectsActions.loadProjectSummary, (state): ProjectsState => ({ ...state, loadProjectSummaryStatus: pending() })),
  on(ProjectsActions.loadProjectSummarySuccess, (state, r): ProjectsState => ({
    ...state,
    loadProjectSummaryStatus: succeeded(),
    summaries: { ...state.summaries, [r.summary.projectId]: r.summary },
  })),
  on(ProjectsActions.loadProjectSummaryFailure, (state, { error }): ProjectsState => ({ ...state, loadProjectSummaryStatus: failed(error) })),

  on(ProjectsActions.clearProjectsPage, (state): ProjectsState => ({ ...state, page: null, loadProjectsStatus: idleStatus })),
  on(ProjectsActions.clearSelectedProject, (state): ProjectsState => ({ ...state, selected: null, loadProjectStatus: idleStatus })),
  on(ProjectsActions.resetProjectsStatuses, (state): ProjectsState => ({
    ...state,
    loadProjectsStatus: idleStatus, loadProjectStatus: idleStatus, createProjectStatus: idleStatus, updateProjectStatus: idleStatus,
    archiveProjectStatus: idleStatus, addMembersStatus: idleStatus, removeMemberStatus: idleStatus, loadProjectSummaryStatus: idleStatus,
  })),
  on(AuthActions.logoutSuccess, AuthActions.sessionExpired, (): ProjectsState => initialProjectsState),
);
