import { HttpClient, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { API_URL } from '../../../core/config/api.config';
import { Page } from '../../../shared/entities/page.entity';
import { TaskSummary } from '../../tasks/entities/task.entity';
import { AddMembersRequestDTO } from '../dtos/AddMembersRequestDTO';
import { CreateProjectRequestDTO } from '../dtos/CreateProjectRequestDTO';
import { ProjectQueryDTO } from '../dtos/ProjectQueryDTO';
import { UpdateProjectRequestDTO } from '../dtos/UpdateProjectRequestDTO';
import { Member, Project, ProjectDetail } from '../entities/project.entity';

@Injectable({ providedIn: 'root' })
export class ProjectService {
  private http = inject(HttpClient);
  private api = inject(API_URL);

  createProject(dto: CreateProjectRequestDTO): Observable<ProjectDetail> {
    return this.http.post<ProjectDetail>(`${this.api}/projects`, dto);
  }

  /** Only the projects the caller may see (admin: all; others: managed or member of). */
  getProjects(query: ProjectQueryDTO): Observable<Page<Project>> {
    let params = new HttpParams().set('page', query.page).set('size', query.size);
    if (query.q?.trim()) params = params.set('q', query.q.trim());
    if (query.status) params = params.set('status', query.status);
    if (query.includeArchived !== undefined) params = params.set('includeArchived', String(query.includeArchived));
    if (query.sort) params = params.set('sort', query.sort);
    return this.http.get<Page<Project>>(`${this.api}/projects`, { params });
  }

  getProjectById(id: number): Observable<ProjectDetail> {
    return this.http.get<ProjectDetail>(`${this.api}/projects/${id}`);
  }

  updateProject(id: number, dto: UpdateProjectRequestDTO): Observable<ProjectDetail> {
    return this.http.put<ProjectDetail>(`${this.api}/projects/${id}`, dto);
  }

  archiveProject(id: number): Observable<ProjectDetail> {
    return this.http.patch<ProjectDetail>(`${this.api}/projects/${id}/archive`, {});
  }

  getSummary(id: number): Observable<TaskSummary> {
    return this.http.get<TaskSummary>(`${this.api}/projects/${id}/summary`);
  }

  getMembers(id: number): Observable<Member[]> {
    return this.http.get<Member[]>(`${this.api}/projects/${id}/members`);
  }

  /** Returns the full member list after the change. */
  addMembers(id: number, userIds: number[]): Observable<Member[]> {
    const body: AddMembersRequestDTO = { userIds };
    return this.http.post<Member[]>(`${this.api}/projects/${id}/members`, body);
  }

  /** The member's tasks in this project are un-assigned by the server. */
  removeMember(id: number, userId: number): Observable<void> {
    return this.http.delete<void>(`${this.api}/projects/${id}/members/${userId}`);
  }
}
