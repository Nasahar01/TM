import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { API_URL } from '../../../core/config/api.config';
import { ProjectService } from './project-service';

describe('ProjectService', () => {
  let service: ProjectService;
  let http: HttpTestingController;
  let api: string;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    service = TestBed.inject(ProjectService);
    http = TestBed.inject(HttpTestingController);
    api = TestBed.inject(API_URL);
  });

  afterEach(() => http.verify());

  it('creates a project', () => {
    const dto = { name: 'P', description: null, startDate: '2026-10-01', endDate: null, managerId: null, memberIds: [3, 4] };
    service.createProject(dto).subscribe();
    const req = http.expectOne(`${api}/projects`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body.memberIds).toEqual([3, 4]);
    req.flush({});
  });

  it('lists projects with search, status and archived flag', () => {
    service.getProjects({ q: 'web', status: 'ACTIVE', includeArchived: false, page: 2, size: 9, sort: 'updatedAt,desc' }).subscribe();
    const req = http.expectOne((r) => r.url === `${api}/projects`);
    expect(req.request.params.get('q')).toBe('web');
    expect(req.request.params.get('status')).toBe('ACTIVE');
    expect(req.request.params.get('includeArchived')).toBe('false');
    expect(req.request.params.get('page')).toBe('2');
    req.flush({});
  });

  it('gets, updates and archives a project', () => {
    service.getProjectById(5).subscribe();
    http.expectOne(`${api}/projects/5`).flush({});
    service.updateProject(5, { name: 'N', description: null, startDate: '2026-10-01', endDate: null, status: 'ON_HOLD', managerId: null }).subscribe();
    expect(http.expectOne(`${api}/projects/5`).request.method).toBe('PUT');
    service.archiveProject(5).subscribe();
    const arch = http.expectOne(`${api}/projects/5/archive`);
    expect(arch.request.method).toBe('PATCH');
    arch.flush({});
  });

  it('adds members as { userIds } and removes one by id', () => {
    service.addMembers(5, [7, 8]).subscribe();
    const add = http.expectOne(`${api}/projects/5/members`);
    expect(add.request.method).toBe('POST');
    expect(add.request.body).toEqual({ userIds: [7, 8] });
    add.flush([]);
    service.removeMember(5, 7).subscribe();
    const del = http.expectOne(`${api}/projects/5/members/7`);
    expect(del.request.method).toBe('DELETE');
    del.flush(null);
  });

  it('reads the summary and the members', () => {
    service.getSummary(5).subscribe();
    http.expectOne(`${api}/projects/5/summary`).flush({});
    service.getMembers(5).subscribe();
    http.expectOne(`${api}/projects/5/members`).flush([]);
  });
});
