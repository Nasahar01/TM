import { Component, computed, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Avatar } from '../../../../shared/components/avatar/avatar';
import { Badge } from '../../../../shared/components/badge/badge';
import { Icon } from '../../../../shared/components/icon/icon';
import { ProgressBar } from '../../../../shared/components/progress-bar/progress-bar';
import { fmtDate } from '../../../../shared/utils/format';
import { TaskSummary } from '../../../tasks/entities/task.entity';
import { Project } from '../../entities/project.entity';

/** Summary tile of one project with live progress. `summary` is undefined while it is still loading. */
@Component({
  selector: 'app-project-card',
  templateUrl: './project-card.html',
  styleUrl: './project-card.css',
  imports: [RouterLink, Avatar, Badge, Icon, ProgressBar]
})
export class ProjectCard {

  project = input.required<Project>();
  summary = input<TaskSummary | undefined>(undefined);

  dates = computed(() => {
    const p = this.project();
    return `${fmtDate(p.startDate)} → ${p.endDate ? fmtDate(p.endDate) : 'open ended'}`;
  });
  percent = computed(() => this.summary()?.completionPercentage ?? 0);
}
