import { Component, computed, DestroyRef, effect, inject, input, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Store } from '@ngrx/store';
import { debounceTime, distinctUntilChanged, Subject } from 'rxjs';
import { Avatar } from '../../../../shared/components/avatar/avatar';
import { Badge } from '../../../../shared/components/badge/badge';
import { Btn } from '../../../../shared/components/btn/btn';
import { Icon } from '../../../../shared/components/icon/icon';
import { Loading } from '../../../../shared/components/loading/loading';
import { fmtDate } from '../../../../shared/utils/format';
import { loadDirectory } from '../../../users/state/users.actions';
import { selectDirectory, selectLoadDirectoryStatus } from '../../../users/state/users.selectors';
import { ProjectDetail } from '../../entities/project.entity';
import { addMembers, removeMember } from '../../state/projects.actions';
import { selectAddMembersStatus, selectRemoveMemberStatus } from '../../state/projects.selectors';

/** Team tab: the member list, and (for managers) adding / removing people. */
@Component({
  selector: 'app-members-panel',
  templateUrl: './members-panel.html',
  styleUrl: './members-panel.css',
  imports: [Avatar, Badge, Btn, Icon, Loading]
})
export class MembersPanel {

  private store = inject(Store);
  private destroyRef = inject(DestroyRef);

  detail = input.required<ProjectDetail>();
  canManage = input<boolean>(false);

  directory = this.store.selectSignal(selectDirectory);
  directoryStatus = this.store.selectSignal(selectLoadDirectoryStatus);
  addStatus = this.store.selectSignal(selectAddMembersStatus);
  removeStatus = this.store.selectSignal(selectRemoveMemberStatus);

  adding = signal(false);
  picked = signal<number[]>([]);
  search = signal('');
  search$ = new Subject<string>();
  confirming = signal<number | null>(null);
  fmt = fmtDate;
  private submitted = false;

  members = computed(() => this.detail().members);
  managerId = computed(() => this.detail().project.managerId);
  /** people who are not in the project yet */
  candidates = computed(() => {
    const inTeam = new Set(this.members().map((m) => m.userId));
    return this.directory().filter((u) => !inTeam.has(u.id));
  });

  constructor() {
    this.search$.pipe(debounceTime(350), distinctUntilChanged(), takeUntilDestroyed(this.destroyRef)).subscribe((v) => {
      this.search.set(v);
      this.fetch();
    });
    effect(() => {
      if (this.submitted && this.addStatus().success) {
        this.submitted = false;
        this.adding.set(false);
        this.picked.set([]);
      }
    });
  }

  fetch(): void {
    this.store.dispatch(loadDirectory({ query: { q: this.search(), page: 0, size: 50, sort: 'name,asc' } }));
  }

  openPicker(): void {
    this.adding.set(true);
    this.picked.set([]);
    this.search.set('');
    this.fetch();
  }

  toggle(id: number): void {
    this.picked.update((ids) => (ids.includes(id) ? ids.filter((i) => i !== id) : [...ids, id]));
  }

  addSelected(): void {
    if (!this.picked().length || this.addStatus().loading) return;
    this.submitted = true;
    this.store.dispatch(addMembers({ projectId: this.detail().project.id, userIds: this.picked() }));
  }

  removing(userId: number): boolean {
    return this.removeStatus().loading && this.removeStatus().target === userId;
  }

  remove(userId: number): void {
    this.confirming.set(null);
    this.store.dispatch(removeMember({ projectId: this.detail().project.id, userId }));
  }
}
