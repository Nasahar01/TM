import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { MembersPanel } from './members-panel';

describe('MembersPanel', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [MembersPanel], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(MembersPanel);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
