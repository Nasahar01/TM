import { Component, computed, DestroyRef, inject, OnInit, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { debounceTime, distinctUntilChanged, Subject } from 'rxjs';
import { EmptyState } from '../../../../shared/components/empty-state/empty-state';
import { Icon } from '../../../../shared/components/icon/icon';
import { PageHeader } from '../../../../shared/components/page-header/page-header';
import { Pagination } from '../../../../shared/components/pagination/pagination';
import { PROJECT_STATUSES } from '../../../../core/config/task-meta';
import { pretty } from '../../../../shared/utils/format';
import { selectUser } from '../../../auth/state/auth.selectors';
import { clearProjectsPage, loadProjects, resetProjectsStatuses } from '../../state/projects.actions';
import { selectLoadProjectsStatus, selectProjectsPage, selectProjectSummaries } from '../../state/projects.selectors';
import { ProjectCard } from '../project-card/project-card';

const PAGE_SIZE = 9;

@Component({
  selector: 'app-projects-list',
  templateUrl: './projects-list.html',
  styleUrl: './projects-list.css',
  imports: [RouterLink, EmptyState, Icon, PageHeader, Pagination, ProjectCard]
})
export class ProjectsList implements OnInit {

  private store = inject(Store);
  private destroyRef = inject(DestroyRef);
  user = this.store.selectSignal(selectUser);
  page = this.store.selectSignal(selectProjectsPage);
  status = this.store.selectSignal(selectLoadProjectsStatus);
  summaries = this.store.selectSignal(selectProjectSummaries);

  statuses = PROJECT_STATUSES;
  pretty = pretty;
  q = signal('');
  statusFilter = signal('');
  pageIndex = signal(0);
  search$ = new Subject<string>();

  canCreate = computed(() => this.user()?.role !== 'TEAM_MEMBER');
  title = computed(() => (this.user()?.role === 'TEAM_MEMBER' ? 'My projects' : 'Projects'));
  projects = computed(() => this.page()?.content ?? []);
  filtered = computed(() => !!this.q().trim() || !!this.statusFilter());

  constructor() {
    this.search$.pipe(debounceTime(350), distinctUntilChanged(), takeUntilDestroyed(this.destroyRef)).subscribe((v) => {
      this.q.set(v);
      this.pageIndex.set(0);
      this.load();
    });
  }

  ngOnInit(): void {
    this.store.dispatch(resetProjectsStatuses());
    this.store.dispatch(clearProjectsPage());
    this.load();
  }

  load(): void {
    const status = this.statusFilter();
    this.store.dispatch(loadProjects({
      query: { q: this.q(), status: status || undefined, includeArchived: status === 'ARCHIVED' || undefined, page: this.pageIndex(), size: PAGE_SIZE, sort: 'updatedAt,desc' },
    }));
  }

  setStatus(value: string): void {
    this.statusFilter.set(value);
    this.pageIndex.set(0);
    this.load();
  }

  goTo(p: number): void {
    this.pageIndex.set(p);
    this.load();
  }
}
