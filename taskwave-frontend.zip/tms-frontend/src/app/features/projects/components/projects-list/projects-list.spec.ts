import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { ProjectsList } from './projects-list';

describe('ProjectsList', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [ProjectsList], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(ProjectsList);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
