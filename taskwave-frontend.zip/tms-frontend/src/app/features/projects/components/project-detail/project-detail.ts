import { Component, computed, effect, inject, OnDestroy, OnInit, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { map } from 'rxjs';
import { Avatar } from '../../../../shared/components/avatar/avatar';
import { Badge } from '../../../../shared/components/badge/badge';
import { Btn } from '../../../../shared/components/btn/btn';
import { Icon } from '../../../../shared/components/icon/icon';
import { Modal } from '../../../../shared/components/modal/modal';
import { fmtDate } from '../../../../shared/utils/format';
import { selectUser } from '../../../auth/state/auth.selectors';
import { clearThread } from '../../../comments/state/comments.actions';
import { KanbanBoard, TaskMove } from '../../../tasks/components/kanban-board/kanban-board';
import { TaskDetail } from '../../../tasks/components/task-detail/task-detail';
import { TaskForm } from '../../../tasks/components/task-form/task-form';
import { TaskTable } from '../../../tasks/components/task-table/task-table';
import { Task } from '../../../tasks/entities/task.entity';
import { clearTasks, loadBoard, resetTasksStatuses, updateTaskStatus } from '../../../tasks/state/tasks.actions';
import {
  selectBoard, selectBoardColumns, selectBoardSummary, selectLoadBoardStatus, selectUpdateTaskStatusStatus,
} from '../../../tasks/state/tasks.selectors';
import { canCreateTask, canManageProject, canMoveTask, isArchived } from '../../../tasks/utils/permissions';
import { archiveProject, clearSelectedProject, loadProject, resetProjectsStatuses } from '../../state/projects.actions';
import { selectArchiveProjectStatus, selectLoadProjectStatus, selectSelectedProject } from '../../state/projects.selectors';
import { MembersPanel } from '../members-panel/members-panel';

type Tab = 'board' | 'list' | 'team';

@Component({
  selector: 'app-project-detail',
  templateUrl: './project-detail.html',
  styleUrl: './project-detail.css',
  imports: [RouterLink, Avatar, Badge, Btn, Icon, Modal, KanbanBoard, TaskDetail, TaskForm, TaskTable, MembersPanel]
})
export class ProjectDetail implements OnInit, OnDestroy {

  private store = inject(Store);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  projectId = Number(this.route.snapshot.paramMap.get('id'));
  user = this.store.selectSignal(selectUser);
  detail = this.store.selectSignal(selectSelectedProject);
  loadStatus = this.store.selectSignal(selectLoadProjectStatus);
  archiveStatus = this.store.selectSignal(selectArchiveProjectStatus);
  board = this.store.selectSignal(selectBoard);
  columns = this.store.selectSignal(selectBoardColumns);
  boardStatus = this.store.selectSignal(selectLoadBoardStatus);
  liveSummary = this.store.selectSignal(selectBoardSummary);
  moveStatus = this.store.selectSignal(selectUpdateTaskStatusStatus);
  fmt = fmtDate;

  tab = signal<Tab>('board');
  confirmArchive = signal(false);
  formOpen = signal(false);
  editing = signal<Task | null>(null);

  /** ?task=ID in the URL opens the drawer, so a task link can be shared */
  taskParam = toSignal(this.route.queryParamMap.pipe(map((q) => Number(q.get('task')) || null)), { initialValue: null });
  /** kept after closing so the drawer can slide out with its content still in place */
  shownTaskId = signal<number | null>(null);

  actor = computed(() => { const u = this.user(); return u ? { userId: u.userId, role: u.role } : null; });
  project = computed(() => this.detail()?.project ?? null);
  members = computed(() => this.detail()?.members ?? []);
  summary = computed(() => this.liveSummary() ?? this.detail()?.progress ?? null);
  canManage = computed(() => canManageProject(this.detail(), this.actor()));
  canCreate = computed(() => canCreateTask(this.detail(), this.actor()));
  archived = computed(() => isArchived(this.detail()));
  mismatch = computed(() => !!this.detail() && this.detail()!.project.id !== this.projectId);
  movePredicate = computed(() => {
    const d = this.detail();
    const a = this.actor();
    return (t: Task) => canMoveTask(t, d, a);
  });
  savingTaskId = computed(() => (this.moveStatus().loading ? this.moveStatus().target : null));

  /** ring geometry: r = 52 -> circumference 326.7 */
  ringOffset = computed(() => 326.7 - (326.7 * (this.summary()?.completionPercentage ?? 0)) / 100);

  tabs: { id: Tab; label: string; icon: string }[] = [
    { id: 'board', label: 'Board', icon: 'columns' },
    { id: 'list', label: 'List', icon: 'list' },
    { id: 'team', label: 'Team', icon: 'users' },
  ];

  constructor() {
    effect(() => {
      const id = this.taskParam();
      if (id) this.shownTaskId.set(id);
    });
  }

  ngOnInit(): void {
    this.store.dispatch(resetProjectsStatuses());
    this.store.dispatch(resetTasksStatuses());
    this.store.dispatch(clearSelectedProject());
    this.store.dispatch(clearTasks());
    this.store.dispatch(loadProject({ projectId: this.projectId }));
    this.store.dispatch(loadBoard({ projectId: this.projectId }));
  }

  ngOnDestroy(): void {
    this.store.dispatch(clearThread());
  }

  openTask(id: number): void {
    this.router.navigate([], { relativeTo: this.route, queryParams: { task: id }, queryParamsHandling: 'merge' });
  }

  closeTask(): void {
    this.router.navigate([], { relativeTo: this.route, queryParams: { task: null }, queryParamsHandling: 'merge' });
  }

  newTask(): void {
    this.editing.set(null);
    this.formOpen.set(true);
  }

  editTask(task: Task): void {
    this.editing.set(task);
    this.formOpen.set(true);
  }

  onMove(m: TaskMove): void {
    this.store.dispatch(updateTaskStatus({ taskId: m.task.id, status: m.to, from: m.task.status }));
  }

  archive(): void {
    this.confirmArchive.set(false);
    this.store.dispatch(archiveProject({ projectId: this.projectId }));
  }

  reload(): void {
    this.ngOnInit();
  }
}
