import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { ProjectDetail } from './project-detail';

describe('ProjectDetail', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [ProjectDetail], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(ProjectDetail);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
