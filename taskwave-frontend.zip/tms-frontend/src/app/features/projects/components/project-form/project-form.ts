import { Component, computed, effect, inject, OnInit, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { Avatar } from '../../../../shared/components/avatar/avatar';
import { Btn } from '../../../../shared/components/btn/btn';
import { Field } from '../../../../shared/components/field/field';
import { Icon } from '../../../../shared/components/icon/icon';
import { Loading } from '../../../../shared/components/loading/loading';
import { PageHeader } from '../../../../shared/components/page-header/page-header';
import { EDITABLE_PROJECT_STATUSES, ProjectStatus } from '../../../../core/config/task-meta';
import { onOrAfter, notBlank } from '../../../../shared/utils/validators';
import { pretty, todayIso } from '../../../../shared/utils/format';
import { selectUser } from '../../../auth/state/auth.selectors';
import { loadDirectory } from '../../../users/state/users.actions';
import { selectDirectory, selectLoadDirectoryStatus } from '../../../users/state/users.selectors';
import { clearSelectedProject, createProject, loadProject, resetProjectsStatuses, updateProject } from '../../state/projects.actions';
import { selectCreateProjectStatus, selectLoadProjectStatus, selectSelectedProject, selectUpdateProjectStatus } from '../../state/projects.selectors';

/** One form for both /app/projects/new and /app/projects/:id/edit. */
@Component({
  selector: 'app-project-form',
  templateUrl: './project-form.html',
  styleUrl: './project-form.css',
  imports: [ReactiveFormsModule, RouterLink, Avatar, Btn, Field, Icon, Loading, PageHeader]
})
export class ProjectForm implements OnInit {

  private store = inject(Store);
  private route = inject(ActivatedRoute);

  user = this.store.selectSignal(selectUser);
  selected = this.store.selectSignal(selectSelectedProject);
  loadStatus = this.store.selectSignal(selectLoadProjectStatus);
  createStatus = this.store.selectSignal(selectCreateProjectStatus);
  updateStatus = this.store.selectSignal(selectUpdateProjectStatus);
  directory = this.store.selectSignal(selectDirectory);
  directoryStatus = this.store.selectSignal(selectLoadDirectoryStatus);

  projectId = Number(this.route.snapshot.paramMap.get('id')) || null;
  editing = !!this.projectId;
  statuses = EDITABLE_PROJECT_STATUSES;
  pretty = pretty;
  today = todayIso();
  memberIds = signal<number[]>([]);
  memberSearch = signal('');
  patched = signal(false);

  isAdmin = computed(() => this.user()?.role === 'ADMIN');
  status = computed(() => (this.editing ? this.updateStatus() : this.createStatus()));
  /** admin can hand the project to any admin / project manager */
  managers = computed(() => {
    const list = this.directory().filter((u) => u.role === 'ADMIN' || u.role === 'PROJECT_MANAGER');
    const current = this.selected()?.project;
    if (this.editing && current && !list.some((u) => u.id === current.managerId)) {
      return [{ id: current.managerId, name: current.managerName }, ...list];
    }
    return list;
  });
  candidates = computed(() => {
    const q = this.memberSearch().trim().toLowerCase();
    const me = this.user()?.userId;
    return this.directory().filter((u) => u.id !== me && (!q || u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q)));
  });

  form = new FormGroup({
    name: new FormControl('', { nonNullable: true, validators: [Validators.required, notBlank, Validators.maxLength(150)] }),
    description: new FormControl('', { nonNullable: true, validators: [Validators.maxLength(2000)] }),
    startDate: new FormControl(todayIso(), { nonNullable: true, validators: [Validators.required] }),
    endDate: new FormControl('', { nonNullable: true, validators: [onOrAfter('startDate')] }),
    status: new FormControl<ProjectStatus>('PLANNING', { nonNullable: true, validators: [Validators.required] }),
    managerId: new FormControl<number | null>(null),
  });

  constructor() {
    // fills the form once the project to edit has arrived
    effect(() => {
      const d = this.selected();
      if (this.editing && d && !this.patched() && d.project.id === this.projectId) {
        const p = d.project;
        this.form.patchValue({ name: p.name, description: p.description ?? '', startDate: p.startDate, endDate: p.endDate ?? '', status: p.status, managerId: p.managerId });
        this.patched.set(true);
      }
    });
  }

  ngOnInit(): void {
    this.store.dispatch(resetProjectsStatuses());
    this.store.dispatch(clearSelectedProject());
    this.form.controls.startDate.valueChanges.subscribe(() => this.form.controls.endDate.updateValueAndValidity());
    // the directory feeds the manager select (admin) and the initial-members picker (create)
    this.store.dispatch(loadDirectory({ query: { page: 0, size: 100, sort: 'name,asc' } }));
    if (this.editing) this.store.dispatch(loadProject({ projectId: this.projectId! }));
  }

  toggleMember(id: number): void {
    this.memberIds.update((ids) => (ids.includes(id) ? ids.filter((i) => i !== id) : [...ids, id]));
  }

  submit(): void {
    if (this.form.invalid || this.status().loading) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    const base = { name: v.name.trim(), description: v.description.trim() || null, startDate: v.startDate, endDate: v.endDate || null };
    if (this.editing) {
      this.store.dispatch(updateProject({ projectId: this.projectId!, dto: { ...base, status: v.status, managerId: this.isAdmin() ? v.managerId : null } }));
    } else {
      this.store.dispatch(createProject({ dto: { ...base, managerId: this.isAdmin() ? v.managerId : null, memberIds: this.memberIds() } }));
    }
  }
}
