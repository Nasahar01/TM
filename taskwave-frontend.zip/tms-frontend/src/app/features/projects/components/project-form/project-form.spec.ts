import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { ProjectForm } from './project-form';

describe('ProjectForm', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [ProjectForm], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(ProjectForm);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
