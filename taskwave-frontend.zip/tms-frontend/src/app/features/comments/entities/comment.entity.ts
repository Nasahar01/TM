/** CommentResponse (task-service). */
export interface Comment {
  id: number;
  taskId: number;
  authorId: number;
  authorName: string;
  content: string;
  createdAt: string;
}

export type HistoryAction = 'CREATED' | 'STATUS_CHANGED' | 'ASSIGNEE_CHANGED' | 'DETAILS_UPDATED';

/** TaskHistoryResponse: audit trail of who changed what and when. */
export interface TaskHistory {
  id: number;
  taskId: number;
  action: HistoryAction;
  fieldName: string;
  oldValue: string | null;
  newValue: string | null;
  changedById: number;
  changedByName: string;
  changedAt: string;
}
