export interface CommentRequestDTO {
  /** 1-2000 characters, not blank */
  content: string;
}
