import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { API_URL } from '../../../core/config/api.config';
import { CommentService } from './comment-service';

describe('CommentService', () => {
  let service: CommentService;
  let http: HttpTestingController;
  let api: string;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    service = TestBed.inject(CommentService);
    http = TestBed.inject(HttpTestingController);
    api = TestBed.inject(API_URL);
  });

  afterEach(() => http.verify());

  it('unwraps the page of comments', () => {
    let result: unknown[] = [];
    service.getComments(10).subscribe((c) => (result = c));
    const req = http.expectOne((r) => r.url === `${api}/tasks/10/comments`);
    expect(req.request.params.get('size')).toBe('100');
    req.flush({ content: [{ id: 1 }], page: 0, size: 100, totalElements: 1, totalPages: 1, last: true });
    expect(result.length).toBe(1);
  });

  it('posts a comment as { content }', () => {
    service.addComment(10, 'Looks good').subscribe();
    const req = http.expectOne(`${api}/tasks/10/comments`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ content: 'Looks good' });
    req.flush({});
  });

  it('reads the audit history', () => {
    service.getHistory(10).subscribe();
    http.expectOne(`${api}/tasks/10/history`).flush([]);
  });
});
