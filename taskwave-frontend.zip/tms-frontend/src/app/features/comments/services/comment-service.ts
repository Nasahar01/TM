import { HttpClient, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { API_URL } from '../../../core/config/api.config';
import { Page } from '../../../shared/entities/page.entity';
import { CommentRequestDTO } from '../dtos/CommentRequestDTO';
import { Comment, TaskHistory } from '../entities/comment.entity';

@Injectable({ providedIn: 'root' })
export class CommentService {
  private http = inject(HttpClient);
  private api = inject(API_URL);

  /** Oldest first. One page of up to 100 comments is plenty for a task discussion. */
  getComments(taskId: number): Observable<Comment[]> {
    const params = new HttpParams().set('page', 0).set('size', 100);
    return this.http.get<Page<Comment>>(`${this.api}/tasks/${taskId}/comments`, { params }).pipe(map((p) => p.content));
  }

  addComment(taskId: number, content: string): Observable<Comment> {
    const body: CommentRequestDTO = { content };
    return this.http.post<Comment>(`${this.api}/tasks/${taskId}/comments`, body);
  }

  /** Newest change first. */
  getHistory(taskId: number): Observable<TaskHistory[]> {
    return this.http.get<TaskHistory[]>(`${this.api}/tasks/${taskId}/history`);
  }
}
