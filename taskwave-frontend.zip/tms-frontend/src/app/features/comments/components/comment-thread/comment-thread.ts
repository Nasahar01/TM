import { Component, effect, inject, input } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Avatar } from '../../../../shared/components/avatar/avatar';
import { Btn } from '../../../../shared/components/btn/btn';
import { Field } from '../../../../shared/components/field/field';
import { Loading } from '../../../../shared/components/loading/loading';
import { notBlank } from '../../../../shared/utils/validators';
import { timeAgo } from '../../../../shared/utils/format';
import { selectUserId } from '../../../auth/state/auth.selectors';
import { addComment, resetCommentsStatuses } from '../../state/comments.actions';
import { selectAddCommentStatus, selectComments, selectLoadCommentsStatus } from '../../state/comments.selectors';

/** Discussion under a task: list of comments and a composer. */
@Component({
  selector: 'app-comment-thread',
  templateUrl: './comment-thread.html',
  styleUrl: './comment-thread.css',
  imports: [ReactiveFormsModule, Avatar, Btn, Field, Loading]
})
export class CommentThread {

  private store = inject(Store);

  taskId = input.required<number>();
  /** when false the composer is hidden (archived project) */
  canComment = input<boolean>(true);

  comments = this.store.selectSignal(selectComments);
  loadStatus = this.store.selectSignal(selectLoadCommentsStatus);
  addStatus = this.store.selectSignal(selectAddCommentStatus);
  me = this.store.selectSignal(selectUserId);
  ago = timeAgo;
  private submitted = false;

  form = new FormGroup({
    content: new FormControl('', { nonNullable: true, validators: [Validators.required, notBlank, Validators.maxLength(2000)] }),
  });

  constructor() {
    this.store.dispatch(resetCommentsStatuses());
    // clear the composer once the server accepted the comment
    effect(() => {
      if (this.submitted && this.addStatus().success) {
        this.submitted = false;
        this.form.reset({ content: '' });
      }
    });
  }

  submit(): void {
    if (this.form.invalid || this.addStatus().loading) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitted = true;
    this.store.dispatch(addComment({ taskId: this.taskId(), content: this.form.getRawValue().content.trim() }));
  }
}
