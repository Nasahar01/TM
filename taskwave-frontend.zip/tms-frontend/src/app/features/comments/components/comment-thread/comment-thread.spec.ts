import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { CommentThread } from './comment-thread';

describe('CommentThread', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [CommentThread], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(CommentThread);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
