import { TestBed } from '@angular/core/testing';
import { provideTestEnv } from '../../../../testing/test-env';
import { HistoryTimeline } from './history-timeline';

describe('HistoryTimeline', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [HistoryTimeline], providers: provideTestEnv() }).compileComponents();
  });

  it('should create', () => {
    const fixture = TestBed.createComponent(HistoryTimeline);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
