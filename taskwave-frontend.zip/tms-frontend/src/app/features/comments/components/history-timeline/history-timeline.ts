import { Component, computed, inject, input } from '@angular/core';
import { Store } from '@ngrx/store';
import { Icon } from '../../../../shared/components/icon/icon';
import { Loading } from '../../../../shared/components/loading/loading';
import { statusLabel } from '../../../../core/config/task-meta';
import { pretty, timeAgo } from '../../../../shared/utils/format';
import { Member } from '../../../projects/entities/project.entity';
import { TaskHistory } from '../../entities/comment.entity';
import { selectHistory, selectLoadHistoryStatus } from '../../state/comments.selectors';

/** Audit trail of a task: who changed what, newest first. */
@Component({
  selector: 'app-history-timeline',
  templateUrl: './history-timeline.html',
  styleUrl: './history-timeline.css',
  imports: [Icon, Loading]
})
export class HistoryTimeline {

  private store = inject(Store);

  /** used to turn assignee ids in the audit rows into names */
  members = input<Member[]>([]);
  history = this.store.selectSignal(selectHistory);
  status = this.store.selectSignal(selectLoadHistoryStatus);
  ago = timeAgo;

  rows = computed(() => this.history().map((h) => ({ h, text: this.describe(h), icon: this.icon(h) })));

  private person(id: string | null): string {
    if (!id) return 'nobody';
    return this.members().find((m) => String(m.userId) === id)?.name ?? `user #${id}`;
  }

  private shorten(v: string | null): string {
    const s = v ?? 'empty';
    return s.length > 40 ? `${s.slice(0, 40)}…` : s;
  }

  private describe(h: TaskHistory): string {
    switch (h.action) {
      case 'CREATED': return 'created this task';
      case 'STATUS_CHANGED': return `moved it from ${statusLabel(h.oldValue ?? '')} to ${statusLabel(h.newValue ?? '')}`;
      case 'ASSIGNEE_CHANGED': return h.oldValue ? `reassigned it from ${this.person(h.oldValue)} to ${this.person(h.newValue)}` : `assigned it to ${this.person(h.newValue)}`;
      default: return `changed ${pretty(h.fieldName)}: ${this.shorten(h.oldValue)} → ${this.shorten(h.newValue)}`;
    }
  }

  private icon(h: TaskHistory): string {
    return h.action === 'CREATED' ? 'plus' : h.action === 'STATUS_CHANGED' ? 'columns' : h.action === 'ASSIGNEE_CHANGED' ? 'user' : 'edit';
  }
}
