import { createAction, props } from '@ngrx/store';
import { Comment, TaskHistory } from '../entities/comment.entity';

export const loadComments = createAction('[Comments] Load Comments', props<{ taskId: number }>());
export const loadCommentsSuccess = createAction('[Comments] Load Comments Success', props<{ taskId: number; comments: Comment[] }>());
export const loadCommentsFailure = createAction('[Comments] Load Comments Failure', props<{ error: string }>());

export const addComment = createAction('[Comments] Add Comment', props<{ taskId: number; content: string }>());
export const addCommentSuccess = createAction('[Comments] Add Comment Success', props<{ comment: Comment }>());
export const addCommentFailure = createAction('[Comments] Add Comment Failure', props<{ error: string }>());

export const loadHistory = createAction('[Comments] Load History', props<{ taskId: number }>());
export const loadHistorySuccess = createAction('[Comments] Load History Success', props<{ taskId: number; history: TaskHistory[] }>());
export const loadHistoryFailure = createAction('[Comments] Load History Failure', props<{ error: string }>());

export const clearThread = createAction('[Comments] Clear Thread');
export const resetCommentsStatuses = createAction('[Comments] Reset Statuses');
