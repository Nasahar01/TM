import { commentsReducer } from './comments.reducer';
import * as A from './comments.actions';
import { initialCommentsState } from './comments.state';

const comment = (id: number, taskId = 10) => ({ id, taskId, authorId: 1, authorName: 'Asha', content: 'Hi', createdAt: '2026-10-28T10:00:00' });

describe('commentsReducer', () => {
  it('opening another task starts with an empty thread', () => {
    let s = commentsReducer(initialCommentsState, A.loadCommentsSuccess({ taskId: 10, comments: [comment(1)] }));
    s = commentsReducer(s, A.loadComments({ taskId: 11 }));
    expect(s.comments).toEqual([]);
    expect(s.taskId).toBe(11);
  });

  it('re-loading the same task keeps comments on screen', () => {
    let s = commentsReducer(initialCommentsState, A.loadCommentsSuccess({ taskId: 10, comments: [comment(1)] }));
    s = commentsReducer(s, A.loadComments({ taskId: 10 }));
    expect(s.comments.length).toBe(1);
  });

  it('appends a posted comment to the open thread only', () => {
    const open = commentsReducer(initialCommentsState, A.loadCommentsSuccess({ taskId: 10, comments: [comment(1)] }));
    expect(commentsReducer(open, A.addCommentSuccess({ comment: comment(2) })).comments.length).toBe(2);
    expect(commentsReducer(open, A.addCommentSuccess({ comment: comment(3, 99) })).comments.length).toBe(1);
  });

  it('clearThread empties everything', () => {
    const open = commentsReducer(initialCommentsState, A.loadCommentsSuccess({ taskId: 10, comments: [comment(1)] }));
    expect(commentsReducer(open, A.clearThread())).toEqual(initialCommentsState);
  });
});
