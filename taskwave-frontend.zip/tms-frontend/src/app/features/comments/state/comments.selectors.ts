import { createFeatureSelector, createSelector } from '@ngrx/store';
import { CommentsState } from './comments.state';

export const selectCommentsState = createFeatureSelector<CommentsState>('comments');
export const selectThreadTaskId = createSelector(selectCommentsState, (s) => s.taskId);
export const selectComments = createSelector(selectCommentsState, (s) => s.comments);
export const selectHistory = createSelector(selectCommentsState, (s) => s.history);
export const selectLoadCommentsStatus = createSelector(selectCommentsState, (s) => s.loadCommentsStatus);
export const selectAddCommentStatus = createSelector(selectCommentsState, (s) => s.addCommentStatus);
export const selectLoadHistoryStatus = createSelector(selectCommentsState, (s) => s.loadHistoryStatus);
