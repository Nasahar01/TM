import { createReducer, on } from '@ngrx/store';
import { failed, idleStatus, pending, succeeded } from '../../../shared/state/request-status';
import { CommentsState, initialCommentsState } from './comments.state';
import * as CommentsActions from './comments.actions';
import * as AuthActions from '../../auth/state/auth.actions';

export const commentsReducer = createReducer(
  initialCommentsState,
  // opening another task starts with an empty thread so old comments never flash
  on(CommentsActions.loadComments, (state, a): CommentsState => ({
    ...state,
    taskId: a.taskId,
    comments: state.taskId === a.taskId ? state.comments : [],
    loadCommentsStatus: pending(),
  })),
  on(CommentsActions.loadCommentsSuccess, (state, r): CommentsState => ({ ...state, loadCommentsStatus: succeeded(), taskId: r.taskId, comments: r.comments })),
  on(CommentsActions.loadCommentsFailure, (state, { error }): CommentsState => ({ ...state, loadCommentsStatus: failed(error) })),

  on(CommentsActions.addComment, (state, a): CommentsState => ({ ...state, addCommentStatus: pending(a.taskId) })),
  on(CommentsActions.addCommentSuccess, (state, r): CommentsState => ({
    ...state,
    addCommentStatus: succeeded(),
    comments: state.taskId === r.comment.taskId ? [...state.comments, r.comment] : state.comments,
  })),
  on(CommentsActions.addCommentFailure, (state, { error }): CommentsState => ({ ...state, addCommentStatus: failed(error) })),

  on(CommentsActions.loadHistory, (state, a): CommentsState => ({
    ...state,
    taskId: a.taskId,
    history: state.taskId === a.taskId ? state.history : [],
    loadHistoryStatus: pending(),
  })),
  on(CommentsActions.loadHistorySuccess, (state, r): CommentsState => ({ ...state, loadHistoryStatus: succeeded(), taskId: r.taskId, history: r.history })),
  on(CommentsActions.loadHistoryFailure, (state, { error }): CommentsState => ({ ...state, loadHistoryStatus: failed(error) })),

  on(CommentsActions.clearThread, (): CommentsState => initialCommentsState),
  on(CommentsActions.resetCommentsStatuses, (state): CommentsState => ({ ...state, loadCommentsStatus: idleStatus, addCommentStatus: idleStatus, loadHistoryStatus: idleStatus })),
  on(AuthActions.logoutSuccess, AuthActions.sessionExpired, (): CommentsState => initialCommentsState),
);
