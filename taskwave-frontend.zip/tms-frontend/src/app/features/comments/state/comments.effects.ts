import { inject, Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { catchError, delay, filter, map, mergeMap, of, switchMap, withLatestFrom } from 'rxjs';
import { LOADING_DELAY, toMessage } from '../../../shared/state/request-status';
import * as TasksActions from '../../tasks/state/tasks.actions';
import { CommentService } from '../services/comment-service';
import * as CommentsActions from './comments.actions';
import { selectThreadTaskId } from './comments.selectors';

@Injectable()
export class CommentsEffects {
  private actions$ = inject(Actions);
  private api = inject(CommentService);
  private store = inject(Store);

  loadComments$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CommentsActions.loadComments),
      switchMap((a) =>
        this.api.getComments(a.taskId).pipe(
          delay(LOADING_DELAY),
          map((res) => CommentsActions.loadCommentsSuccess({ taskId: a.taskId, comments: res })),
          catchError((err) => of(CommentsActions.loadCommentsFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  addComment$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CommentsActions.addComment),
      mergeMap((a) =>
        this.api.addComment(a.taskId, a.content).pipe(
          delay(LOADING_DELAY),
          map((res) => CommentsActions.addCommentSuccess({ comment: res })),
          catchError((err) => of(CommentsActions.addCommentFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  loadHistory$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CommentsActions.loadHistory),
      switchMap((a) =>
        this.api.getHistory(a.taskId).pipe(
          delay(LOADING_DELAY),
          map((res) => CommentsActions.loadHistorySuccess({ taskId: a.taskId, history: res })),
          catchError((err) => of(CommentsActions.loadHistoryFailure({ error: toMessage(err) })).pipe(delay(LOADING_DELAY))),
        ),
      ),
    ),
  );

  /** Every status / assignee / detail change adds an audit row: refresh the timeline of the task on screen. */
  refreshHistory$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TasksActions.updateTaskStatusSuccess, TasksActions.assignTaskSuccess, TasksActions.updateTaskSuccess),
      withLatestFrom(this.store.select(selectThreadTaskId)),
      filter(([{ task }, threadTaskId]) => task.id === threadTaskId),
      map(([{ task }]) => CommentsActions.loadHistory({ taskId: task.id })),
    ),
  );
}
