import { idleStatus, RequestStatus } from '../../../shared/state/request-status';
import { Comment, TaskHistory } from '../entities/comment.entity';

export interface CommentsState {
  /** the task whose thread is on screen */
  taskId: number | null;
  comments: Comment[];
  history: TaskHistory[];
  loadCommentsStatus: RequestStatus;
  addCommentStatus: RequestStatus;
  loadHistoryStatus: RequestStatus;
}

export const initialCommentsState: CommentsState = {
  taskId: null,
  comments: [],
  history: [],
  loadCommentsStatus: idleStatus,
  addCommentStatus: idleStatus,
  loadHistoryStatus: idleStatus,
};
