# Taskwave – Team Project & Task Management System (Angular 20 frontend)

Frontend for **Project 03 – Team Project & Task Management System** of the Team Alpha practice PRD.
Built with **Angular 20** (standalone components, signals, new control flow), **NgRx** (store + effects), **Tailwind CSS v4** and **Angular CDK drag & drop**.
It talks to the Spring Cloud API Gateway (`http://localhost:8080`) of the `team-task-management-backend` and follows the same
folder conventions as the VoyageGuard reference frontend.

## Run it

```bash
npm install
npm start              # http://localhost:4200  (the gateway's CORS allows exactly this origin)
npm run build          # production build in dist/
npm test               # Karma + Jasmine (needs Chrome)
```

Start the backend first (`api-gateway` on **:8080**, plus auth / user / project / task services and Eureka). To point the app at another
gateway change the default of the `API_URL` token in `src/app/core/config/api.config.ts`.

### Demo accounts (seeded by user-service)

| Role | Email | Password |
|---|---|---|
| Admin | `admin@tms.com` | `Admin@123` |
| Project Manager | `manager@tms.com` | `Manager@123` |
| Team Member | `member1@tms.com` | `Member@123` |

The login page has a role selector and a "Fill it in" shortcut for the chosen role.

## What is in the app

| Area | Screens | Who |
|---|---|---|
| Public | Home (animated hero board, features, roles, permissions matrix, FAQ), Features, How it works, Login, 404 | everyone, **no login needed** |
| Dashboard | Greeting, stats, "Up next", project progress cards | all roles |
| Projects | List (search, status filter, pagination), create / edit, detail with **Kanban board**, task **list**, **team** tab, progress ring, archive | all see theirs; Admin / PM create & manage |
| Tasks | Create / edit / delete, assign, status change (drag & drop or select), comments, audit history, **My tasks** | members of the project |
| Users | Create, edit, deactivate, search & filter, pagination | Admin |
| Profile | Edit details, change password | all roles |

### Permission rules mirrored in the UI (`features/tasks/utils/permissions.ts`)
The API still enforces everything; the UI only hides what would be refused.

* Admin: everything. Project Manager: full control of **own** projects. Team Member: sees only assigned projects.
* Anyone in a project can create and assign tasks (to project members only).
* A team member moves (updates the status of) **only tasks assigned to them**; Admin / owning PM move any task.
* Edit / delete a task: Admin, owning PM, or the creator. **Completed tasks cannot be deleted.**
* **Archived projects are read-only.**
* No self-registration: accounts are created by an Admin (PRD: *Manage Users – Admin only*).

## Project structure

```
src/app
├─ app.ts / app.html / app.config.ts / app.routes.ts   root, providers (store, effects, interceptor), lazy routes
├─ core/config        api.config (API_URL), roles (+ sidebar nav per role), task-meta (statuses, priorities), marketing copy
├─ shared
│  ├─ components      btn, field, loading, toast-container, animated-bg, badge, stat-card, page-header, icon,
│  │                  avatar, progress-bar, modal (dialog + drawer), empty-state, pagination
│  ├─ directives      reveal (scroll reveal), count-up
│  ├─ state           request-status (RequestStatus, LOADING_DELAY, toMessage)
│  ├─ entities        Page<T>
│  └─ utils           validators, format
├─ state/ui           toasts + notify.effects (single place that turns success/failure actions into toasts)
├─ testing            test-env (providers for specs), factories
└─ features/<module>
   ├─ dtos/           request bodies / query objects (…RequestDTO.ts)
   ├─ entities/       response models
   ├─ services/       one class per backend service: only HttpClient calls
   ├─ state/          actions · state · reducer · selectors · effects
   ├─ guards/ interceptors/ utils/   (where needed)
   └─ components/     <name>.ts · .html · .css · .spec.ts
```
Modules: `auth`, `users`, `projects`, `tasks`, `comments` (comments + audit history), `dashboard`, `public`.

### State pattern (same as the reference)
* Every async action has `action` → `actionSuccess` / `actionFailure` and a `RequestStatus { loading, success, error, target }` in state.
* **Every effect waits `LOADING_DELAY` = 1000 ms** (`shared/state/request-status.ts`) so the loading state is visible.
* Buttons are `app-btn`: **disabled and showing a spinner while `loading`**, and `[disabled]="form.invalid"` for forms.
* `app-field` turns the input **red as soon as a wrong value is typed (dirty) or the field is touched**, with the message underneath.
* Moving a Kanban card is **optimistic**: the card moves at once, the server confirms after the delay, and a refusal puts the card back.

## Backend contract used

| Feature | Calls (all via the gateway) |
|---|---|
| Auth | `POST /auth/login`, `POST /auth/refresh`, `POST /auth/logout`, `GET /auth/validate` |
| Session | `Authorization: Bearer <access>` on every call; on `401` the interceptor swaps the refresh token for a new pair **once** (parallel calls wait) and replays the request; if that fails the session ends |
| Profile | `GET/PUT /users/me`, `PUT /users/me/password` |
| Users (Admin) | `GET/POST /admin/users`, `GET/PUT/DELETE /admin/users/{id}` (DELETE = deactivate) |
| Member picker | `GET /users/directory` |
| Projects | `GET/POST /projects`, `GET/PUT /projects/{id}`, `PATCH /projects/{id}/archive`, `GET /projects/{id}/summary`, `GET/POST /projects/{id}/members`, `DELETE /projects/{id}/members/{userId}` |
| Tasks | `POST /tasks`, `GET /tasks/my`, `GET /tasks/project/{id}` (+`/board`, `/summary`), `GET/PUT/DELETE /tasks/{id}`, `PATCH /tasks/{id}/status`, `PUT /tasks/{id}/assignee` |
| Collaboration | `GET/POST /tasks/{id}/comments`, `GET /tasks/{id}/history` |

Lists are **server-side paginated and filtered** (`page`, `size`, `sort`, `q`, `status`, `priority`, `assigneeId`, …).

## PRD traceability (Project 3)

| PRD item | Where |
|---|---|
| M1 secure login, JWT, RBAC, profile, route guards | `features/auth` (login, interceptor, `authGuard`, `roleGuard`), `features/users/profile` |
| M2 create / edit projects, dates, status, manager, members, list, summary & progress | `projects-list`, `project-form`, `project-detail`, `members-panel`, progress ring |
| M3 create / edit / delete tasks, assign, priority, due date, 4 statuses | `task-form`, `task-detail`, `kanban-board`, `task-table` |
| M6 comments, update timestamps, completion summary | `comment-thread`, `task-detail`, `task-table` (Updated column), progress ring |
| US-01 … US-05 | login · create project + add members · **My tasks** · create & assign task · change status |
| Rules 1-7 | project code shown; assignee select limited to members; archive; assignee-only status moves; DONE tasks cannot be deleted |
| NFR usability / scalability / error handling / auditability | responsive layout, **drag-and-drop Kanban**, server-side paging, form validation + API error messages, **History** tab |

## Design & animation
Soft violet SaaS look (clean cards, gradient accents, floating product mock-up) in the spirit of Flowmark / Vortasky.
Smooth, `prefers-reduced-motion`-aware animations: view-transition route changes, staggered list entrances, scroll reveals, count-up numbers,
auto-playing hero board where cards glide between columns, drifting aurora background, marquee, animated progress ring / bars,
spring-eased modal and slide-in drawer, CDK drag preview with lift & settle, toast slide-ins, shimmering skeletons.

## Tests
`ng test` runs 64 spec files: reducers (incl. optimistic move + rollback), effects (1 s delay, failures), services (URL / method / params / body),
auth interceptor (bearer + refresh + replay), guards, validators, permission rules, key components (blocked buttons, red-on-touched fields,
login validation, Kanban drops) and page-level render tests against a populated store.
