import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../../../core/services/api.service';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
  <main class="auth-page">
    <a class="brand auth-brand" routerLink="/"><span class="brand-mark">f</span> flowboard</a>
    <section class="auth-card">
      <a routerLink="/" class="back-link">← Back to home</a>
      <div class="auth-symbol">✳</div><p class="eyebrow">CREATE YOUR ACCOUNT</p>
      <h1>Make room<br><em>to do.</em></h1>
      <p class="auth-copy">Create a Flowboard account to start collaborating with your team.</p>
      <form #signupForm="ngForm" (ngSubmit)="submit(signupForm)">
        <label for="name">Full name</label>
        <input id="name" name="name" [(ngModel)]="name" #nameField="ngModel" required maxlength="100" [class.invalid-field]="nameField.invalid&&nameField.touched" placeholder="Your full name">
        <small class="field-error" *ngIf="nameField.invalid&&nameField.touched">Enter your name (up to 100 characters).</small>
        <label for="email">Email address</label>
        <input id="email" name="email" type="email" [(ngModel)]="email" #emailField="ngModel" required email maxlength="150" [class.invalid-field]="emailField.invalid&&emailField.touched" placeholder="you@company.com">
        <small class="field-error" *ngIf="emailField.invalid&&emailField.touched">Enter a valid email address.</small>
        <label for="password">Password</label>
        <input id="password" name="password" type="password" [(ngModel)]="password" #passwordField="ngModel" required minlength="8" maxlength="64" [class.invalid-field]="passwordField.invalid&&passwordField.touched" placeholder="At least 8 characters">
        <small class="field-error" *ngIf="passwordField.invalid&&passwordField.touched">Password must be 8–64 characters.</small>
        <p class="error" *ngIf="error">{{error}}</p><p class="success" *ngIf="success">{{success}}</p>
        <button class="button button-dark button-full" [disabled]="signupForm.invalid||saving">{{saving?'Creating account…':'Create account ↗'}}</button>
      </form>
      <p class="auth-copy signup-switch">Already have an account? <a routerLink="/login">Sign in</a></p>
    </section>
    <p class="auth-foot">A little more clarity. A lot more momentum.</p>
  </main>`
})
export class Signup {
  private api = inject(ApiService);
  name=''; email=''; password=''; saving=false; error=''; success='';
  submit(form: NgForm) {
    if (form.invalid || this.saving) return;
    this.saving=true; this.error=''; this.success='';
    // The current backend source does not expose a public registration route.
    this.api.post<any>('/users/register',{name:this.name.trim(),email:this.email.trim(),password:this.password,role:'TEAM_MEMBER'})
      .subscribe({next:()=>{this.saving=false;this.success='Account created. You can now sign in.';this.name='';this.email='';this.password='';form.resetForm();},
      error:(e)=>{this.saving=false;this.error=e.status===404||e.status===405?'Self-service registration is not enabled by the current backend. Ask an administrator to create your account, or enable POST /users/register in the user service.':(e.error?.message||'Could not create your account. Please try again.');}});
  }
}
