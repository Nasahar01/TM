# Backend alignment notes (reviewed 2026-10-27)

This Angular 20 frontend targets the gateway at `http://localhost:8080`. Public gateway routes confirmed from the supplied Java backend:

- `POST /auth/login`, `POST /auth/refresh`, `POST /auth/logout`, `GET /auth/validate`
- `GET/PUT /users/me`, `PUT /users/me/password`, `GET /users/directory`
- Admin users: `POST/GET /admin/users`, `GET/PUT/DELETE /admin/users/{id}`
- Projects: `POST/GET /projects`, `GET/PUT /projects/{id}`, `PATCH /projects/{id}/archive`, `GET /projects/{id}/summary`, `GET/POST /projects/{id}/members`, `DELETE /projects/{id}/members/{userId}`
- Tasks: `POST /tasks`, `GET /tasks/my`, `GET /tasks/project/{projectId}`, `GET /tasks/project/{projectId}/board`, `GET /tasks/project/{projectId}/summary`, `GET/PUT/DELETE /tasks/{id}`, `PATCH /tasks/{id}/status`, `PUT /tasks/{id}/assignee`, `GET /tasks/{id}/history`, `GET/POST /tasks/{id}/comments`

Important contract details: `AddMembersRequest` uses `{ userIds: number[] }`; project creation uses `memberIds`; list endpoints use `page` (zero-based) and `size`; project response uses `projectCode`; task comments use `authorId`/`authorName`; task history uses `action`, `changedById`, and `changedByName`. Status enums are `TODO`, `IN_PROGRESS`, `IN_REVIEW`, `DONE`; priority enums are `LOW`, `MEDIUM`, `HIGH`, `CRITICAL`; project statuses are `PLANNING`, `ACTIVE`, `ON_HOLD`, `COMPLETED`, `ARCHIVED`.

## PRD role behavior represented in UI
- ADMIN: can create projects, access the admin user directory, and use admin project/task workflows supported by the backend.
- PROJECT_MANAGER: can create projects and coordinate members/tasks within projects they manage.
- TEAM_MEMBER: sees assigned tasks and available project spaces; task creation/project creation controls are hidden. Backend authorization remains the source of truth.

## Validation/loading
Login, project creation, task creation and admin user creation use Angular template-driven validation. Invalid fields turn red after touch; submit buttons remain disabled until valid and while requests are in flight. Task status controls and user deactivation lock while their requests are pending.

## Known scope limits
The supplied PRD also expects a fully interactive drag-and-drop Kanban board, project detail/member management, task comments and history. API services for board/comments/history/member management are present, but these should be tested end-to-end and completed in the UI before claiming full PRD acceptance. Frontend build/runtime integration has not been verified against live services in this environment.
