import { Routes } from '@angular/router';
import { authGuard } from './features/auth/guards/auth.guard';
import { roleGuard } from './features/auth/guards/role.guard';
export const routes: Routes = [
 {path:'',loadComponent:()=>import('./features/public/components/home/home').then(m=>m.Home),title:'Flowboard — Work in sync'},
 {path:'login',loadComponent:()=>import('./features/auth/components/login/login').then(m=>m.Login),title:'Sign in | Flowboard'},
 {path:'app',canActivate:[authGuard],loadComponent:()=>import('./features/dashboard/components/dashboard/dashboard').then(m=>m.Dashboard),title:'Workspace | Flowboard'},
 {path:'projects/:id/board',canActivate:[authGuard],loadComponent:()=>import('./features/projects/components/project-board/project-board').then(m=>m.ProjectBoard),title:'Project board | Flowboard'},
 {path:'projects',canActivate:[authGuard],loadComponent:()=>import('./features/projects/components/projects/projects').then(m=>m.ProjectsPage),title:'Projects | Flowboard'},
 {path:'tasks',canActivate:[authGuard],loadComponent:()=>import('./features/tasks/components/tasks/tasks').then(m=>m.TasksPage),title:'My tasks | Flowboard'},
 {path:'admin/users',canActivate:[authGuard,roleGuard],data:{roles:['ADMIN']},loadComponent:()=>import('./features/users/components/users/users').then(m=>m.UsersPage),title:'User directory | Flowboard'},
 {path:'**',redirectTo:''}
];