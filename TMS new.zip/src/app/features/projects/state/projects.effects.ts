import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import * as A from './projects.actions';
import { ProjectsService } from '../services/projects.service';

@Injectable()
export class ProjectsEffects {
  private actions = inject(Actions);
  private api = inject(ProjectsService);
  load$ = createEffect(() => this.actions.pipe(
    ofType(A.loadProjects),
    switchMap(({ q }) => this.api.list(q).pipe(
      map((r: any) => A.loadProjectsSuccess({ projects: Array.isArray(r) ? r : r.content ?? [] })),
      catchError(e => of(A.loadProjectsFailure({ error: e.error?.message ?? 'Could not load projects' })))
    ))
  ));
  create$ = createEffect(() => this.actions.pipe(
    ofType(A.createProject),
    switchMap(({ project }) => this.api.create(project).pipe(
      map(project => A.createProjectSuccess({ project })),
      catchError(e => of(A.loadProjectsFailure({ error: e.error?.message ?? 'Could not create project' })))
    ))
  ));
}