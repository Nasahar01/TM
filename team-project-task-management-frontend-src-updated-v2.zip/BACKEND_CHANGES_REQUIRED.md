# Backend changes required

## Confirmed task pagination bug
The Task Service's `Params` utility enforces page size 1–100. The frontend now sends `size=100` (not 200) to `/tasks/my` and `/tasks/project/{projectId}`. This removes the 400 error in the provided screenshot; no backend change is needed for that specific error.

## Performance improvement recommended
Admins and project managers currently require one task-list request per project because the backend only exposes `/tasks/my` and `/tasks/project/{projectId}`. Add a role-aware, paginated `GET /tasks/visible?page=0&size=100&sort=dueDate,asc` endpoint in Task Service and route it through API Gateway. Members should see only their assigned tasks; managers only tasks in authorized projects; admins according to the configured access policy. Use the authenticated principal and existing authorization checks; do not trust a client-supplied role or user ID. Keep page size capped at 100.

## Signup requests / approval
The supplied UserRouter has no registration-request endpoints. Add:
- `POST /users/registration-requests` — public, creates a PENDING request only.
- `GET /admin/registration-requests?status=PENDING&page=0&size=100` — ADMIN only.
- `PATCH /admin/registration-requests/{id}/approve` — ADMIN only; create/activate user and assign an allowed role.
- `PATCH /admin/registration-requests/{id}/reject` — ADMIN only; store optional rejection reason.

Add a `registration_requests` table with id, name, normalized email, password_hash, department, phone, status (PENDING/APPROVED/REJECTED), requested_at, reviewed_at, reviewed_by and rejection_reason. Hash passwords using the existing PasswordEncoder; never store plaintext. Enforce unique email and duplicate-pending-request rules. Make approval transactional/idempotent and prevent public requests from choosing ADMIN. Only the public POST route should be unauthenticated; protect admin routes at gateway and service level. Preserve existing HttpOnly cookie, CORS and CSRF/security policies.

The frontend access-request review UI is present, but it will show an endpoint error until these backend changes are implemented.
